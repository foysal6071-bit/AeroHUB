package com.example.mykuzu

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import com.example.mykuzu.server.Server

class MainActivity : Activity() {
    // ---------- palette (dark) ----------
    private val PRIMARY = 0xFF5B50E0.toInt()
    private val ACCENT = 0xFFB4AEFF.toInt()
    private val BG = 0xFF10131C.toInt()
    private val CARD = 0xFF1B1E2A.toInt()
    private val ROW = 0xFF282B37.toInt()
    private val FIELD = 0xFF141722.toInt()
    private val SOFT = 0xFF343848.toInt()
    private val LINE = 0xFF343848.toInt()
    private val ICON = 0xFF0B47A8.toInt()
    private val INK = 0xFFE8EAF2.toInt()
    private val MUTED = 0xFF9AA0B2.toInt()

    // connection tab
    private lateinit var dot: View
    private lateinit var statusT: TextView
    private lateinit var subT: TextView
    private lateinit var msgT: TextView
    private lateinit var stopBtn: Button
    private lateinit var autoBtn: Button
    private lateinit var restartBtn: Button
    private lateinit var hero: LinearLayout
    private lateinit var appsBox: LinearLayout
    private lateinit var panel: LinearLayout
    private val chips = mutableListOf<Button>()
    private val names = listOf("Wireless", "TCP", "Root")
    private var method = 0

    // shell / tabs
    private lateinit var content: FrameLayout
    private lateinit var connectPage: View
    private lateinit var toolsHost: FrameLayout
    private val navBtns = mutableListOf<LinearLayout>()
    private var tab = 0
    private var toolOpen = false

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(fill: Int, stroke: Int? = null, r: Int = 14) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat(); setColor(fill); if (stroke != null) setStroke(dp(1), stroke)
    }
    private fun heroBg(running: Boolean) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        if (running) intArrayOf(0xFF047857.toInt(), 0xFF10B981.toInt()) else intArrayOf(0xFF4338CA.toInt(), 0xFF7C3AED.toInt())
    ).apply { cornerRadius = dp(22).toFloat() }
    private fun oval(c: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
    private fun label(s: String, size: Float = 14f, color: Int = INK, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun btn(s: String, primary: Boolean = true, onClick: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; stateListAnimator = null; textSize = 15f
        setTextColor(if (primary) Color.WHITE else ACCENT)
        background = rounded(if (primary) PRIMARY else SOFT, null, 12)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) }
    }
    private fun field(hint: String, def: String = "", num: Boolean = false) = EditText(this).apply {
        this.hint = hint; setText(def); textSize = 15f; setSingleLine()
        setTextColor(INK); setHintTextColor(MUTED)
        setPadding(dp(12), 0, dp(12), 0); background = rounded(FIELD, LINE, 10)
        if (num) inputType = InputType.TYPE_CLASS_NUMBER
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) }
    }
    private fun card(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(18), dp(18), dp(18))
        background = rounded(CARD, LINE, 18)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
        v.forEach { addView(it) }
    }
    private fun step(n: Int, t: String, vararg extra: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) }
        if (n > 1) addView(View(this@MainActivity).apply {
            setBackgroundColor(LINE)
            layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { bottomMargin = dp(18) }
        })
        addView(LinearLayout(this@MainActivity).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = "$n"; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 12f
                background = oval(PRIMARY)
                layoutParams = LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(10) }
            })
            addView(label(t, 15f, INK, true))
        })
        extra.forEach { addView(it) }
    }
    private fun hint(s: String) = label(s, 13f, MUTED).apply { setPadding(0, dp(6), 0, 0) }
    private fun code(s: String) = label(s, 12f, INK).apply {
        typeface = Typeface.MONOSPACE; setTextIsSelectable(true)
        setPadding(dp(12), dp(12), dp(12), dp(12)); background = rounded(FIELD, null, 10)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
    }
    private fun copy(s: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("text", s))
        toast("Copied")
    }
    private fun sw(on: Boolean, f: (Boolean) -> Unit) = Switch(this).apply {
        isChecked = on
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        thumbTintList = ColorStateList(st, intArrayOf(ACCENT, 0xFF9AA0B2.toInt()))
        trackTintList = ColorStateList(st, intArrayOf(0x80B4AEFF.toInt(), 0xFF3A3F52.toInt()))
        setOnCheckedChangeListener { _, b -> f(b) }
    }
    private fun half(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; stateListAnimator = null; textSize = 13f
        minWidth = 0; minimumWidth = 0; setPadding(dp(4), 0, dp(4), 0)
        setTextColor(ACCENT); background = rounded(SOFT, null, 12)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(3); marginEnd = dp(3) }
    }
    private fun rowOf(vararg b: View) = LinearLayout(this).apply {
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        b.forEach { addView(it) }
    }
    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"
    private fun confirm(msg: String, go: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg)
            .setPositiveButton("Continue") { _, _ -> go() }.setNegativeButton("Cancel", null).show()
    }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    // ---------- shell: pages + bottom bar ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        content = FrameLayout(this)
        toolsHost = FrameLayout(this)
        connectPage = buildConnect()
        showToolsList()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(BG)
            addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(buildNav())
        }
        setContentView(root)
        showTab(0)
        refresh()
    }

    private fun buildNav(): View {
        val items = listOf("🔌" to "Connect", "🧰" to "Tools")
        val pill = LinearLayout(this).apply {
            background = rounded(0xFF1F2230.toInt(), null, 34)
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        items.forEachIndexed { i, item ->
            val b = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(dp(26), dp(8), dp(26), dp(8))
                addView(label(item.first, 18f).apply { gravity = Gravity.CENTER })
                addView(label(item.second, 11f, MUTED).apply { gravity = Gravity.CENTER })
                setOnClickListener { showTab(i) }
            }
            navBtns.add(b); pill.addView(b)
        }
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER; setBackgroundColor(BG)
            setPadding(dp(16), dp(8), dp(16), dp(10))
            addView(pill)
        }
    }

    private fun styleNav() = navBtns.forEachIndexed { i, b ->
        val on = i == tab
        b.background = rounded(if (on) 0xFF3D3A66.toInt() else Color.TRANSPARENT, null, 26)
        (b.getChildAt(1) as TextView).setTextColor(if (on) Color.WHITE else MUTED)
    }

    private fun showTab(i: Int) {
        tab = i
        content.removeAllViews()
        content.addView(if (i == 0) connectPage else toolsHost, FrameLayout.LayoutParams(-1, -1))
        styleNav()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (tab == 1 && toolOpen) showToolsList() else super.onBackPressed()
    }

    // ---------- TAB 1: connection ----------
    private fun buildConnect(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(28), dp(18), dp(24)) }
        val logo = TextView(this).apply {
            text = "K"; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 20f; setTypeface(null, Typeface.BOLD)
            background = rounded(PRIMARY, null, 12)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(12) }
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(label("AeroHUB", 22f, INK, true))
            addView(label("Run commands with elevated access", 13f, MUTED))
        }
        col.addView(LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; addView(logo); addView(titles) })

        dot = View(this).apply { background = oval(Color.WHITE); layoutParams = LinearLayout.LayoutParams(dp(12), dp(12)).apply { marginEnd = dp(10) } }
        statusT = label("Checking…", 24f, Color.WHITE, true)
        subT = label("", 14f, 0xDDFFFFFF.toInt()).apply { setPadding(0, dp(6), 0, 0) }
        msgT = label("", 13f, Color.WHITE).apply { setPadding(0, dp(8), 0, 0) }
        stopBtn = btn("Stop server", false) {
            Thread { MyKuzu.stop(Store.token(this)); Thread.sleep(500); refresh() }.start()
        }.apply { background = rounded(Color.WHITE, null, 12); setTextColor(0xFF3B2FC9.toInt()) }
        autoBtn = btn("Auto start", false) { autoStart() }.apply { background = rounded(Color.WHITE, null, 12); setTextColor(0xFF3B2FC9.toInt()) }
        restartBtn = btn("Restart server", false) { restartServer() }.apply {
            background = rounded(0x33FFFFFF, null, 12); setTextColor(Color.WHITE)
        }
        hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(22))
            background = heroBg(false); elevation = dp(4).toFloat()
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) }
            addView(LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL; addView(dot); addView(statusT) })
            addView(subT); addView(msgT); addView(autoBtn); addView(restartBtn); addView(stopBtn)
        }
        col.addView(hero)

        // App access
        appsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                addView(label("App access", 17f, INK, true))
                addView(hint("Allow or block apps in one place."))
            })
            addView(sw(Store.masterOn(this@MainActivity)) {
                Store.setMasterOn(this@MainActivity, it); Store.push(this@MainActivity)
                msgT.text = if (it) "App access enabled" else "All apps are blocked"
            })
        }
        col.addView(card(head, appsBox))

        // Start methods
        val seg = LinearLayout(this).apply {
            background = rounded(FIELD, null, 14); setPadding(dp(4), dp(4), dp(4), dp(4))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
        }
        names.forEachIndexed { i, n ->
            val c = Button(this).apply {
                text = n; isAllCaps = false; stateListAnimator = null; textSize = 13f
                minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0; setPadding(0, 0, 0, 0)
                setOnClickListener { method = i; styleChips(); buildPanel() }
                layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f)
            }
            chips.add(c); seg.addView(c)
        }
        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(card(
            label("Start the server", 17f, INK, true),
            hint("Pick one method and follow the steps."),
            seg, panel
        ))
        styleChips(); buildPanel()

        // Advanced
        val boot = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(14), 0, 0)
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                addView(label("Start on boot", 15f, INK, true))
                addView(hint("Starts the server by itself after a reboot. Needs Wi-Fi and Android 11+."))
            })
            addView(sw(Store.autoStart(this@MainActivity)) { on -> setAutoStart(on) })
        }
        col.addView(card(
            label("Advanced", 17f, INK, true), boot,
            btn("Check connection", false) { runDiagnose() }
        ))
        col.addView(label("AeroHUB 1.5", 12f, MUTED).apply { gravity = Gravity.CENTER; setPadding(0, dp(24), 0, 0) })
        return ScrollView(this).apply { setBackgroundColor(BG); addView(col) }
    }

    private fun styleChips() = chips.forEachIndexed { i, b ->
        val on = i == method
        b.setTextColor(if (on) Color.WHITE else MUTED)
        b.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
        b.background = rounded(if (on) SOFT else Color.TRANSPARENT, null, 11)
    }

    private fun buildPanel() {
        panel.removeAllViews()
        when (method) {
            0 -> { // Wireless debugging
                val pairPort = field("Pairing port", "", true)
                val pairCode = field("Pairing code", "", true)
                val connPort = field("Connection port (empty = find automatically)", "", true)
                panel.addView(step(1, "Turn on Wireless debugging",
                    hint("Connect to Wi-Fi, then enable Wireless debugging in Developer options."),
                    btn("Open Developer options", false) {
                        try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) } catch (e: Exception) { toast("Open Settings manually") }
                    }))
                panel.addView(step(2, "Pair using a notification",
                    hint("Press Start, then tap \"Pair device with pairing code\" in Settings. Type the code into the MyKuzu notification. The server starts automatically."),
                    btn("Start pairing") { startPairing() }))
                val manual = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; visibility = View.GONE
                    addView(pairPort); addView(pairCode)
                    addView(btn("Pair device", false) {
                        val pp = pairPort.text.toString().toIntOrNull(); val c = pairCode.text.toString()
                        if (pp == null || c.isEmpty()) toast("Enter the pairing port and code") else work("Pairing…") {
                            if (Build.VERSION.SDK_INT < 30) error("Wireless debugging needs Android 11 or newer")
                            if (!AdbMgr.pairWith(this@MainActivity, "127.0.0.1", pp, c)) error("Pairing failed. Check the port and code")
                            "Paired. Now press Connect & Start"
                        }
                    })
                    addView(connPort)
                    addView(btn("Connect & Start", false) {
                        val p = connPort.text.toString().toIntOrNull()
                        if (p == null) work("Finding the connection port…") { Starter.wirelessStart(this@MainActivity) }
                        else adbStart("127.0.0.1", p)
                    })
                }
                panel.addView(label("Enter port and code manually  ›", 14f, ACCENT, true).apply {
                    setPadding(dp(4), dp(20), dp(4), dp(4))
                    setOnClickListener { manual.visibility = if (manual.visibility == View.GONE) View.VISIBLE else View.GONE }
                })
                panel.addView(manual)
            }
            1 -> { // ADB over TCP
                val tcpPort = field("Port", Store.tcpPort(this).toString(), true)
                panel.addView(step(1, "Turn TCP on (no computer needed)",
                    hint("Pair once in the Wireless tab. Then MyKuzu switches ADB to TCP by itself. TCP also works without Wi-Fi, until the phone reboots."),
                    tcpPort,
                    btn("Enable TCP via Wireless", false) {
                        val p = tcpPort.text.toString().toIntOrNull() ?: 5555
                        work("Switching ADB to TCP…") { Starter.enableTcp(this@MainActivity, p) }
                    }))
                panel.addView(step(2, "Connect and start",
                    hint("If TCP is already on, start here. Accept the \"Allow USB debugging?\" dialog if it appears."),
                    btn("Connect & Start") {
                        val p = tcpPort.text.toString().toIntOrNull() ?: 5555
                        Store.setTcpPort(this, p)
                        adbStart("127.0.0.1", p)
                    }))
            }
            else -> { // Root
                panel.addView(step(1, "Start with root",
                    hint("Grant superuser access when asked."),
                    btn("Start with root") { work("Requesting root…") { Starter.startRoot(this@MainActivity) } }))
            }
        }
    }

    // ---------- connection logic ----------
    private fun startPairing() {
        if (Build.VERSION.SDK_INT < 30) { toast("Wireless debugging needs Android 11 or newer"); return }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7); return
        }
        startForegroundService(Intent(this, PairingService::class.java).setAction(PairingService.ACTION_START))
        msgT.text = "Pairing started. Check your notifications."
        toast("Now tap \"Pair device with pairing code\" in Wireless debugging")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startPairing()
            else toast("Allow notifications to enter the pairing code there")
        }
    }

    private fun work(label: String, block: () -> String) {
        msgT.text = label
        Thread {
            val r = try { block() } catch (e: Throwable) { "Failed: ${e.message ?: e.javaClass.simpleName}" }
            runOnUiThread { msgT.text = r }
            refresh()
        }.start()
    }

    private fun adbStart(host: String, port: Int) = work("Connecting to $host:$port…") {
        AdbMgr.runStart(this, host, port)
        if (!Starter.waitRunning(this)) error("Start command sent, but the server did not answer. Try Auto start.")
        "Server started"
    }

    private fun autoStart() = work("Looking for a way to connect…") { Starter.auto(this) }

    private fun restartServer() = work("Restarting…") {
        runCatching { MyKuzu.stop(Store.token(this)) }
        Thread.sleep(800)
        Starter.auto(this)
    }

    private fun setAutoStart(on: Boolean) {
        Store.setAutoStart(this, on)
        if (!on) { msgT.text = "Start on boot is off"; return }
        Thread {
            val r = try {
                val res = MyKuzu.exec(Store.token(this), "pm grant $packageName android.permission.WRITE_SECURE_SETTINGS")
                if (res.first == 0) "Start on boot is on" else "Start on boot is on, but the permission was not granted: ${res.second.trim()}"
            } catch (e: Exception) { "Start on boot is on. Start the server once so MyKuzu can finish the setup." }
            runOnUiThread { msgT.text = r }
        }.start()
    }

    private fun runDiagnose() {
        toast("Checking…")
        Thread {
            val r = try { Starter.diagnose(this) } catch (e: Throwable) { "Failed: ${Starter.msg(e)}" }
            runOnUiThread { AlertDialog.Builder(this).setTitle("Connection check").setMessage(r).setPositiveButton("OK", null).show() }
        }.start()
    }

    private fun buildApps() {
        appsBox.removeAllViews()
        val gs = Store.grants(this)
        if (gs.isEmpty()) { appsBox.addView(hint("No apps yet. Apps that ask for access will appear here.")); return }
        gs.forEach { g ->
            val name = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(g.pkg, 0)).toString() } catch (e: Exception) { g.pkg }
            appsBox.addView(LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(14), 0, 0)
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    addView(label(name, 15f, INK, true)); addView(label(g.pkg, 12f, MUTED))
                })
                addView(sw(g.enabled) { Store.setEnabled(this@MainActivity, g.pkg, it); Store.push(this@MainActivity) })
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity).setTitle("Remove $name?")
                        .setMessage("It will lose access and must ask again.")
                        .setPositiveButton("Remove") { _, _ -> Store.remove(this@MainActivity, g.pkg); Store.push(this@MainActivity); buildApps() }
                        .setNegativeButton("Cancel", null).show()
                    true
                }
            })
        }
        appsBox.addView(hint("Long-press an app to remove it."))
    }

    override fun onResume() { super.onResume(); buildApps(); refresh() }

    private fun refresh() {
        Thread {
            val tok = Store.token(this)
            val uid = MyKuzu.ping(tok)
            val ver = if (uid != null) MyKuzu.version(tok) else null
            if (uid != null) runCatching { MyKuzu.sync(tok, Store.activeTokens(this)) }
            runOnUiThread {
                hero.background = heroBg(uid != null)
                statusT.text = if (uid == null) "Not running" else "Running"
                subT.text = when (uid) {
                    null -> "Tap Auto start, or choose a method below."
                    0 -> "Running as root"
                    2000 -> "Running as ADB shell"
                    else -> "Running as UID $uid"
                }
                stopBtn.visibility = if (uid == null) View.GONE else View.VISIBLE
                restartBtn.visibility = if (uid == null) View.GONE else View.VISIBLE
                autoBtn.visibility = if (uid == null) View.VISIBLE else View.GONE
                if (uid != null && (ver ?: 1) < Server.VERSION) msgT.text = "Server is outdated. Tap Restart server to update it."
            }
        }.start()
    }

    // ---------- TAB 2: tools ----------
    private val INFO_CMD = listOf(
        "echo \"Model: \$(getprop ro.product.brand) \$(getprop ro.product.model)\"",
        "echo \"Android: \$(getprop ro.build.version.release) (API \$(getprop ro.build.version.sdk))\"",
        "echo \"Security patch: \$(getprop ro.build.version.security_patch)\"",
        "echo \"CPU: \$(getprop ro.product.cpu.abi)\"",
        "echo \"Kernel: \$(uname -r)\"",
        "echo \"Battery: \$(dumpsys battery | grep -m1 level | tr -d ' ')\"",
        "echo \"RAM: \$(grep MemTotal /proc/meminfo | tr -s ' ')\"",
        "echo \"Storage: \$(df -h /data | tail -1 | tr -s ' ')\"",
        "echo \"Running as: \$(id)\""
    ).joinToString("; ")
    private val ANIM = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")

    private fun toolRow(glyph: String, title: String, go: () -> Unit) = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = rounded(ROW, null, 22)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
        addView(TextView(this@MainActivity).apply {
            text = glyph; textSize = 20f; gravity = Gravity.CENTER; background = rounded(ICON, null, 14)
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginEnd = dp(16) }
        })
        addView(label(title, 17f, INK).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        addView(label("›", 24f, MUTED))
        setOnClickListener { go() }
    }

    private fun showToolsList() {
        toolOpen = false
        toolsHost.removeAllViews()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(36), dp(18), dp(24)) }
        col.addView(label("Tools", 28f, INK))
        col.addView(hint("Needs the server running. Root can do more than ADB shell."))
        col.addView(toolRow("♿", "Accessibility") { accessibilityTool() })
        col.addView(toolRow("🚀", "Activities launcher") { launcherTool() })
        col.addView(toolRow("📦", "App installer") { installerTool() })
        col.addView(toolRow("🛡", "App ops") { appOpsTool() })
        col.addView(toolRow("🗂", "App manager") { appsTool() })
        col.addView(toolRow("🔑", "Permissions") { permissionsTool() })
        col.addView(toolRow("📱", "Device info") { deviceInfoTool() })
        col.addView(toolRow("🖥", "Display") { displayTool() })
        col.addView(toolRow("📁", "Files") { filesTool() })
        col.addView(toolRow("⚙", "System settings") { settingsTool() })
        col.addView(toolRow("⏻", "Power") { powerTool() })
        col.addView(toolRow("🔒", "Keyboard guard") { keyboardTool() })
        col.addView(toolRow("⌨", "Terminal") { terminalTool() })
        col.addView(toolRow("📜", "Activity log") { showLog() })
        toolsHost.addView(ScrollView(this).apply { setBackgroundColor(BG); addView(col) }, FrameLayout.LayoutParams(-1, -1))
    }

    private fun openTool(title: String, vararg v: View) {
        toolOpen = true
        toolsHost.removeAllViews()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(24), dp(18), dp(24)) }
        col.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(label("‹", 32f, ACCENT).apply { setPadding(dp(4), 0, dp(18), dp(4)); setOnClickListener { showToolsList() } })
            addView(label(title, 22f, INK, true))
        })
        v.forEach { col.addView(it) }
        toolsHost.addView(ScrollView(this).apply { setBackgroundColor(BG); addView(col) }, FrameLayout.LayoutParams(-1, -1))
    }

    private fun outView() = label("", 12f, INK).apply {
        typeface = Typeface.MONOSPACE; setTextIsSelectable(true); setPadding(0, dp(12), 0, 0)
    }

    /** A tool page: a card holding the views you build plus an output area. */
    private fun tool(title: String, build: (TextView) -> List<View>) {
        val out = outView()
        val views = build(out)
        openTool(title, card(*(views + out).toTypedArray()))
    }

    /** Runs a command on the server in the background and shows the result in [out]. */
    private fun bg(cmd: String, done: (Int, String) -> Unit) {
        Thread {
            val r = try { MyKuzu.exec(Store.token(this), cmd) } catch (e: Exception) { -1 to "Start the server first (${e.message})" }
            runOnUiThread { done(r.first, r.second) }
        }.start()
    }

    private fun runSys(out: TextView, ok: String, cmd: String) {
        out.text = "Running…"
        bg(cmd) { c, o ->
            val parts = mutableListOf<String>()
            if (c == -1) parts.add(o) else {
                if (c == 0) { if (ok.isNotEmpty()) parts.add("✓ $ok") } else parts.add("Exit code $c")
                if (o.isNotBlank()) parts.add(o.trim())
            }
            out.text = if (parts.isEmpty()) "Done" else parts.joinToString("\n")
        }
    }

    private fun need(f: EditText, what: String): String? {
        val v = f.text.toString().trim()
        if (v.isEmpty()) { toast("Enter $what"); return null }
        return v
    }

    private fun deviceInfoTool() = tool("Device info") { out ->
        runSys(out, "", INFO_CMD)
        listOf<View>(btn("Refresh", false) { runSys(out, "", INFO_CMD) })
    }

    private fun appsTool() = tool("App manager") { out ->
        val pkgF = field("Package name, e.g. com.example.app")
        fun pkg() = need(pkgF, "a package name")
        listOf<View>(
            pkgF,
            rowOf(
                half("Force stop") { pkg()?.let { runSys(out, "Stopped", "am force-stop ${q(it)}") } },
                half("Clear data") { pkg()?.let { p -> confirm("Delete all data of $p?") { runSys(out, "Data cleared", "pm clear ${q(p)}") } } }
            ),
            rowOf(
                half("Disable") { pkg()?.let { runSys(out, "Disabled", "pm disable-user --user 0 ${q(it)}") } },
                half("Enable") { pkg()?.let { runSys(out, "Enabled", "pm enable ${q(it)}") } }
            ),
            rowOf(
                half("Uninstall") { pkg()?.let { p -> confirm("Uninstall $p for the current user?") { runSys(out, "Uninstalled", "pm uninstall --user 0 ${q(p)}") } } },
                half("Open app") { pkg()?.let { runSys(out, "Opened", "monkey -p ${q(it)} -c android.intent.category.LAUNCHER 1") } }
            ),
            rowOf(
                half("Search packages") { runSys(out, "", "pm list packages | grep -i ${q(pkgF.text.toString().trim())}") },
                half("User apps") { runSys(out, "", "pm list packages -3") }
            )
        )
    }

    private fun permissionsTool() = tool("Permissions") { out ->
        val pkgF = field("Package name, e.g. com.example.app")
        val permF = field("Permission, e.g. android.permission.WRITE_SECURE_SETTINGS")
        listOf<View>(
            pkgF, permF,
            rowOf(
                half("Grant") { val p = need(pkgF, "a package name"); val x = need(permF, "a permission"); if (p != null && x != null) runSys(out, "Granted", "pm grant ${q(p)} ${q(x)}") },
                half("Revoke") { val p = need(pkgF, "a package name"); val x = need(permF, "a permission"); if (p != null && x != null) runSys(out, "Revoked", "pm revoke ${q(p)} ${q(x)}") }
            ),
            rowOf(half("Show granted permissions") { need(pkgF, "a package name")?.let { runSys(out, "", "dumpsys package ${q(it)} | grep 'granted=true'") } })
        )
    }

    private fun appOpsTool() = tool("App ops") { out ->
        val pkgF = field("Package name, e.g. com.example.app")
        val opF = field("Operation, e.g. SYSTEM_ALERT_WINDOW")
        fun set(mode: String) {
            val p = need(pkgF, "a package name"); val o = need(opF, "an operation")
            if (p != null && o != null) runSys(out, "Set to $mode", "appops set ${q(p)} ${q(o)} $mode")
        }
        listOf<View>(
            pkgF, opF,
            rowOf(half("Allow") { set("allow") }, half("Ignore") { set("ignore") }),
            rowOf(half("Deny") { set("deny") }, half("Default") { set("default") }),
            rowOf(half("Show all for app") { need(pkgF, "a package name")?.let { runSys(out, "", "appops get ${q(it)}") } })
        )
    }

    private fun displayTool() = tool("Display") { out ->
        val dpiF = field("Screen density (DPI)", "", true)
        val sizeF = field("Screen size, e.g. 1080x2400")
        listOf<View>(
            rowOf(half("Show current") { runSys(out, "", "wm size; wm density") }, half("Screenshot") { runSys(out, "Saved to Pictures", "mkdir -p /sdcard/Pictures; screencap -p /sdcard/Pictures/mykuzu_\$(date +%s).png") }),
            dpiF,
            rowOf(
                half("Set DPI") { val d = dpiF.text.toString().toIntOrNull(); if (d == null) toast("Enter a DPI number") else runSys(out, "DPI set", "wm density $d") },
                half("Reset DPI") { runSys(out, "DPI reset", "wm density reset") }
            ),
            sizeF,
            rowOf(
                half("Set size") { need(sizeF, "a size like 1080x2400")?.let { runSys(out, "Size set", "wm size ${q(it)}") } },
                half("Reset size") { runSys(out, "Size reset", "wm size reset") }
            ),
            rowOf(
                half("Animations off") { runSys(out, "Animations off", ANIM.joinToString("; ") { "settings put global $it 0" }) },
                half("Animations on") { runSys(out, "Animations on", ANIM.joinToString("; ") { "settings put global $it 1" }) }
            )
        )
    }

    private fun settingsTool() = tool("System settings") { out ->
        val nsF = field("Namespace: global, secure or system", "global")
        val keyF = field("Setting key")
        val valF = field("Value")
        fun ns() = nsF.text.toString().trim()
        listOf<View>(
            nsF, keyF, valF,
            rowOf(
                half("Read") { need(keyF, "a key")?.let { runSys(out, "", "settings get ${q(ns())} ${q(it)}") } },
                half("Write") { need(keyF, "a key")?.let { k -> confirm("Change this system setting?") { runSys(out, "Saved", "settings put ${q(ns())} ${q(k)} ${q(valF.text.toString())}") } } }
            ),
            rowOf(half("List all in namespace") { runSys(out, "", "settings list ${q(ns())}") })
        )
    }

    private fun accessibilityTool() = tool("Accessibility") { out ->
        val svcF = field("Service, e.g. com.app/com.app.MyService")
        listOf<View>(
            hint("Turn accessibility services on or off without opening Settings."),
            svcF,
            rowOf(half("Show enabled") { runSys(out, "", "settings get secure enabled_accessibility_services") }),
            rowOf(
                half("Enable service") {
                    need(svcF, "a service")?.let { s ->
                        runSys(out, "Enabled", "C=\$(settings get secure enabled_accessibility_services); case \"\$C\" in null|\"\") N=${q(s)};; *) N=\"\$C:\"${q(s)};; esac; settings put secure enabled_accessibility_services \"\$N\"; settings put secure accessibility_enabled 1")
                    }
                },
                half("Disable all") { confirm("Turn off all accessibility services?") { runSys(out, "Disabled", "settings delete secure enabled_accessibility_services; settings put secure accessibility_enabled 0") } }
            )
        )
    }

    private fun launcherTool() = tool("Activities launcher") { out ->
        val pkgF = field("Package name")
        val clsF = field("Activity, e.g. .MainActivity")
        val uriF = field("Link, e.g. https://example.com")
        listOf<View>(
            pkgF, clsF,
            rowOf(
                half("Launch activity") { val p = need(pkgF, "a package name"); val c = need(clsF, "an activity"); if (p != null && c != null) runSys(out, "Started", "am start -n ${q("$p/$c")}") },
                half("Open app") { need(pkgF, "a package name")?.let { runSys(out, "Opened", "monkey -p ${q(it)} -c android.intent.category.LAUNCHER 1") } }
            ),
            uriF,
            rowOf(half("Open link") { need(uriF, "a link")?.let { runSys(out, "Opened", "am start -a android.intent.action.VIEW -d ${q(it)}") } })
        )
    }

    private fun installerTool() = tool("App installer") { out ->
        val pathF = field("APK path", "/sdcard/Download/")
        listOf<View>(
            hint("Installs an APK file from storage. For several files, use Files and tap an .apk."),
            pathF,
            rowOf(
                half("Install") { need(pathF, "an APK path")?.let { runSys(out, "Installed", "pm install -r ${q(it)}") } },
                half("Install + grant all") { need(pathF, "an APK path")?.let { runSys(out, "Installed", "pm install -r -g ${q(it)}") } }
            )
        )
    }

    private fun powerTool() = tool("Power") { out ->
        listOf<View>(
            rowOf(half("Reboot") { confirm("Reboot the device now?") { runSys(out, "Rebooting", "svc power reboot") } },
                half("Power off") { confirm("Power off the device now?") { runSys(out, "Powering off", "svc power shutdown") } }),
            rowOf(half("Recovery") { confirm("Reboot to recovery?") { runSys(out, "Rebooting", "svc power reboot recovery") } },
                half("Bootloader") { confirm("Reboot to bootloader?") { runSys(out, "Rebooting", "svc power reboot bootloader") } })
        )
    }

    private val IME_ID = "com.example.mykuzu/com.example.mykuzu.GuardIme"

    private fun keyboardTool() = tool("Keyboard guard") { out ->
        val status = "echo \"Enabled keyboards:\"; ime list -s; echo; echo \"Active keyboard: \$(settings get secure default_input_method)\""
        runSys(out, "", status)
        listOf<View>(
            hint("Registers MyKuzu as an enabled keyboard. It does not read any text. Do NOT choose it as your active keyboard; keep your normal keyboard selected."),
            btn("Enable keyboard (via server)") { runSys(out, "Keyboard enabled", "ime enable $IME_ID; $status") },
            rowOf(
                half("Keyboard settings") { try { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) } catch (e: Exception) { toast("Open Settings manually") } },
                half("Show status") { runSys(out, "", status) }
            ),
            rowOf(half("Disable keyboard") { confirm("Disable the MyKuzu keyboard?") { runSys(out, "Keyboard disabled", "ime disable $IME_ID; $status") } })
        )
    }

    private fun terminalTool() = tool("Terminal") { out ->
        val cmdF = field("Shell command", "id")
        listOf<View>(cmdF, btn("Run") { runSys(out, "", cmdF.text.toString()) })
    }

    private fun filesTool() {
        val pathT = label("/sdcard", 13f, ACCENT, true).apply { typeface = Typeface.MONOSPACE; setPadding(0, 0, 0, dp(8)) }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun load(p: String) {
            pathT.text = p
            list.removeAllViews(); list.addView(hint("Loading…"))
            bg("ls -1Ap ${q(p)}") { c, o ->
                list.removeAllViews()
                if (c != 0) { list.addView(hint(if (c == -1) o else o.trim().ifEmpty { "Cannot open this folder" })) }
                else {
                    if (p != "/") list.addView(fileRow("⬆  ..") { load(p.trimEnd('/').substringBeforeLast('/').ifEmpty { "/" }) })
                    val items = o.lines().filter { it.isNotBlank() }
                    if (items.isEmpty()) list.addView(hint("Empty folder"))
                    items.forEach { n ->
                        val isDir = n.endsWith("/")
                        val name = n.trimEnd('/')
                        val full = (if (p.endsWith("/")) p else "$p/") + name
                        list.addView(fileRow((if (isDir) "📁  " else "📄  ") + name) {
                            if (isDir) load(full) else fileActions(name, full)
                        })
                    }
                }
            }
        }
        val goF = field("Path", "/sdcard")
        openTool("Files", card(
            goF,
            rowOf(half("Go") { load(goF.text.toString().trim().ifEmpty { "/" }) }, half("Internal storage") { goF.setText("/sdcard"); load("/sdcard") }),
            pathT, list
        ))
        load("/sdcard")
    }

    private fun fileRow(text: String, go: () -> Unit) = label(text, 14f, INK).apply {
        setPadding(dp(8), dp(12), dp(8), dp(12)); setOnClickListener { go() }
    }

    private fun fileActions(name: String, full: String) {
        val opts = mutableListOf("Copy path", "Delete")
        if (name.endsWith(".apk")) opts.add("Install")
        AlertDialog.Builder(this).setTitle(name).setItems(opts.toTypedArray()) { _, i ->
            when (opts[i]) {
                "Copy path" -> copy(full)
                "Delete" -> confirm("Delete $name?") { bg("rm -f ${q(full)}") { c, o -> toast(if (c == 0) "Deleted" else o.trim().ifEmpty { "Failed" }) } }
                else -> bg("pm install -r ${q(full)}") { c, o -> toast(if (c == 0) "Installed" else o.trim().ifEmpty { "Failed" }) }
            }
        }.show()
    }

    private fun showLog() {
        Thread {
            val raw = try { MyKuzu.log(Store.token(this)) } catch (e: Exception) { null }
            val txt = if (raw == null) "Start the server first." else if (raw.isEmpty()) "No commands yet." else {
                val fmt = java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.US)
                val gs = Store.grants(this)
                raw.reversed().joinToString("\n\n") { e ->
                    val p = e.split("|", limit = 4)
                    if (p.size < 4) e else {
                        val who = if (p[1] == "app") "AeroHUB" else (gs.firstOrNull { it.token.startsWith(p[1]) }?.pkg ?: p[1])
                        val cmd = try { String(java.util.Base64.getDecoder().decode(p[3])) } catch (x: Exception) { "?" }
                        "${fmt.format(java.util.Date(p[0].toLongOrNull() ?: 0L))}  $who  (exit ${p[2]})\n$cmd"
                    }
                }
            }
            runOnUiThread { AlertDialog.Builder(this).setTitle("Activity log").setMessage(txt).setPositiveButton("OK", null).show() }
        }.start()
    }
}
