package com.example.mykuzu

import android.content.Context
import android.os.Build
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.net.InetSocketAddress
import java.net.Socket
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/** ADB client (pairing + TCP/TLS connect). Keys are generated once and stored privately. */
class AdbMgr private constructor(ctx: Context) : AbsAdbConnectionManager() {
    private val priv: PrivateKey
    private val cert: Certificate

    init {
        setApi(Build.VERSION.SDK_INT)
        val kf = File(ctx.filesDir, "adb_key")
        val cf = File(ctx.filesDir, "adb_cert")
        if (kf.exists() && cf.exists()) {
            priv = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
            cert = cf.inputStream().use { CertificateFactory.getInstance("X.509").generateCertificate(it) }
        } else {
            val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
            val name = X500Name("CN=MyKuzu")
            val now = Date()
            val end = Date(now.time + 3650L * 24 * 3600 * 1000)
            val builder = JcaX509v3CertificateBuilder(
                name, BigInteger.valueOf(System.nanoTime() and Long.MAX_VALUE), now, end, name, kp.public
            )
            val signer = JcaContentSignerBuilder("SHA512withRSA").build(kp.private)
            val c = JcaX509CertificateConverter().getCertificate(builder.build(signer))
            kf.writeBytes(kp.private.encoded)
            cf.writeBytes(c.encoded)
            priv = kp.private
            cert = c
        }
    }

    override fun getPrivateKey(): PrivateKey = priv
    override fun getCertificate(): Certificate = cert
    override fun getDeviceName(): String = "MyKuzu"

    companion object {
        @Volatile private var inst: AdbMgr? = null
        fun get(c: Context): AdbMgr = inst ?: synchronized(this) {
            inst ?: AdbMgr(c.applicationContext).also { inst = it }
        }

        /** Quick check: is anything listening on host:port? Tells "port closed" apart from "refused/unauthorised". */
        fun reachable(host: String, port: Int, ms: Int = 2500): Boolean = try {
            Socket().use { it.connect(InetSocketAddress(host, port), ms) }
            true
        } catch (e: Exception) { false }

        /** Runs [f] on a worker thread and gives up after [sec] seconds (adb calls can hang forever). */
        private fun <T> timed(sec: Long, what: String, f: () -> T): T {
            val ex = Executors.newSingleThreadExecutor()
            try {
                val fut = ex.submit(Callable<T> { f() })
                try {
                    return fut.get(sec, TimeUnit.SECONDS)
                } catch (e: TimeoutException) {
                    fut.cancel(true)
                    throw IllegalStateException("Timed out while $what. If an \"Allow USB debugging?\" dialog appeared, tap \"Always allow\" and try again.")
                } catch (e: ExecutionException) {
                    throw e.cause ?: e
                }
            } finally { ex.shutdownNow() }
        }

        private fun explain(e: Throwable?): String {
            val m = e?.message ?: e?.javaClass?.simpleName ?: "unknown error"
            return when {
                m.startsWith("Timed out") -> m
                e?.javaClass?.simpleName?.contains("Auth") == true ->
                    "ADB authentication failed. Accept the \"Allow USB debugging?\" dialog on this phone (tick \"Always allow\"), or pair again in the Wireless tab."
                else -> "Could not connect: $m"
            }
        }

        /** Connects to adbd with a pre-check, a timeout and up to 3 attempts. Always returns a connected manager or throws a readable error. */
        fun open(c: Context, host: String, port: Int): AdbMgr {
            if (!reachable(host, port)) throw IllegalStateException(
                "Nothing is listening on $host:$port. TCP is off or the port is different. " +
                "Use \"Enable TCP via Wireless\" in the TCP tab, or check the port number."
            )
            val m = get(c)
            var last: Throwable? = null
            for (attempt in 1..3) {
                runCatching { m.disconnect() }
                try {
                    if (timed(20, "connecting to $host:$port") { m.connect(host, port) }) return m
                    last = IllegalStateException("adbd refused the connection")
                } catch (e: Throwable) {
                    last = e
                    if (e.message?.startsWith("Timed out") == true) break
                }
                Thread.sleep(600L * attempt)
            }
            throw IllegalStateException(explain(last))
        }

        fun pairWith(c: Context, host: String, port: Int, code: String): Boolean {
            val m = get(c)
            return timed(20, "pairing") { m.pair(host, port, code) }
        }

        /** Connects to adbd and runs the MyKuzu start command as the ADB shell user. */
        fun runStart(c: Context, host: String, port: Int) {
            val m = open(c, host, port)
            try {
                m.openStream("shell:" + Store.startCommand(c)).use { it.openInputStream().readBytes() }
            } finally { runCatching { m.disconnect() } }
        }

        /** Asks adbd to restart in TCP mode (same as `adb tcpip <port>`), over an already paired connection. */
        fun enableTcp(c: Context, host: String, port: Int, tcpPort: Int) {
            val m = open(c, host, port)
            try {
                m.openStream("tcpip:$tcpPort").use { it.openInputStream().readBytes() }
            } finally { runCatching { m.disconnect() } }
        }
    }
}
