package com.example.mykuzu

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Handler
import android.os.Looper
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Finds the Wireless debugging services (pairing / connect) advertised on this device via mDNS. */
class Mdns(ctx: Context, private val type: String, private val onFound: (host: String, port: Int) -> Unit) {
    private val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var listener: NsdManager.DiscoveryListener? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var stopped = false

    /** Resolving can fail with "already active" when several services show up together, so retry a few times. */
    @Suppress("DEPRECATION")
    private fun resolve(s: NsdServiceInfo, left: Int) {
        if (stopped) return
        try {
            nsd.resolveService(s, object : NsdManager.ResolveListener {
                override fun onResolveFailed(si: NsdServiceInfo, errorCode: Int) {
                    if (left > 0 && !stopped) main.postDelayed({ resolve(s, left - 1) }, 400)
                }
                override fun onServiceResolved(r: NsdServiceInfo) {
                    if (!stopped) onFound(r.host?.hostAddress ?: "127.0.0.1", r.port)
                }
            })
        } catch (e: Exception) {
            if (left > 0 && !stopped) main.postDelayed({ resolve(s, left - 1) }, 400)
        }
    }

    fun start() {
        stopped = false
        val l = object : NsdManager.DiscoveryListener {
            override fun onServiceFound(s: NsdServiceInfo) { resolve(s, 5) }
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onServiceLost(s: NsdServiceInfo) {}
        }
        listener = l
        nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, l)
    }

    fun stop() {
        stopped = true
        listener?.let { runCatching { nsd.stopServiceDiscovery(it) } }
        listener = null
    }

    companion object {
        /** Waits up to [sec] seconds for the first service of [type]. Returns host to port, or null. */
        fun findOne(ctx: Context, type: String, sec: Long): Pair<String, Int>? {
            val latch = CountDownLatch(1)
            var res: Pair<String, Int>? = null
            val d = Mdns(ctx, type) { host, port ->
                if (res == null) { res = host to port; latch.countDown() }
            }
            d.start()
            latch.await(sec, TimeUnit.SECONDS)
            d.stop()
            return res
        }
    }
}
