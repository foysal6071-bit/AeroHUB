package com.example.mykuzu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** Short-lived foreground service that keeps the process alive while the server is being started after boot. */
class BootService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("boot", "Auto start", NotificationManager.IMPORTANCE_LOW))
        fun note(t: String) = Notification.Builder(this, "boot")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("MyKuzu").setContentText(t).build()
        val n = note("Starting the server…")
        if (Build.VERSION.SDK_INT >= 34) startForeground(72, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        else startForeground(72, n)
        Thread {
            val r = try { Starter.boot(this) } catch (e: Throwable) { Starter.msg(e) }
            stopForeground(STOP_FOREGROUND_DETACH)
            nm.notify(72, Notification.Builder(this, "boot").setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("MyKuzu").setContentText(r.lines().first()).setAutoCancel(true).build())
            stopSelf()
        }.start()
        return START_NOT_STICKY
    }
}
