/*
 * aerostart - tiny freestanding native starter (same idea as Shizuku's libshizuku.so).
 * Usage: aerostart <apk> <token> <csv> <logfile> [exec-path-override]
 * Double-forks, setsid(), detaches from adb's pipes, sets CLASSPATH and execs app_process with the AeroHUB server.
 * Raw syscalls only (no libc) so it runs on any Android kernel without extra libraries.
 */
typedef unsigned long ul;

#if defined(__aarch64__)
#define NR_FORK_CLONE 220
#define NR_SETSID 157
#define NR_CHDIR 49
#define NR_OPENAT 56
#define NR_DUP3 24
#define NR_CLOSE 57
#define NR_EXECVE 221
#define NR_EXIT 93
#define NR_WRITE 64
static inline long sc(long n, long a, long b, long c, long d, long e) {
    register long x8 __asm__("x8") = n;
    register long x0 __asm__("x0") = a;
    register long x1 __asm__("x1") = b;
    register long x2 __asm__("x2") = c;
    register long x3 __asm__("x3") = d;
    register long x4 __asm__("x4") = e;
    __asm__ volatile("svc 0" : "+r"(x0) : "r"(x8), "r"(x1), "r"(x2), "r"(x3), "r"(x4) : "memory", "cc");
    return x0;
}
static long do_fork(void) { return sc(NR_FORK_CLONE, 17 /*SIGCHLD*/, 0, 0, 0, 0); }
static long do_open(const char *p, int fl, int mode) { return sc(NR_OPENAT, -100 /*AT_FDCWD*/, (long)p, fl, mode, 0); }
static long do_dup2(int o, int n) { return o == n ? n : sc(NR_DUP3, o, n, 0, 0, 0); }
__asm__(".globl _start\n_start:\n mov x0, sp\n bl start_c\n");
#elif defined(__arm__)
#define NR_FORK 2
#define NR_SETSID 66
#define NR_CHDIR 12
#define NR_OPEN 5
#define NR_DUP2 63
#define NR_CLOSE 6
#define NR_EXECVE 11
#define NR_EXIT 1
#define NR_WRITE 4
static inline long sc(long n, long a, long b, long c, long d, long e) {
    register long r7 __asm__("r7") = n;
    register long r0 __asm__("r0") = a;
    register long r1 __asm__("r1") = b;
    register long r2 __asm__("r2") = c;
    register long r3 __asm__("r3") = d;
    register long r4 __asm__("r4") = e;
    __asm__ volatile("svc 0" : "+r"(r0) : "r"(r7), "r"(r1), "r"(r2), "r"(r3), "r"(r4) : "memory", "cc");
    return r0;
}
static long do_fork(void) { return sc(NR_FORK, 0, 0, 0, 0, 0); }
static long do_open(const char *p, int fl, int mode) { return sc(NR_OPEN, (long)p, fl, mode, 0, 0); }
static long do_dup2(int o, int n) { return sc(NR_DUP2, o, n, 0, 0, 0); }
__asm__(".globl _start\n_start:\n mov r0, sp\n bic sp, sp, #7\n bl start_c\n");
#elif defined(__x86_64__)
#define NR_FORK 57
#define NR_SETSID 112
#define NR_CHDIR 80
#define NR_OPEN 2
#define NR_DUP2 33
#define NR_CLOSE 3
#define NR_EXECVE 59
#define NR_EXIT 60
#define NR_WRITE 1
static inline long sc(long n, long a, long b, long c, long d, long e) {
    long ret;
    register long r10 __asm__("r10") = d;
    register long r8 __asm__("r8") = e;
    __asm__ volatile("syscall" : "=a"(ret) : "a"(n), "D"(a), "S"(b), "d"(c), "r"(r10), "r"(r8) : "rcx", "r11", "memory");
    return ret;
}
static long do_fork(void) { return sc(NR_FORK, 0, 0, 0, 0, 0); }
static long do_open(const char *p, int fl, int mode) { return sc(NR_OPEN, (long)p, fl, mode, 0, 0); }
static long do_dup2(int o, int n) { return sc(NR_DUP2, o, n, 0, 0, 0); }
__asm__(".globl _start\n_start:\n mov %rsp, %rdi\n and $-16, %rsp\n call start_c\n");
#else
#error unsupported architecture
#endif

static void out(int fd, const char *s) {
    long n = 0;
    while (s[n]) n++;
    sc(NR_WRITE, fd, (long)s, n, 0, 0);
}
static int starts(const char *s, const char *p) {
    while (*p) { if (*s != *p) return 0; s++; p++; }
    return 1;
}
static void quit(int code) { for (;;) sc(NR_EXIT, code, 0, 0, 0, 0); }

static char cp_buf[4096 + 16];
static char *new_env[512];

void start_c(long *sp) {
    long argc = sp[0];
    char **argv = (char **)(sp + 1);
    char **envp = argv + argc + 1;
    if (argc < 5) { out(2, "usage: aerostart <apk> <token> <csv> <log> [exec]\n"); quit(2); }
    const char *apk = argv[1], *token = argv[2], *csv = argv[3], *log = argv[4];
    const char *exe = argc >= 6 ? argv[5] : "/system/bin/app_process";

    long pid = do_fork();
    if (pid < 0) { out(2, "aerostart: fork failed\n"); quit(3); }
    if (pid > 0) { out(1, "aerostart: launched\n"); quit(0); }

    sc(NR_SETSID, 0, 0, 0, 0, 0);
    pid = do_fork();
    if (pid < 0) quit(3);
    if (pid > 0) quit(0);

    sc(NR_CHDIR, (long)"/", 0, 0, 0, 0);
    long nul = do_open("/dev/null", 2 /*O_RDWR*/, 0);
    long lf = do_open(log, 1 | 0100 | 02000 /*O_WRONLY|O_CREAT|O_APPEND*/, 0666);
    if (nul >= 0) do_dup2((int)nul, 0);
    if (lf < 0) lf = nul;
    if (lf >= 0) { do_dup2((int)lf, 1); do_dup2((int)lf, 2); }
    for (int i = 3; i < 256; i++) sc(NR_CLOSE, i, 0, 0, 0, 0);

    /* environment = inherited one, with CLASSPATH replaced */
    int n = 0;
    for (; envp[n] && n < 500; n++) {}
    int k = 0;
    for (int i = 0; i < n; i++) if (!starts(envp[i], "CLASSPATH=")) new_env[k++] = envp[i];
    char *cp = cp_buf;
    const char *pre = "CLASSPATH=";
    int o = 0;
    while (pre[o]) { cp[o] = pre[o]; o++; }
    for (int i = 0; apk[i] && o < 4090; i++) cp[o++] = apk[i];
    cp[o] = 0;
    new_env[k++] = cp;
    new_env[k] = 0;

    char *args[8];
    args[0] = (char *)"app_process";
    args[1] = (char *)"/system/bin";
    args[2] = (char *)"--nice-name=mykuzu_server";
    args[3] = (char *)"com.example.mykuzu.server.Server";
    args[4] = (char *)token;
    args[5] = (char *)csv;
    args[6] = 0;
    sc(NR_EXECVE, (long)exe, (long)args, (long)new_env, 0, 0);
    out(2, "aerostart: exec failed\n");
    quit(127);
}
