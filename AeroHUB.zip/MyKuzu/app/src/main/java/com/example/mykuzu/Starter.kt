package com.example.mykuzu

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import java.io.File
import java.io.IOException

/** All the ways to start the server, shared by the UI and the boot service. Functions block: call from a background thread. */
object Starter {
    private const val TLS_CONNECT = "_adb-tls-connect._tcp"
    private const val LOCAL = "127.0.0.1"

    fun msg(e: Throwable) = e.message ?: e.javaClass.simpleName

    /** Waits a few seconds for the freshly started server to answer. */
    fun waitRunning(c: Context): Boolean {
        repeat(10) {
            if (MyKuzu.ping(Store.token(c)) != null) return true
            Thread.sleep(500)
        }
        return false
    }

    private fun startVia(c: Context, host: String, port: Int) {
        val variants = if (File(Store.starterPath(c)).exists()) listOf(2, 0, 1) else listOf(0, 1)
        for (v in variants) {
            AdbMgr.runStart(c, host, port, v)
            if (waitRunning(c)) return
        }
        run {
            val local = runCatching { File(Store.logPath(c)).readText().takeLast(1500) }.getOrNull()
            val log = local?.takeIf { it.isNotBlank() } ?: AdbMgr.readServerLog(c, host, port)
            error("The start command was sent, but the server did not answer.\nadb said: ${AdbMgr.lastStartOut.ifEmpty { "(nothing)" }}\nServer log:\n$log")
        }
    }

    /** Wireless debugging: finds the connect port by itself (device must be paired already). */
    fun wirelessStart(c: Context): String {
        if (Build.VERSION.SDK_INT < 30) error("Wireless debugging needs Android 11 or newer")
        // If Wireless debugging was switched off, switch it back on ourselves (works once WRITE_SECURE_SETTINGS is granted).
        if (c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED) {
            runCatching { Settings.Global.putInt(c.contentResolver, "adb_wifi_enabled", 1) }
            Thread.sleep(1500)
        }
        val svc = Mdns.findLocal(c, TLS_CONNECT, 15)
            ?: error("Wireless debugging connection not found. Turn on Wireless debugging and connect to Wi-Fi.")
        var last: Throwable? = null
        for (h in listOf(LOCAL, svc.first).distinct()) {
            try { startVia(c, h, svc.second); return "Server started (Wireless)" } catch (e: Throwable) { last = e }
        }
        error(msg(last ?: IllegalStateException("failed")))
    }

    /** "USB debugging" start: connects to adbd's TCP port on this phone (needs ADB in TCP mode). */
    fun usbStart(c: Context): String {
        val tried = mutableListOf<String>()
        for (p in linkedSetOf(Store.tcpPort(c), 5555)) {
            if (!AdbMgr.reachable(LOCAL, p)) { tried.add("port $p: closed"); continue }
            try {
                startVia(c, LOCAL, p)
                Store.setTcpPort(c, p)
                return "Server started (USB debugging, port $p)"
            } catch (e: Throwable) { tried.add("port $p: ${msg(e)}") }
        }
        error("USB debugging connection not found.\n" + tried.joinToString("\n") +
            "\nSwitch ADB to TCP once: pair in the Wireless tab, then TCP tab -> Enable TCP via Wireless.")
    }

    /** Tries TCP first (saved port, then 5555), then Wireless debugging. */
    fun auto(c: Context): String {
        val tried = mutableListOf<String>()
        for (p in linkedSetOf(Store.tcpPort(c), 5555)) {
            if (!AdbMgr.reachable(LOCAL, p)) { tried.add("TCP $p: closed"); continue }
            try {
                startVia(c, LOCAL, p)
                Store.setTcpPort(c, p)
                return "Server started (TCP $p)"
            } catch (e: Throwable) { tried.add("TCP $p: ${msg(e)}") }
        }
        try { return wirelessStart(c) } catch (e: Throwable) { tried.add("Wireless: ${msg(e)}") }
        return "Could not start the server. [build 10 conscrypt]\n" + tried.joinToString("\n")
    }

    /** Switches adbd to TCP mode from the phone itself, no computer needed (needs a paired Wireless debugging connection). */
    fun enableTcp(c: Context, tcpPort: Int): String {
        if (AdbMgr.reachable(LOCAL, tcpPort)) { Store.setTcpPort(c, tcpPort); return "TCP is already on (port $tcpPort). Press Connect & Start." }
        if (Build.VERSION.SDK_INT < 30) error("Enabling TCP from the phone needs Android 11 or newer")
        val svc = Mdns.findLocal(c, TLS_CONNECT, 10)
            ?: error("Wireless debugging not found. Turn it on, connect to Wi-Fi and pair first (Wireless tab).")
        var last: Throwable? = null
        var sent = false
        for (h in listOf(LOCAL, svc.first).distinct()) {
            try { AdbMgr.enableTcp(c, h, svc.second, tcpPort); sent = true; break } catch (e: Throwable) { last = e }
        }
        if (!sent) error(msg(last ?: IllegalStateException("failed")))
        repeat(40) {
            if (AdbMgr.reachable(LOCAL, tcpPort, 500)) { Store.setTcpPort(c, tcpPort); return "TCP enabled on port $tcpPort. Now press Connect & Start." }
            Thread.sleep(500)
        }
        error("adbd did not open port $tcpPort. Try again.")
    }

    /** Used after a reboot: turns Wireless debugging on if allowed, then keeps trying for about 2 minutes. */
    fun boot(c: Context): String {
        if (c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED) {
            runCatching { Settings.Global.putInt(c.contentResolver, "adb_wifi_enabled", 1) }
        }
        var last = "Not started"
        repeat(12) {
            if (MyKuzu.ping(Store.token(c)) != null) return "AeroHUB server is running"
            last = auto(c)
            if (last.startsWith("Server started")) return last
            Thread.sleep(10_000)
        }
        return last
    }

    fun diagnose(c: Context): String {
        val sb = StringBuilder()
        sb.append("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
        val uid = MyKuzu.ping(Store.token(c))
        sb.append("Server: ").append(if (uid == null) "not running" else "running (UID $uid)").append("\n")
        var tcpOpen = false
        for (p in linkedSetOf(Store.tcpPort(c), 5555)) {
            val open = AdbMgr.reachable(LOCAL, p, 1500)
            if (open) tcpOpen = true
            sb.append("TCP $p: ").append(if (open) "open" else "closed").append("\n")
        }
        var wifiFound = false
        if (Build.VERSION.SDK_INT >= 30) {
            val svc = Mdns.findLocal(c, TLS_CONNECT, 6)
            wifiFound = svc != null
            sb.append("Wireless debugging: ").append(if (svc == null) "not found (off, or no Wi-Fi)" else "found, port ${svc.second}").append("\n")
        } else sb.append("Wireless debugging: needs Android 11+\n")
        if (AdbMgr.lastDetail.isNotEmpty()) sb.append("Last error detail:\n").append(AdbMgr.lastDetail).append("\n")
        sb.append("ADB key: ").append(if (File(c.filesDir, "adb_key").exists()) "created" else "not created yet").append("\n")
        sb.append("Start on boot: ").append(if (Store.autoStart(c)) "on" else "off").append("\n")
        sb.append("Secure settings access: ").append(
            if (c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED) "granted" else "not granted"
        ).append("\n\n")
        sb.append(when {
            uid != null -> "Everything is fine: the server is running."
            tcpOpen -> "TCP is open. Press Auto start or Connect & Start. If it fails, accept the \"Allow USB debugging?\" dialog."
            wifiFound -> "Wireless debugging is available. Pair once (Wireless tab), then use \"Enable TCP via Wireless\" or Auto start."
            else -> "No connection found. Turn on Wireless debugging (Wi-Fi needed) and pair in the Wireless tab."
        })
        return sb.toString()
    }
}
