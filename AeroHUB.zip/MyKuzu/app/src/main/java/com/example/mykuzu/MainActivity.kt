package com.example.mykuzu

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private val PRIMARY = 0xFF4F46E5.toInt()
    private val SOFT = 0xFFEEF0FF.toInt()
    private val BG = 0xFFF5F6FA.toInt()
    private val INK = 0xFF111827.toInt()
    private val MUTED = 0xFF6B7280.toInt()
    private val LINE = 0xFFE5E7EB.toInt()
    private val OK = 0xFF16A34A.toInt()
    private val BAD = 0xFFDC2626.toInt()

    private lateinit var dot: View
    private lateinit var statusT: TextView
    private lateinit var subT: TextView
    private lateinit var msgT: TextView
    private lateinit var stopBtn: Button
    private lateinit var hero: LinearLayout
    private lateinit var appsBox: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var out: TextView
    private val chips = mutableListOf<Button>()
    private val shizukuPerm = Shizuku.OnRequestPermissionResultListener { code, result ->
        if (code == ShizukuHelper.REQ) runOnUiThread {
            msgT.text = if (result == PackageManager.PERMISSION_GRANTED) "Shizuku permission granted" else "Shizuku permission denied"
            if (method == 4) buildPanel()
        }
    }
    private val shizukuBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { if (method == 4) buildPanel() } }
    private val names = listOf("Wireless", "TCP", "Root", "PC", "Shizuku")
    private var method = 0

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(fill: Int, stroke: Int? = null, r: Int = 14) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat(); setColor(fill); if (stroke != null) setStroke(dp(1), stroke)
    }
    private fun heroBg(running: Boolean) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        if (running) intArrayOf(0xFF047857.toInt(), 0xFF10B981.toInt()) else intArrayOf(0xFF4338CA.toInt(), 0xFF7C3AED.toInt())
    ).apply { cornerRadius = dp(22).toFloat() }
    private fun oval(c: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
    private fun label(s: String, size: Float = 14f, color: Int = INK, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun btn(s: String, primary: Boolean = true, onClick: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; stateListAnimator = null; textSize = 15f
        setTextColor(if (primary) Color.WHITE else PRIMARY)
        background = rounded(if (primary) PRIMARY else SOFT, null, 12)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) }
    }
    private fun field(hint: String, def: String = "", num: Boolean = false) = EditText(this).apply {
        this.hint = hint; setText(def); textSize = 15f; setSingleLine()
        setPadding(dp(12), 0, dp(12), 0); background = rounded(Color.WHITE, LINE, 10)
        if (num) inputType = InputType.TYPE_CLASS_NUMBER
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) }
    }
    private fun card(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(18), dp(18), dp(18))
        background = rounded(Color.WHITE, LINE, 18)
        elevation = dp(2).toFloat()
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
        v.forEach { addView(it) }
    }
    private fun step(n: Int, t: String, vararg extra: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) }
        if (n > 1) addView(View(this@MainActivity).apply {
            setBackgroundColor(LINE)
            layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { bottomMargin = dp(18) }
        })
        addView(LinearLayout(this@MainActivity).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = "$n"; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 12f
                background = oval(PRIMARY)
                layoutParams = LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(10) }
            })
            addView(label(t, 15f, INK, true))
        })
        extra.forEach { addView(it) }
    }
    private fun hint(s: String) = label(s, 13f, MUTED).apply { setPadding(0, dp(6), 0, 0) }
    private fun code(s: String) = label(s, 12f, INK).apply {
        typeface = Typeface.MONOSPACE; setTextIsSelectable(true)
        setPadding(dp(12), dp(12), dp(12), dp(12)); background = rounded(BG, null, 10)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
    }
    private fun copy(s: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("cmd", s))
        toast("Copied")
    }

    private fun sw(on: Boolean, f: (Boolean) -> Unit) = Switch(this).apply {
        isChecked = on
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        thumbTintList = ColorStateList(st, intArrayOf(PRIMARY, 0xFFF9FAFB.toInt()))
        trackTintList = ColorStateList(st, intArrayOf(0x804F46E5.toInt(), 0xFFD1D5DB.toInt()))
        setOnCheckedChangeListener { _, b -> f(b) }
    }

    private fun script() = Store.script(this)
    private fun pcCmd() = "adb shell sh ${script().absolutePath}"

    // ---------- UI ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(36), dp(18), dp(32)) }
        val logo = TextView(this).apply {
            text = "K"; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 20f; setTypeface(null, Typeface.BOLD)
            background = rounded(PRIMARY, null, 12)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(12) }
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(label("MyKuzu", 22f, INK, true))
            addView(label("Run commands with elevated access", 13f, MUTED))
        }
        col.addView(LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; addView(logo); addView(titles) })

        // Status hero
        dot = View(this).apply { background = oval(Color.WHITE); layoutParams = LinearLayout.LayoutParams(dp(12), dp(12)).apply { marginEnd = dp(10) } }
        statusT = label("Checking…", 24f, Color.WHITE, true)
        subT = label("", 14f, 0xDDFFFFFF.toInt()).apply { setPadding(0, dp(6), 0, 0) }
        msgT = label("", 13f, Color.WHITE).apply { setPadding(0, dp(8), 0, 0) }
        stopBtn = btn("Stop server", false) {
            Thread { MyKuzu.stop(Store.token(this)); Thread.sleep(500); refresh() }.start()
        }.apply { background = rounded(Color.WHITE, null, 12) }
        hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(22))
            background = heroBg(false); elevation = dp(4).toFloat()
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) }
            addView(LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL; addView(dot); addView(statusT) })
            addView(subT); addView(msgT); addView(stopBtn)
        }
        col.addView(hero)

        // App access (one place to switch apps on/off)
        appsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                addView(label("App access", 17f, INK, true))
                addView(hint("Allow or block apps in one place."))
            })
            addView(sw(Store.masterOn(this@MainActivity)) {
                Store.setMasterOn(this@MainActivity, it); Store.push(this@MainActivity)
                msgT.text = if (it) "App access enabled" else "All apps are blocked"
            })
        }
        col.addView(card(head, appsBox))

        // Start methods
        val seg = LinearLayout(this).apply {
            background = rounded(0xFFEDEFF5.toInt(), null, 14); setPadding(dp(4), dp(4), dp(4), dp(4))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
        }
        names.forEachIndexed { i, n ->
            val c = Button(this).apply {
                text = n; isAllCaps = false; stateListAnimator = null; textSize = 13f
                minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0; setPadding(0, 0, 0, 0)
                setOnClickListener { method = i; styleChips(); buildPanel() }
                layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f)
            }
            chips.add(c); seg.addView(c)
        }
        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(card(
            label("Start the server", 17f, INK, true),
            hint("Pick one method and follow the steps."),
            seg, panel
        ))
        styleChips(); buildPanel()
        col.addView(buildTools())

        // Test area (collapsed)
        val cmd = field("Shell command", "id")
        out = label("", 12f, INK).apply { typeface = Typeface.MONOSPACE; setTextIsSelectable(true); setPadding(0, dp(10), 0, 0) }
        val test = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            addView(cmd)
            addView(btn("Run") {
                val c = cmd.text.toString()
                Thread {
                    val r = try { MyKuzu.exec(Store.token(this@MainActivity), c).let { "exit ${it.first}\n${it.second}" } } catch (e: Exception) { "Error: ${e.message}" }
                    runOnUiThread { out.text = r }
                }.start()
            })
            addView(out)
        }
        val toggle = label("Terminal  ›", 14f, PRIMARY, true).apply {
            setPadding(dp(4), dp(20), dp(4), dp(8))
            setOnClickListener { test.visibility = if (test.visibility == View.GONE) View.VISIBLE else View.GONE }
        }
        col.addView(toggle); col.addView(test)
        col.addView(label("MyKuzu 1.1", 12f, MUTED).apply { gravity = Gravity.CENTER; setPadding(0, dp(28), 0, 0) })

        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(col) })
        Shizuku.addRequestPermissionResultListener(shizukuPerm)
        Shizuku.addBinderReceivedListenerSticky(shizukuBinder)
        prepare(); refresh()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(shizukuPerm)
        Shizuku.removeBinderReceivedListener(shizukuBinder)
        super.onDestroy()
    }

    private fun styleChips() = chips.forEachIndexed { i, b ->
        val on = i == method
        b.setTextColor(if (on) PRIMARY else MUTED)
        b.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
        b.background = rounded(if (on) Color.WHITE else Color.TRANSPARENT, null, 11)
    }

    private fun buildPanel() {
        panel.removeAllViews()
        when (method) {
            0 -> { // Wireless debugging
                val pairPort = field("Pairing port", "", true)
                val pairCode = field("Pairing code", "", true)
                val connPort = field("Connection port", "", true)
                panel.addView(step(1, "Turn on Wireless debugging",
                    hint("Connect to Wi-Fi, then enable Wireless debugging in Developer options."),
                    btn("Open Developer options", false) {
                        try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) } catch (e: Exception) { toast("Open Settings manually") }
                    }))
                panel.addView(step(2, "Pair using a notification",
                    hint("Press Start, then tap \"Pair device with pairing code\" in Settings. Type the code into the MyKuzu notification. The server starts automatically."),
                    btn("Start pairing") { startPairing() }))
                val manual = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; visibility = View.GONE
                    addView(pairPort); addView(pairCode)
                    addView(btn("Pair device", false) {
                        val pp = pairPort.text.toString().toIntOrNull(); val c = pairCode.text.toString()
                        if (pp == null || c.isEmpty()) toast("Enter the pairing port and code") else work("Pairing…") {
                            if (Build.VERSION.SDK_INT < 30) error("Wireless debugging needs Android 11 or newer")
                            if (!AdbMgr.get(this@MainActivity).pair("127.0.0.1", pp, c)) error("Pairing failed. Check the port and code")
                            "Paired. Now enter the connection port"
                        }
                    })
                    addView(connPort)
                    addView(btn("Connect & Start", false) {
                        val p = connPort.text.toString().toIntOrNull()
                        if (p == null) toast("Enter the connection port") else adbStart("127.0.0.1", p)
                    })
                }
                panel.addView(label("Enter port and code manually  ›", 14f, PRIMARY, true).apply {
                    setPadding(dp(4), dp(20), dp(4), dp(4))
                    setOnClickListener { manual.visibility = if (manual.visibility == View.GONE) View.VISIBLE else View.GONE }
                })
                panel.addView(manual)
            }
            1 -> { // ADB over TCP
                val tcpPort = field("Port", "5555", true)
                panel.addView(step(1, "Enable TCP on a computer",
                    hint("Connect the phone with USB debugging, then run:"), code("adb tcpip 5555")))
                panel.addView(step(2, "Connect and start", tcpPort,
                    btn("Connect & Start") { adbStart("127.0.0.1", tcpPort.text.toString().toIntOrNull() ?: 5555) }))
            }
            2 -> { // Root
                panel.addView(step(1, "Start with root",
                    hint("Grant superuser access when asked."),
                    btn("Start with root") {
                        work("Requesting root…") {
                            prepare()
                            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "sh ${script().absolutePath}"))
                            val c = p.waitFor(); Thread.sleep(1000)
                            if (c == 0) "Root start requested" else "Root denied or unavailable (exit $c)"
                        }
                    }))
            }
            3 -> { // Computer
                panel.addView(step(1, "Connect your phone",
                    hint("Enable USB debugging and connect the phone to your computer.")))
                panel.addView(step(2, "Run this command", code(pcCmd()), btn("Copy command", false) { copy(pcCmd()) }))
            }
            else -> { // Shizuku
                val st = hint(ShizukuHelper.status())
                panel.addView(step(1, "Start Shizuku",
                    hint("Install the Shizuku app and start it (wireless debugging or root).")))
                panel.addView(step(2, "Allow MyKuzu", st,
                    btn("Request Shizuku permission") { st.text = ShizukuHelper.request(this) }))
            }
        }
    }

    // ---------- System tools ----------
    private lateinit var toolOut: TextView

    private fun half(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; stateListAnimator = null; textSize = 13f
        minWidth = 0; minimumWidth = 0; setPadding(dp(4), 0, dp(4), 0)
        setTextColor(PRIMARY); background = rounded(SOFT, null, 12)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(3); marginEnd = dp(3) }
    }
    private fun rowOf(vararg b: View) = LinearLayout(this).apply {
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        b.forEach { addView(it) }
    }
    private fun sub(s: String) = label(s, 14f, INK, true).apply { setPadding(0, dp(20), 0, 0) }
    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"
    private fun confirm(msg: String, go: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg)
            .setPositiveButton("Continue") { _, _ -> go() }.setNegativeButton("Cancel", null).show()
    }
    private fun sys(ok: String, cmd: String) {
        toolOut.text = "Running…"
        Thread {
            val r = try {
                val (code, o) = MyKuzu.exec(Store.token(this), cmd)
                (if (code == 0) "✓ $ok" else "Exit code $code") + (if (o.isNotBlank()) "\n" + o.trim() else "")
            } catch (e: Exception) { "Start the server first (${e.message})" }
            runOnUiThread { toolOut.text = r }
        }.start()
    }

    private fun buildTools(): LinearLayout {
        val pkgF = field("Package name, e.g. com.example.app")
        val permF = field("Permission, e.g. android.permission.WRITE_SECURE_SETTINGS")
        val dpiF = field("Screen density (DPI)", "", true)
        val nsF = field("Namespace: global, secure or system", "global")
        val keyF = field("Setting key")
        val valF = field("Value")
        toolOut = label("", 12f, INK).apply { typeface = Typeface.MONOSPACE; setTextIsSelectable(true); setPadding(0, dp(12), 0, 0) }
        fun pkg(): String? { val v = pkgF.text.toString().trim(); if (v.isEmpty()) { toast("Enter a package name"); return null }; return v }
        fun perm(): String? { val v = permF.text.toString().trim(); if (v.isEmpty()) { toast("Enter a permission"); return null }; return v }
        val anim = "window_animation_scale transition_animation_scale animator_duration_scale"
        return card(
            label("System tools", 17f, INK, true),
            hint("Needs the server running. ADB shell covers most of these; root can do more."),
            sub("Device"),
            rowOf(
                half("Device info") { sys("Device info", "echo Model: \$(getprop ro.product.model); echo Android: \$(getprop ro.build.version.release) (API \$(getprop ro.build.version.sdk)); echo CPU: \$(getprop ro.product.cpu.abi); id") },
                half("Screenshot") { sys("Saved to Pictures", "mkdir -p /sdcard/Pictures; screencap -p /sdcard/Pictures/mykuzu_\$(date +%s).png") }
            ),
            rowOf(
                half("Animations off") { sys("Animations off", anim.split(" ").joinToString("; ") { "settings put global $it 0" }) },
                half("Animations on") { sys("Animations on", anim.split(" ").joinToString("; ") { "settings put global $it 1" }) }
            ),
            rowOf(half("Reboot device") { confirm("Reboot the device now?") { sys("Rebooting", "svc power reboot") } }),
            sub("Apps"), pkgF,
            rowOf(
                half("Force stop") { pkg()?.let { sys("Stopped", "am force-stop ${q(it)}") } },
                half("Clear data") { pkg()?.let { p -> confirm("Delete all data of $p?") { sys("Data cleared", "pm clear ${q(p)}") } } }
            ),
            rowOf(
                half("Disable") { pkg()?.let { sys("Disabled", "pm disable-user --user 0 ${q(it)}") } },
                half("Enable") { pkg()?.let { sys("Enabled", "pm enable ${q(it)}") } }
            ),
            rowOf(half("Uninstall (current user)") { pkg()?.let { p -> confirm("Uninstall $p for the current user?") { sys("Uninstalled", "pm uninstall --user 0 ${q(p)}") } } }),
            permF,
            rowOf(
                half("Grant permission") { val p = pkg(); val x = perm(); if (p != null && x != null) sys("Granted", "pm grant ${q(p)} ${q(x)}") },
                half("Revoke permission") { val p = pkg(); val x = perm(); if (p != null && x != null) sys("Revoked", "pm revoke ${q(p)} ${q(x)}") }
            ),
            sub("Display"), dpiF,
            rowOf(
                half("Set DPI") { val d = dpiF.text.toString().toIntOrNull(); if (d == null) toast("Enter a DPI number") else sys("DPI set", "wm density $d") },
                half("Reset DPI") { sys("DPI reset", "wm density reset") }
            ),
            sub("System settings"), nsF, keyF, valF,
            rowOf(
                half("Read") { sys("Value", "settings get ${q(nsF.text.toString().trim())} ${q(keyF.text.toString().trim())}") },
                half("Write") { confirm("Change this system setting?") { sys("Saved", "settings put ${q(nsF.text.toString().trim())} ${q(keyF.text.toString().trim())} ${q(valF.text.toString())}") } }
            ),
            toolOut
        )
    }

    // ---------- logic ----------
    private fun startPairing() {
        if (Build.VERSION.SDK_INT < 30) { toast("Wireless debugging needs Android 11 or newer"); return }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7); return
        }
        startForegroundService(Intent(this, PairingService::class.java).setAction(PairingService.ACTION_START))
        msgT.text = "Pairing started. Check your notifications."
        toast("Now tap \"Pair device with pairing code\" in Wireless debugging")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startPairing()
            else toast("Allow notifications to enter the pairing code there")
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun work(label: String, block: () -> String) {
        msgT.text = label
        Thread {
            val r = try { block() } catch (e: Throwable) { "Failed: ${e.message ?: e.javaClass.simpleName}" }
            runOnUiThread { msgT.text = r }
            refresh()
        }.start()
    }

    private fun adbStart(host: String, port: Int) = work("Connecting to $host:$port…") {
        AdbMgr.runStart(this, host, port)
        Thread.sleep(1200)
        "Start command sent"
    }

    private fun prepare() = Store.writeScript(this)

    private fun buildApps() {
        appsBox.removeAllViews()
        val gs = Store.grants(this)
        if (gs.isEmpty()) { appsBox.addView(hint("No apps yet. Apps that ask for access will appear here.")); return }
        gs.forEach { g ->
            val name = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(g.pkg, 0)).toString() } catch (e: Exception) { g.pkg }
            appsBox.addView(LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(14), 0, 0)
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    addView(label(name, 15f, INK, true)); addView(label(g.pkg, 12f, MUTED))
                })
                addView(sw(g.enabled) { Store.setEnabled(this@MainActivity, g.pkg, it); Store.push(this@MainActivity) })
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity).setTitle("Remove $name?")
                        .setMessage("It will lose access and must ask again.")
                        .setPositiveButton("Remove") { _, _ -> Store.remove(this@MainActivity, g.pkg); Store.push(this@MainActivity); buildApps() }
                        .setNegativeButton("Cancel", null).show()
                    true
                }
            })
        }
        appsBox.addView(hint("Long-press an app to remove it."))
    }

    private val poll = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { refresh(); poll.postDelayed(this, 3000) } }
    override fun onResume() { super.onResume(); buildApps(); poll.post(tick) }
    override fun onPause() { poll.removeCallbacks(tick); super.onPause() }

    private fun refresh() {
        Thread {
            val uid = MyKuzu.ping(Store.token(this))
            if (uid != null) runCatching { MyKuzu.sync(Store.token(this), Store.activeTokens(this)) }
            runOnUiThread {
                hero.background = heroBg(uid != null)
                statusT.text = if (uid == null) "Not running" else "Running"
                subT.text = when (uid) {
                    null -> "Choose a method below to start it."
                    0 -> "Running as root"
                    2000 -> "Running as ADB shell"
                    else -> "Running as UID $uid"
                }
                stopBtn.visibility = if (uid == null) View.GONE else View.VISIBLE
            }
        }.start()
    }
}
