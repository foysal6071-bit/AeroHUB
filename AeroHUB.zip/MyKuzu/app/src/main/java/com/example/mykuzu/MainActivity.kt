package com.example.mykuzu

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.example.mykuzu.server.Server

class MainActivity : Activity() {
    // ---------- palette (set by applyTheme: 0 = Light, 1 = Dark, 2 = AMOLED black) ----------
    private var PRIMARY = 0; private var ACCENT = 0; private var BG = 0; private var CARD = 0; private var ROW = 0
    private var FIELD = 0; private var SOFT = 0; private var LINE = 0; private var INK = 0; private var MUTED = 0
    private var NAV = 0; private var TRACK = 0; private var PRESS = 0
    private var themeMode = 0
    private val GREEN = 0xFF34C759.toInt()

    private fun applyTheme() {
        themeMode = getSharedPreferences("aerohub_tools", Context.MODE_PRIVATE).getInt("theme", 0)
        when (themeMode) {
            1 -> { // Dark
                PRIMARY = 0xFF0A84FF.toInt(); ACCENT = 0xFF0A84FF.toInt(); BG = 0xFF1C1C1E.toInt(); CARD = 0xFF2C2C2E.toInt()
                ROW = CARD; FIELD = 0xFF3A3A3C.toInt(); SOFT = 0x330A84FF; LINE = 0xFF3A3A3C.toInt()
                INK = 0xFFFFFFFF.toInt(); MUTED = 0xFF98989D.toInt(); NAV = 0xFF242426.toInt(); TRACK = 0xFF48484A.toInt(); PRESS = 0x22FFFFFF
            }
            2 -> { // AMOLED black
                PRIMARY = 0xFF0A84FF.toInt(); ACCENT = 0xFF0A84FF.toInt(); BG = 0xFF000000.toInt(); CARD = 0xFF121214.toInt()
                ROW = CARD; FIELD = 0xFF1C1C1E.toInt(); SOFT = 0x330A84FF; LINE = 0xFF2A2A2C.toInt()
                INK = 0xFFFFFFFF.toInt(); MUTED = 0xFF8E8E93.toInt(); NAV = 0xFF000000.toInt(); TRACK = 0xFF39393D.toInt(); PRESS = 0x22FFFFFF
            }
            else -> { // Light
                PRIMARY = 0xFF007AFF.toInt(); ACCENT = 0xFF007AFF.toInt(); BG = 0xFFF2F2F7.toInt(); CARD = 0xFFFFFFFF.toInt()
                ROW = CARD; FIELD = 0xFFF2F2F7.toInt(); SOFT = 0x1A007AFF; LINE = 0xFFE5E5EA.toInt()
                INK = 0xFF000000.toInt(); MUTED = 0xFF8E8E93.toInt(); NAV = 0xFFF9F9F9.toInt(); TRACK = 0xFFE5E5EA.toInt(); PRESS = 0x11000000
            }
        }
    }

    // connection tab
    private lateinit var dot: View
    private lateinit var statusT: TextView
    private lateinit var subT: TextView
    private lateinit var msgT: TextView
    private lateinit var stopBtn: Button
    private lateinit var pillsT: TextView
    private lateinit var methodsBox: LinearLayout
    private lateinit var methodsArrow: TextView
    private var methodsInit = false
    private lateinit var autoBtn: Button
    private lateinit var startBtn: Button
    private lateinit var startRow: LinearLayout
    private lateinit var restartBtn: Button
    private lateinit var hero: LinearLayout
    private lateinit var appsBox: LinearLayout
    private lateinit var panel: LinearLayout
    private val chips = mutableListOf<Button>()
    private val appChips = mutableListOf<Button>()   // Apps tab: Installed / System
    private var appsFilter = 0                       // 0 = Installed, 1 = System
    private val names = listOf("Wireless", "TCP", "USB")
    private var method = 0

    // shell / tabs
    private lateinit var content: FrameLayout
    private lateinit var connectPage: View
    private lateinit var toolsHost: FrameLayout
    private lateinit var appsPage: View
    private val navBtns = mutableListOf<LinearLayout>()
    private var tab = 0

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(fill: Int, stroke: Int? = null, r: Int = 14) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat(); setColor(fill); if (stroke != null) setStroke(dp(1), stroke)
    }
    private fun heroBg(running: Boolean) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        if (running) intArrayOf(GREEN, GREEN) else intArrayOf(ACCENT, ACCENT)
    ).apply { cornerRadius = dp(18).toFloat() }
    private fun oval(c: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
    /** SVG-style vector icon, tinted with [tint]. */
    private fun icon(res: Int, sizeDp: Int = 22, tint: Int = Color.WHITE) = ImageView(this).apply {
        setImageResource(res); setColorFilter(tint)
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

    private fun label(s: String, size: Float = 14f, color: Int = INK, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun btn(s: String, primary: Boolean = true, onClick: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; stateListAnimator = null; textSize = 15f
        setTextColor(if (primary) Color.WHITE else ACCENT)
        background = rounded(if (primary) PRIMARY else SOFT, null, 14)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) }
    }
    private fun field(hint: String, def: String = "", num: Boolean = false) = EditText(this).apply {
        this.hint = hint; setText(def); textSize = 15f; setSingleLine()
        setTextColor(INK); setHintTextColor(MUTED)
        setPadding(dp(12), 0, dp(12), 0); background = rounded(FIELD, LINE, 10)
        if (num) inputType = InputType.TYPE_CLASS_NUMBER
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) }
    }
    private fun card(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(18), dp(18), dp(18))
        background = rounded(CARD, LINE, 18)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
        v.forEach { addView(it) }
    }
    private fun step(n: Int, t: String, vararg extra: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) }
        if (n > 1) addView(View(this@MainActivity).apply {
            setBackgroundColor(LINE)
            layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { bottomMargin = dp(18) }
        })
        addView(LinearLayout(this@MainActivity).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = "$n"; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 12f
                background = oval(PRIMARY)
                layoutParams = LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(10) }
            })
            addView(label(t, 15f, INK, true))
        })
        extra.forEach { addView(it) }
    }
    private fun divider() = View(this).apply { setBackgroundColor(LINE); layoutParams = LinearLayout.LayoutParams(-1, 1) }
    private fun switchRow(title: String, desc: String, on: Boolean, f: (Boolean) -> Unit) = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(12))
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(12) }
            addView(label(title, 15f, INK, true)); addView(hint(desc))
        })
        addView(sw(on, f))
    }
    private fun setMethodsOpen(open: Boolean) {
        methodsBox.visibility = if (open) View.VISIBLE else View.GONE
        methodsArrow.text = if (open) "▴" else "▾"
    }
    private fun hint(s: String) = label(s, 13f, MUTED).apply { setPadding(0, dp(6), 0, 0) }
    private fun code(s: String) = label(s, 12f, INK).apply {
        typeface = Typeface.MONOSPACE; setTextIsSelectable(true)
        setPadding(dp(12), dp(12), dp(12), dp(12)); background = rounded(FIELD, null, 10)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
    }
    private fun copy(s: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("text", s))
        toast("Copied")
    }
    private fun sw(on: Boolean, f: (Boolean) -> Unit) = Switch(this).apply {
        isChecked = on
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        thumbTintList = ColorStateList(st, intArrayOf(Color.WHITE, Color.WHITE))
        trackTintList = ColorStateList(st, intArrayOf(GREEN, TRACK))
        setOnCheckedChangeListener { _, b -> f(b) }
    }
    private fun half(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; stateListAnimator = null; textSize = 13f
        minWidth = 0; minimumWidth = 0; setPadding(dp(4), 0, dp(4), 0)
        setTextColor(ACCENT); background = rounded(SOFT, null, 12)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(3); marginEnd = dp(3) }
    }
    private fun rowOf(vararg b: View) = LinearLayout(this).apply {
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        b.forEach { addView(it) }
    }
    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"
    private fun confirm(msg: String, go: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg)
            .setPositiveButton("Continue") { _, _ -> go() }.setNegativeButton("Cancel", null).show()
    }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    // ---------- shell: pages + bottom bar ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        applyTheme()
        if (themeMode != 0) setTheme(android.R.style.Theme_DeviceDefault_NoActionBar)
        super.onCreate(savedInstanceState)
        // Status bar and navigation bar stay visible but transparent; the app draws behind them and pads itself by the insets.
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) { window.isNavigationBarContrastEnforced = false; window.isStatusBarContrastEnforced = false }
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or   // lays out behind the bar; does NOT hide it
            (if (themeMode != 0) 0 else
                android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                (if (Build.VERSION.SDK_INT >= 26) android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0))
        content = FrameLayout(this)
        toolsHost = FrameLayout(this)
        connectPage = buildConnect()
        appsPage = buildAppsPage()
        showToolsList()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(BG)
            addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
            navBar = buildNav()
            addView(navBar)
        }
        host = FrameLayout(this).apply { addView(root, FrameLayout.LayoutParams(-1, -1)) }
        @Suppress("DEPRECATION")
        host.setOnApplyWindowInsetsListener { _, ins ->
            val top = ins.systemWindowInsetTop
            val total = ins.systemWindowInsetBottom
            val stable = ins.stableInsetBottom
            val imeUp = total > stable                       // keyboard is open
            insetTop = top; insetBottom = stable
            root.setPadding(0, top, 0, if (imeUp) total else 0)
            navInner.setPadding(0, dp(6), 0, dp(6) + if (imeUp) 0 else stable)   // bottom tabs reach down behind the transparent bar
            gateView?.let { g -> (g as? ScrollView)?.getChildAt(0)?.setPadding(dp(22), dp(32) + top, dp(22), dp(24) + stable) }
            ins
        }
        setContentView(host)
        showTab(0)
        refresh()
    }

    // ---------- setup gate: USB debugging + notifications + keyboard ----------
    private lateinit var host: FrameLayout
    private lateinit var navBar: View
    private lateinit var navInner: LinearLayout
    private var insetTop = 0
    private var insetBottom = 0
    private var gateView: View? = null
    private var notifAsked = false

    /** USB debugging switch in Developer options (readable without any permission). */
    private fun adbOk() = try {
        Settings.Global.getInt(contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
    } catch (e: Exception) { false }

    private fun devOptionsOn() = try {
        Settings.Global.getInt(contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
    } catch (e: Exception) { false }

    private fun notifOk() = Build.VERSION.SDK_INT < 33 ||
        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    /** Phone makers (Xiaomi, Oppo, Vivo, Huawei...) have their own "Auto start" switch that Android cannot read, so it counts as done once the user has opened it. */
    private fun autoStartOk() = getSharedPreferences("mk", MODE_PRIVATE).getBoolean("autostart_opened", false)

    private fun openAutoStartSettings() {
        getSharedPreferences("mk", MODE_PRIVATE).edit().putBoolean("autostart_opened", true).apply()
        val targets = listOf(
            "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.startupapp.StartupAppListActivity",
            "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
            "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.optimize.process.ProtectActivity",
            "com.oneplus.security" to "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity",
            "com.asus.mobilemanager" to "com.asus.mobilemanager.autostart.AutoStartActivity",
            "com.samsung.android.lool" to "com.samsung.android.sm.ui.battery.BatteryActivity"
        )
        for ((pkg, cls) in targets) {
            try { startActivity(Intent().setClassName(pkg, cls)); return } catch (e: Exception) { /* not this phone, try the next */ }
        }
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName"))) }
        catch (e: Exception) { toast("Open Settings > Apps > AeroHUB and allow auto start / background activity") }
    }

    private fun batOk() = try {
        getSystemService(android.os.PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
    } catch (e: Exception) { true }

    private fun imeOk() = try {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
            .enabledInputMethodList.any { it.packageName == packageName }
    } catch (e: Exception) { false }

    /**
     * Shows a full-screen setup page that covers the whole app until all five are done:
     * USB debugging is on, notifications are allowed, and battery optimisation is off for AeroHUB.
     * It is re-checked on every onResume, so turning one off later brings the page back.
     */
    /** Items the setup page already asked for by itself in this run (each is auto-opened once; after that the user taps the button). */
    private val gateAsked = HashSet<String>()

    /** [auto] = true from onResume: the setup page then opens the next missing permission by itself, one after another. */
    private fun updateGate(auto: Boolean = false) {
        gateView?.let { host.removeView(it); gateView = null }
        val d = devOptionsOn(); val a = adbOk(); val n = notifOk(); val b = batOk(); val au = autoStartOk()
        if (d && a && n && b && au) return
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(BG)
            setPadding(dp(22), dp(32) + insetTop, dp(22), dp(24) + insetBottom)
        }
        val done = listOf(d, a, n, b, au).count { it }
        col.addView(label("Almost ready", 26f, INK, true))
        col.addView(label("$done of 5 done. Turn on the rest to open AeroHUB.", 14f, MUTED).apply { setPadding(0, dp(8), 0, dp(28)) })
        // One compact line per item: status icon, name + short hint, and a button only if it is still missing.
        val pending = linkedMapOf<String, () -> Unit>()
        fun row(ok: Boolean, title: String, desc: String, action: String, go: () -> Unit) {
            if (!ok) pending[title] = go
            col.addView(LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(CARD, null, 16)
                setPadding(dp(16), dp(14), dp(12), dp(14))
                addView(icon(if (ok) R.drawable.ic_check else R.drawable.ic_circle, 24, if (ok) GREEN else MUTED).apply {
                    (layoutParams as LinearLayout.LayoutParams).marginEnd = dp(14)
                })
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    addView(label(title, 16f, INK, true))
                    addView(label(desc, 12f, MUTED).apply { setPadding(0, dp(2), 0, 0) })
                })
                if (!ok) addView(Button(this@MainActivity).apply {
                    text = action; isAllCaps = false; stateListAnimator = null; textSize = 14f
                    minWidth = 0; minimumWidth = 0; setTextColor(Color.WHITE)
                    setPadding(dp(18), 0, dp(18), 0); background = rounded(PRIMARY, null, 12)
                    setOnClickListener { go() }
                    layoutParams = LinearLayout.LayoutParams(-2, dp(42)).apply { marginStart = dp(8) }
                })
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        }
        row(d, "Developer options", "Tap \"Build number\" 7 times in About phone", "Turn on") {
            toast("Tap \"Build number\" 7 times, then come back")
            try { startActivity(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)) } catch (e: Exception) { toast("Open Settings > About phone") }
        }
        row(a, "USB debugging", "In Developer options", "Turn on") {
            if (devOptionsOn()) openDevSettings("enable_adb")
            else {
                toast("Developer options is off. Tap \"Build number\" 7 times in About phone, then turn on USB debugging.")
                try { startActivity(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)) } catch (e: Exception) { toast("Open Settings > About phone") }
            }
        }
        row(n, "Notifications", "For pairing and server status", "Allow") {
            if (notifAsked) {
                try {
                    startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
                } catch (e: Exception) { toast("Open Settings and allow notifications for AeroHUB") }
            } else {
                notifAsked = true
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 8)
            }
        }
        row(b, "Battery", "Run in background (keeps the server alive with the screen off)", "Allow") {
            try {
                @Suppress("BatteryLife")
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, android.net.Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { toast("Open Settings > Battery and set AeroHUB to Unrestricted") }
            }
        }
        row(au, "Auto start", "Let AeroHUB start by itself. Turn it on for AeroHUB, then come back", "Open") { openAutoStartSettings() }
        // ScrollView so the cards stay reachable on small screens / landscape; also swallows touches.
        val page = ScrollView(this).apply { setBackgroundColor(BG); isFillViewport = true; isClickable = true; addView(col) }
        gateView = page
        host.addView(page, FrameLayout.LayoutParams(-1, -1))
        if (auto) {
            val next = listOf("Notifications", "Battery", "Auto start", "Developer options", "USB debugging")
                .firstOrNull { it in pending && it !in gateAsked && (it != "USB debugging" || d) }
            if (next != null) { gateAsked.add(next); host.post { pending[next]?.invoke() } }
        }
    }

    private fun buildNav(): View {
        val items = listOf(R.drawable.ic_connect to "Connect", R.drawable.ic_tools to "Tools", R.drawable.ic_shield to "Apps")
        val bar = LinearLayout(this).apply { setBackgroundColor(NAV); setPadding(0, dp(6), 0, dp(6)) }
        navInner = bar
        items.forEachIndexed { i, item ->
            val b = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setPadding(0, dp(4), 0, dp(2))
                addView(icon(item.first, 24, MUTED))
                addView(label(item.second, 10f, MUTED).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, 0) })
                setOnClickListener { showTab(i) }
            }
            navBtns.add(b); bar.addView(b)
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(View(this@MainActivity).apply { setBackgroundColor(LINE); layoutParams = LinearLayout.LayoutParams(-1, 1) })
            addView(bar)
        }
    }

    private fun styleNav() = navBtns.forEachIndexed { i, b ->
        val c = if (i == tab) ACCENT else MUTED
        (b.getChildAt(1) as TextView).setTextColor(c)
        (b.getChildAt(0) as ImageView).setColorFilter(c)
    }

    private fun showTab(i: Int) {
        tab = i
        content.removeAllViews()
        content.addView(when (i) { 0 -> connectPage; 1 -> toolsHost; else -> appsPage }, FrameLayout.LayoutParams(-1, -1))
        styleNav()
    }

    // ---------- TAB 1: connection ----------
    private fun buildConnect(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(28), dp(18), dp(24)) }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.aerohub_logo); scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(12).toFloat()) }
            }
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(12) }
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(label("AeroHUB", 22f, INK, true))
            addView(label("Run commands with elevated access", 13f, MUTED))
        }
        col.addView(LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; addView(logo); addView(titles) })

        dot = View(this).apply { background = oval(Color.WHITE); layoutParams = LinearLayout.LayoutParams(dp(12), dp(12)).apply { marginEnd = dp(10) } }
        statusT = label("Checking…", 24f, Color.WHITE, true)
        subT = label("", 14f, 0xDDFFFFFF.toInt()).apply { setPadding(0, dp(6), 0, 0) }
        msgT = label("", 13f, Color.WHITE).apply { setPadding(0, dp(8), 0, 0) }
        pillsT = label("", 12f, 0xDDFFFFFF.toInt()).apply { setPadding(0, dp(12), 0, 0) }
        stopBtn = btn("Stop", false) {
            Store.userStopped(this); Thread { MyKuzu.stop(Store.token(this)); Thread.sleep(500); refresh() }.start()
        }.apply { background = rounded(Color.WHITE, null, 12); setTextColor(ACCENT) }
        autoBtn = btn("Auto start", false) { autoStart() }.apply { background = rounded(Color.WHITE, null, 12); setTextColor(ACCENT) }
        // "Start" uses the method picked below (Wireless / TCP / USB); "Auto start" tries them by itself.
        startBtn = btn("Start", false) { startSelected() }.apply { background = rounded(Color.WHITE, null, 12); setTextColor(ACCENT) }
        startRow = LinearLayout(this).apply {
            listOf(startBtn, autoBtn).forEachIndexed { i, b ->
                b.layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply { topMargin = dp(10); if (i == 0) marginEnd = dp(8) }
                addView(b)
            }
        }
        restartBtn = btn("Restart", false) { restartServer() }.apply {
            background = rounded(0x33FFFFFF, null, 12); setTextColor(Color.WHITE)
        }
        hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(22))
            background = heroBg(false); elevation = 0f
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) }
            addView(LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL; addView(dot); addView(statusT) })
            addView(subT); addView(msgT); addView(pillsT); addView(startRow)
            addView(LinearLayout(this@MainActivity).apply {
                listOf(restartBtn, stopBtn).forEachIndexed { i, b ->
                    b.layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply { topMargin = dp(14); if (i == 0) marginEnd = dp(8) }
                    addView(b)
                }
            })
        }
        col.addView(hero)

        // Start methods
        val seg = LinearLayout(this).apply {
            background = rounded(FIELD, null, 14); setPadding(dp(4), dp(4), dp(4), dp(4))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
        }
        names.forEachIndexed { i, n ->
            val c = Button(this).apply {
                text = n; isAllCaps = false; stateListAnimator = null; textSize = 13f
                minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0; setPadding(0, 0, 0, 0)
                setOnClickListener { method = i; styleChips(); buildPanel() }
                layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f)
            }
            chips.add(c); seg.addView(c)
        }
        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun shortcut(t: String, toggle: String?) = btn(t, false) { openDevSettings(toggle) }.apply {
            textSize = 11f; setPadding(0, 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(3); marginEnd = dp(3) }
        }
        val shortcuts = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
            addView(shortcut("Dev options", null))
            addView(shortcut("USB debugging", "enable_adb"))
            addView(shortcut("Wireless debug", "toggle_adb_wireless"))
        }
        methodsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(hint("Pick one method and follow the steps."))
            addView(shortcuts); addView(seg); addView(panel)
        }
        methodsArrow = label("▾", 18f, MUTED, true)
        val methodsHead = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(label("Start the server", 17f, INK, true).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
            addView(methodsArrow)
            setOnClickListener { setMethodsOpen(methodsBox.visibility != View.VISIBLE) }
        }
        col.addView(card(methodsHead, methodsBox))
        styleChips(); buildPanel()

        // Settings
        col.addView(card(
            label("Settings", 17f, INK, true),
            switchRow("Keep alive (Watchdog)", "Checks the server every 15 s and restarts it. Works with the screen off.", Store.watchdogOn(this)) { on ->
                Store.setWatchdogOn(this, on)
                if (on) WatchdogService.start(this) else WatchdogService.stop(this)
                refresh()
            },
            divider(),
            switchRow("Wake closed apps", "If an app that uses AeroHUB is closed, wake it in the background (checks every 20 s).", Store.wakeApps(this)) { on ->
                Store.setWakeApps(this, on)
                if (on) Thread { runCatching { WatchdogService.wakeApps(this, true) } }.start()
                refresh()
            },
            divider(),
            switchRow("Start on boot", "Starts the server after a reboot. Needs Wi-Fi and Android 11+.", Store.autoStart(this)) { on -> setAutoStart(on); refresh() },
            divider(),
            btn("Check connection", false) { runDiagnose() }
        ))
        col.addView(label("AeroHUB 1.9", 12f, MUTED).apply { gravity = Gravity.CENTER; setPadding(0, dp(24), 0, 0) })
        return ScrollView(this).apply { setBackgroundColor(BG); addView(col) }
    }

    // ---------- TAB 3: app access (which apps may use AeroHUB) ----------
    private fun buildAppsPage(): View {
        appsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(36), dp(18), dp(24)) }
        col.addView(label("Apps", 34f, INK, true))
        col.addView(hint("Choose which apps can use AeroHUB's elevated access."))
        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                addView(label("Allow apps", 17f, INK, true))
                addView(hint("Turn off to block every app at once."))
            })
            addView(sw(Store.masterOn(this@MainActivity)) {
                Store.setMasterOn(this@MainActivity, it); Store.push(this@MainActivity)
                toast(if (it) "Apps allowed" else "All apps are blocked")
            })
        }
        // Installed / System selector at the top of the list
        val seg = LinearLayout(this).apply {
            background = rounded(FIELD, null, 14); setPadding(dp(4), dp(4), dp(4), dp(4))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14); bottomMargin = dp(14) }
        }
        appChips.clear()
        listOf("Installed apps", "System apps").forEachIndexed { i, n ->
            val c = Button(this).apply {
                text = n; isAllCaps = false; stateListAnimator = null; textSize = 13f
                minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0; setPadding(0, 0, 0, 0)
                setOnClickListener { appsFilter = i; buildApps() }
                layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f)
            }
            appChips.add(c); seg.addView(c)
        }
        col.addView(seg)
        col.addView(card(head, appsBox))
        return ScrollView(this).apply { setBackgroundColor(BG); addView(col) }
    }

    private fun styleAppChips() = appChips.forEachIndexed { i, b ->
        val on = i == appsFilter
        b.setTextColor(if (on) Color.WHITE else ACCENT)
        b.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
        b.background = rounded(if (on) ACCENT else Color.TRANSPARENT, null, 11)
    }

    private fun styleChips() = chips.forEachIndexed { i, b ->
        val on = i == method
        b.setTextColor(if (on) Color.WHITE else ACCENT)
        b.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
        b.background = rounded(if (on) ACCENT else Color.TRANSPARENT, null, 11)
    }

    private fun buildPanel() {
        panel.removeAllViews()
        when (method) {
            0 -> { // Wireless debugging: only the Pair button
                panel.addView(btn("Pair") { startPairing() })
            }
            1 -> { // ADB over TCP
                val tcpPort = field("Port", Store.tcpPort(this).toString(), true)
                panel.addView(step(1, "Turn TCP on (no computer needed)",
                    hint("Pair once in the Wireless tab. Then AeroHUB switches ADB to TCP by itself. TCP also works without Wi-Fi, until the phone reboots."),
                    tcpPort,
                    btn("Enable TCP via Wireless", false) {
                        val p = tcpPort.text.toString().toIntOrNull() ?: 5555
                        work("Switching ADB to TCP…") { Starter.enableTcp(this@MainActivity, p) }
                    }))
                panel.addView(step(2, "Connect and start",
                    hint("If TCP is already on, start here. Accept the \"Allow USB debugging?\" dialog if it appears."),
                    btn("Connect & Start") {
                        val p = tcpPort.text.toString().toIntOrNull() ?: 5555
                        Store.setTcpPort(this, p)
                        adbStart("127.0.0.1", p)
                    }))
            }
            else -> { // USB debugging
                panel.addView(step(1, "Turn on USB debugging",
                    hint("Developer options -> USB debugging must be on."),
                    btn("Open USB debugging setting", false) { openDevSettings("enable_adb") }))
                panel.addView(step(2, "Start via USB debugging",
                    hint("Uses the ADB connection on this phone (127.0.0.1). If it says the port is closed, switch ADB to TCP once: pair in the Wireless tab, then TCP tab -> Enable TCP via Wireless. Accept the \"Allow USB debugging?\" dialog (Always allow)."),
                    btn("Start via USB debugging") { work("Connecting through USB debugging…") { Starter.usbStart(this@MainActivity) } }))
            }
        }
    }

    private fun openDevSettings(toggle: String? = null) {
        try {
            val i = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
            if (toggle != null) {
                i.putExtra(":settings:fragment_args_key", toggle)
                i.putExtra(":settings:show_fragment_args", Bundle().apply { putString(":settings:fragment_args_key", toggle) })
            }
            startActivity(i)
        } catch (e: Exception) { toast("Open Settings > Developer options") }
    }

    // ---------- connection logic ----------
    private fun startPairing() {
        if (Build.VERSION.SDK_INT < 30) { toast("Wireless debugging needs Android 11 or newer"); return }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7); return
        }
        startForegroundService(Intent(this, PairingService::class.java).setAction(PairingService.ACTION_START))
        msgT.text = "Pairing started. Tap \"Pair device with pairing code\"; the code box pops up as a notification."
        openWirelessDebugging()
    }

    /** Opens Developer options -> Wireless debugging directly (falls back to Developer options). */
    private fun openWirelessDebugging() {
        val tries = listOf<() -> Intent>(
            { Intent("android.settings.WIRELESS_DEBUGGING_SETTINGS") },
            {
                Intent().setClassName("com.android.settings", "com.android.settings.SubSettings")
                    .putExtra(":settings:show_fragment", "com.android.settings.development.WirelessDebuggingFragment")
            }
        )
        for (t in tries) {
            try { startActivity(t()); return } catch (e: Exception) { /* not on this phone, try the next */ }
        }
        openDevSettings("toggle_adb_wireless")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 8) { updateGate(); return }
        if (requestCode == 7) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startPairing()
            else toast("Allow notifications to enter the pairing code there")
        }
    }

    private fun work(label: String, block: () -> String) {
        msgT.text = label
        Thread {
            val r = try { block() } catch (e: Throwable) { "Failed: ${e.message ?: e.javaClass.simpleName}" }
            runOnUiThread { msgT.text = r }
            refresh()
        }.start()
    }

    private fun adbStart(host: String, port: Int) = work("Connecting to $host:$port…") {
        AdbMgr.runStart(this, host, port)
        if (!Starter.waitRunning(this)) error("Start command sent, but the server did not answer. Try Auto start.")
        Starter.onStarted(this)   // tell the watchdog to keep it alive (this path did not before)
        "Server started"
    }

    /** Starts the watchdog. The battery exemption is asked on the setup page (updateGate). */
    private fun startWatchdog() {
        if (Store.wanted(this) || Store.autoStart(this)) WatchdogService.start(this)
    }

    /** The Start button: starts with the method chosen in the list below (Wireless, TCP or USB). */
    private fun startSelected() = when (method) {
        0 -> work("Starting with Wireless debugging…") { Starter.wirelessStart(this) }
        else -> work("Starting with ${names[method]}…") { Starter.usbStart(this) }
    }

    private fun autoStart() = work("Looking for a way to connect…") { Starter.auto(this) }

    private fun restartServer() = work("Restarting…") {
        runCatching { MyKuzu.stop(Store.token(this)) }
        Thread.sleep(800)
        Starter.auto(this)
    }

    private fun setAutoStart(on: Boolean) {
        Store.setAutoStart(this, on)
        if (!on) { msgT.text = "Start on boot is off"; return }
        Thread {
            val r = try {
                val res = MyKuzu.exec(Store.token(this), "pm grant $packageName android.permission.WRITE_SECURE_SETTINGS")
                if (res.first == 0) "Start on boot is on" else "Start on boot is on, but the permission was not granted: ${res.second.trim()}"
            } catch (e: Exception) { "Start on boot is on. Start the server once so AeroHUB can finish the setup." }
            runOnUiThread { msgT.text = r }
        }.start()
    }

    private fun runDiagnose() {
        toast("Checking…")
        Thread {
            val r = try { Starter.diagnose(this) } catch (e: Throwable) { "Failed: ${Starter.msg(e)}" }
            runOnUiThread { AlertDialog.Builder(this).setTitle("Connection check").setMessage(r).setPositiveButton("OK", null).show() }
        }.start()
    }

    private fun buildApps() {
        appsBox.removeAllViews()
        val pm = packageManager
        val gs = Store.grants(this)
        // system app = has FLAG_SYSTEM; an app that is no longer installed counts as "installed"
        fun isSystem(pkg: String) = try { (pm.getApplicationInfo(pkg, 0).flags and ApplicationInfo.FLAG_SYSTEM) != 0 } catch (e: Exception) { false }
        val nSys = gs.count { isSystem(it.pkg) }
        if (appChips.size == 2) {
            appChips[0].text = "Installed apps (${gs.size - nSys})"
            appChips[1].text = "System apps ($nSys)"
            styleAppChips()
        }
        if (gs.isEmpty()) { appsBox.addView(hint("No apps yet. Apps that ask for access will appear here.")); return }
        val shown = gs.filter { isSystem(it.pkg) == (appsFilter == 1) }
            .sortedBy { g -> try { pm.getApplicationLabel(pm.getApplicationInfo(g.pkg, 0)).toString().lowercase() } catch (e: Exception) { g.pkg } }
        if (shown.isEmpty()) {
            appsBox.addView(hint(if (appsFilter == 1) "No system apps have asked for access." else "No installed apps have asked for access."))
            return
        }
        shown.forEach { g ->
            val name = try { pm.getApplicationLabel(pm.getApplicationInfo(g.pkg, 0)).toString() } catch (e: Exception) { g.pkg }
            val icon = try { pm.getApplicationIcon(g.pkg) } catch (e: Exception) { null }
            appsBox.addView(LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(14), 0, 0)
                addView(ImageView(this@MainActivity).apply {
                    setImageDrawable(icon)
                    layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(14) }
                })
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    addView(label(name, 15f, INK, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
                    addView(label(g.pkg, 12f, MUTED).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
                })
                addView(sw(g.enabled) { Store.setEnabled(this@MainActivity, g.pkg, it); Store.push(this@MainActivity) })
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity).setTitle("Remove $name?")
                        .setMessage("It will lose access and must ask again.")
                        .setPositiveButton("Remove") { _, _ -> Store.remove(this@MainActivity, g.pkg); Store.push(this@MainActivity); buildApps() }
                        .setNegativeButton("Cancel", null).show()
                    true
                }
            })
        }
        appsBox.addView(hint("Long-press an app to remove it."))
    }

    override fun onResume() {
        super.onResume(); startWatchdog(); updateGate(true); buildApps(); refresh(); showKeepDialog()
        ui.removeCallbacks(pairTick); ui.post(pairTick)
    }

    override fun onPause() { ui.removeCallbacks(pairTick); super.onPause() }

    /** While pairing from the notification is running, show its progress here and keep refreshing the server status. */
    private val pairTick = object : Runnable {
        override fun run() {
            if (PairingService.busy) {
                msgT.text = PairingService.status
                refresh()
                ui.postDelayed(this, 1000)
            } else if (PairingService.status.isNotEmpty()) {
                msgT.text = PairingService.status
                PairingService.status = ""
                refresh()
            }
        }
    }

    private val reconnectTask = Runnable { refresh() }

    private fun refresh() {
        Thread {
            val tok = Store.token(this)
            // Right after screen on the first connect can fail while the server is fine, so try a few times before showing "Not running".
            var uid = MyKuzu.ping(tok)
            for (n in 1..3) { if (uid != null) break; Thread.sleep(1000); uid = MyKuzu.ping(tok) }
            // Shizuku style: the server counts as running while its Binder is alive. A failed ping right after screen on only means
            // "not answering yet", so keep showing Running and look again in 3 s instead of flipping to "Not running".
            var reconnecting = false
            if (uid == null && MyKuzu.presumedAlive()) { uid = MyKuzu.lastUid; reconnecting = true }
            val ver = if (uid != null && !reconnecting) MyKuzu.version(tok) else null
            if (uid != null && !reconnecting) runCatching { MyKuzu.sync(tok, Store.activeTokens(this)) }
            // Take AeroHUB out of Doze / battery limits via the server (throttled), so the server keeps answering with the screen off.
            if (uid != null && !reconnecting) runCatching { Store.adoptRunning(this); WatchdogService.start(this); WatchdogService.exempt(this) }
            runOnUiThread {
                ui.removeCallbacks(reconnectTask)
                if (reconnecting) ui.postDelayed(reconnectTask, 3000)
                hero.background = heroBg(uid != null)
                pillsT.text = "Watchdog: " + (if (Store.watchdogOn(this)) "On" else "Off") + "   •   Start on boot: " + (if (Store.autoStart(this)) "On" else "Off") + "   •   Link: " + MyKuzu.transport()
                if (!methodsInit) { methodsInit = true; setMethodsOpen(uid == null) }
                statusT.text = if (uid == null) "Not running" else "Running"
                subT.text = when (uid) {
                    null -> "Tap Auto start, or choose a method below."
                    0 -> "Running as root (UID 0). Press Restart to use UID 2000"
                    2000 -> "Running as ADB shell (UID 2000)"
                    else -> "Running as UID $uid"
                }
                if (reconnecting) subT.text = "Server is running, reconnecting..."
                stopBtn.visibility = if (uid == null) View.GONE else View.VISIBLE
                restartBtn.visibility = if (uid == null) View.GONE else View.VISIBLE
                startRow.visibility = if (uid == null) View.VISIBLE else View.GONE
                if (uid != null && (ver ?: 1) < Server.VERSION) msgT.text = "Server is outdated. Tap Restart to update it."
            }
        }.start()
    }

    // ---------- TAB 2: tools ----------
    private var toolOpen = false
    private val prefs by lazy { getSharedPreferences("aerohub_tools", Context.MODE_PRIVATE) }

    private class AppItem(val pkg: String, val label: String, val system: Boolean, val enabled: Boolean)

    // Lives for the whole process, so a pending "undo display change" survives the activity being recreated.
    private companion object {
        val ui = Handler(Looper.getMainLooper())
        var revertCmd: String? = null
        var revertAt = 0L
        var revertTask: Runnable? = null
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (tab == 1 && toolOpen) showToolsList() else super.onBackPressed()
    }

    override fun onDestroy() {
        ui.removeCallbacks(tick)
        keepDialog?.dismiss(); keepDialog = null
        super.onDestroy()
    }

    private fun toolRow(glyph: Int, title: String, tint: Int, last: Boolean, go: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(LinearLayout(this@MainActivity).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            addView(ImageView(this@MainActivity).apply {
                setImageResource(glyph); setColorFilter(Color.WHITE); background = rounded(tint, null, 8)
                setPadding(dp(6), dp(6), dp(6), dp(6))
                layoutParams = LinearLayout.LayoutParams(dp(32), dp(32)).apply { marginEnd = dp(14) }
            })
            addView(label(title, 17f, INK).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
            addView(label("\u203A", 24f, 0xFFC7C7CC.toInt()))
            setOnClickListener { go() }
        })
        if (!last) addView(View(this@MainActivity).apply {
            setBackgroundColor(LINE); layoutParams = LinearLayout.LayoutParams(-1, 1).apply { marginStart = dp(60) }
        })
    }

    private fun showToolsList() {
        toolOpen = false
        toolsHost.removeAllViews()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(48), dp(18), dp(24)) }
        col.addView(label("Tools", 34f, INK, true))
        col.addView(hint("Needs the server running. Start it in the Connect tab."))
        // One rounded card per category, with a gap between the cards.
        val groups = listOf(
            listOf( // display
                Triple(R.drawable.ic_sliders, "Appearance", 0xFF8E8E93.toInt()) to { appearanceTool() },
                Triple(R.drawable.ic_monitor, "Resolution changer", 0xFF007AFF.toInt()) to { resolutionTool() },
                Triple(R.drawable.ic_sliders, "DPI changer", 0xFF5856D6.toInt()) to { dpiTool() },
                Triple(R.drawable.ic_monitor, "Refresh rate", 0xFF5856D6.toInt()) to { refreshRateTool() },
                Triple(R.drawable.ic_sliders, "Animation speed", 0xFFFF9500.toInt()) to { animationTool() },
                Triple(R.drawable.ic_monitor, "Hide status bar", 0xFF8E8E93.toInt()) to { hideStatusBarTool() },
                Triple(R.drawable.ic_tools, "System UI tuner", 0xFF30B0C7.toInt()) to { systemUiTool() }
            ),
            listOf( // turn apps off / on
                Triple(R.drawable.ic_power, "App disable", 0xFFFF3B30.toInt()) to { disableTool() },
                Triple(R.drawable.ic_check, "App enable", 0xFF30B0C7.toInt()) to { enableTool() }
            ),
            listOf( // app behaviour and permissions
                Triple(R.drawable.ic_shield, "Uninstall protection", 0xFF34C759.toInt()) to { uninstallTool() },
                Triple(R.drawable.ic_launch, "Auto start", 0xFFFF9500.toInt()) to { autoStartTool() },
                Triple(R.drawable.ic_phone, "Notifications", 0xFFFF2D55.toInt()) to { notificationTool() },
                Triple(R.drawable.ic_access, "Accessibility", 0xFFAF52DE.toInt()) to { accessibilityTool() }
            ),
            listOf( // network
                Triple(R.drawable.ic_connect, "Private DNS", 0xFF007AFF.toInt()) to { privateDnsTool() }
            )
        )
        groups.forEach { tools ->
            val group = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = rounded(CARD, null, 14)
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) }
            }
            tools.forEachIndexed { i, t -> group.addView(toolRow(t.first.first, t.first.second, t.first.third, i == tools.lastIndex, t.second)) }
            col.addView(group)
        }
        toolsHost.addView(ScrollView(this).apply { setBackgroundColor(BG); addView(col) }, FrameLayout.LayoutParams(-1, -1))
    }

    /** A tool page: back arrow + title on top, [body] fills the rest. */
    private fun openPage(title: String, body: View) {
        toolOpen = true
        toolsHost.removeAllViews()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(dp(18), dp(24), dp(18), 0) }
        col.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(label("‹", 32f, ACCENT).apply { setPadding(dp(4), 0, dp(18), dp(4)); setOnClickListener { showToolsList() } })
            addView(label(title, 22f, INK, true))
        })
        col.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        toolsHost.addView(col, FrameLayout.LayoutParams(-1, -1))
    }

    private fun scrollBody(vararg v: View): View = ScrollView(this).apply {
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(24))
            v.forEach { addView(it) }
        })
    }

    // ---------- running commands ----------
    /** Runs a command on the server in the background; [done] gets the exit code (-1 = server not reachable) and output. */
    private fun bg(cmd: String, done: (Int, String) -> Unit) {
        Thread {
            val r = try { MyKuzu.exec(Store.token(this), cmd) } catch (e: Exception) { -1 to "Start the server first" }
            runOnUiThread { done(r.first, r.second) }
        }.start()
    }

    /** Runs a command and tells the person the result in a toast. */
    private fun execToast(cmd: String, ok: String, after: (Boolean) -> Unit = {}) = bg(cmd) { c, o ->
        toast(when {
            c == 0 -> ok
            c == -1 -> "Start the server first. Open the Connect tab."
            else -> "Failed: " + o.trim().lineSequence().firstOrNull().orEmpty().ifEmpty { "exit code $c" }
        })
        after(c == 0)
    }

    // ---------- app list (no package names to type) ----------
    private fun loadApps(done: (List<AppItem>) -> Unit) {
        Thread {
            val pm = packageManager
            // The server knows exactly which apps are turned off; fall back to the app info flag if it is not running.
            val off: Set<String> = try {
                val r = MyKuzu.exec(Store.token(this), "pm list packages -d")
                if (r.first == 0) r.second.lines().filter { it.startsWith("package:") }.map { it.removePrefix("package:").trim() }.toSet() else emptySet()
            } catch (e: Exception) { emptySet() }
            @Suppress("DEPRECATION")
            val apps = try { pm.getInstalledApplications(PackageManager.MATCH_DISABLED_COMPONENTS) } catch (e: Exception) { emptyList<ApplicationInfo>() }
            val items = apps.filter { it.packageName != packageName }.map { ai ->
                AppItem(
                    ai.packageName,
                    try { pm.getApplicationLabel(ai).toString() } catch (e: Exception) { ai.packageName },
                    (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                    ai.enabled && ai.packageName !in off
                )
            }.sortedWith(compareBy<AppItem>({ it.system }, { it.label.lowercase() })) // your apps first, then system apps
            runOnUiThread { done(items) }
        }.start()
    }

    private inner class AppAdapter(
        private val all: List<AppItem>, private val tag: (AppItem) -> String?,
        private val toggle: ((AppItem) -> Boolean)? = null,
        private val onToggle: ((AppItem, Boolean) -> Unit)? = null
    ) : BaseAdapter() {
        private var shown: List<AppItem> = all
        private val icons = HashMap<String, Drawable?>()

        fun filter(query: String) {
            val s = query.trim().lowercase()
            shown = if (s.isEmpty()) all else all.filter { it.label.lowercase().contains(s) || it.pkg.lowercase().contains(s) }
            notifyDataSetChanged()
        }

        private fun iconOf(pkg: String): Drawable? =
            icons.getOrPut(pkg) { try { packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null } }

        override fun getCount() = shown.size
        override fun getItem(position: Int): AppItem = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4), dp(10), dp(4), dp(10))
                addView(ImageView(this@MainActivity).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(14) }
                })
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    addView(label("", 15f, INK, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
                    addView(label("", 12f, MUTED).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
                })
                addView(label("", 12f, ACCENT, true))
                addView(sw(false) {}.apply { visibility = View.GONE })
            }
            val a = shown[position]
            (row.getChildAt(0) as ImageView).setImageDrawable(iconOf(a.pkg))
            val mid = row.getChildAt(1) as LinearLayout
            (mid.getChildAt(0) as TextView).text = a.label
            (mid.getChildAt(1) as TextView).text = a.pkg
            (row.getChildAt(2) as TextView).text = tag(a) ?: ""
            val swt = row.getChildAt(3) as Switch
            if (toggle != null) {
                row.getChildAt(2).visibility = View.GONE
                swt.visibility = View.VISIBLE
                swt.setOnCheckedChangeListener(null)
                swt.isChecked = toggle.invoke(a)
                swt.setOnCheckedChangeListener { _, b -> onToggle?.invoke(a, b) }
            } else swt.visibility = View.GONE
            return row
        }
    }

    /**
     * Opens a searchable list of installed apps. [keep] picks which apps are listed, [tag] is a small label on the right,
     * [onPick] runs when an app is tapped and gets a function that reloads the list.
     */
    private fun appPicker(
        title: String, info: String, emptyText: String,
        keep: (AppItem) -> Boolean, tag: (AppItem) -> String?,
        header: View? = null,
        toggle: ((AppItem) -> Boolean)? = null,
        onToggle: ((AppItem, Boolean, () -> Unit) -> Unit)? = null,
        onPick: (AppItem, () -> Unit) -> Unit
    ) {
        val search = field("Search apps")
        val status = hint("Loading apps…")
        val list = ListView(this).apply {
            divider = null
            setSelector(android.graphics.drawable.ColorDrawable(PRESS))
            cacheColorHint = Color.TRANSPARENT
        }
        openPage(title, LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            if (header != null) addView(header)
            addView(hint(info))
            addView(search)
            addView(status)
            addView(list, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })
        })

        var adapter: AppAdapter? = null
        var loaded = false
        fun refreshStatus() {
            val n = adapter?.count ?: 0
            status.visibility = if (!loaded || n == 0) View.VISIBLE else View.GONE
            status.text = if (!loaded) "Loading apps…" else if (search.text.isNullOrBlank()) emptyText else "No app found"
        }
        fun load() {
            loaded = false; refreshStatus()
            loadApps { all ->
                val a = AppAdapter(all.filter(keep), tag, toggle, onToggle?.let { f -> { app: AppItem, on: Boolean -> f(app, on) { load() } } })
                a.filter(search.text.toString())
                adapter = a; list.adapter = a; loaded = true; refreshStatus()
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { adapter?.filter(s?.toString().orEmpty()); refreshStatus() }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        list.setOnItemClickListener { _, _, pos, _ ->
            val a = adapter?.getItem(pos) ?: return@setOnItemClickListener
            onPick(a) { load() }
        }
        load()
    }

    // ---------- tool: App disable / App enable ----------
    private fun disableTool() = appPicker(
        "App disable", "Tap an app to turn it off. Turn it back on in App enable.", "No apps to show",
        { it.enabled }, { if (it.system) "System" else null }
    ) { a, reload ->
        val go = { execToast("pm disable-user --user 0 ${q(a.pkg)}", "${a.label} disabled") { ok -> if (ok) reload() } }
        if (a.system) confirm("${a.label} is a system app. Turning it off can break your phone. Continue?") { go() } else go()
    }

    private fun enableTool() = appPicker(
        "App enable", "Apps you turned off are listed here. Tap one to turn it on.", "No disabled apps",
        { !it.enabled }, { if (it.system) "System" else null }
    ) { a, reload ->
        execToast("pm enable ${q(a.pkg)}", "${a.label} enabled") { ok -> if (ok) reload() }
    }

    // ---------- tool: Auto start ----------
    private fun autoSet(key: String): Set<String> = prefs.getStringSet(key, null) ?: emptySet()

    private fun markAuto(pkg: String, on: Boolean) {
        val onSet = HashSet(autoSet("auto_on")); val offSet = HashSet(autoSet("auto_off"))
        if (on) { onSet.add(pkg); offSet.remove(pkg) } else { offSet.add(pkg); onSet.remove(pkg) }
        prefs.edit().putStringSet("auto_on", onSet).putStringSet("auto_off", offSet).apply()
    }

    /** Allow = may run in the background and is exempt from battery limits. Block = the opposite. */
    private fun setAutoStartFor(a: AppItem, on: Boolean, reload: () -> Unit) {
        val p = q(a.pkg)
        val cmd = if (on)
            "appops set $p RUN_IN_BACKGROUND allow || exit 1; " +
                "(appops set $p RUN_ANY_IN_BACKGROUND allow; cmd deviceidle whitelist +$p; appops set $p AUTO_START allow) >/dev/null 2>&1; exit 0"
        else
            "appops set $p RUN_IN_BACKGROUND ignore || exit 1; " +
                "(appops set $p RUN_ANY_IN_BACKGROUND ignore; cmd deviceidle whitelist -$p; appops set $p AUTO_START ignore) >/dev/null 2>&1; exit 0"
        execToast(cmd, if (on) "${a.label}: auto start allowed" else "${a.label}: auto start blocked") { ok ->
            if (ok) { markAuto(a.pkg, on); reload() }
        }
    }

    private fun autoStartTool() = appPicker(
        "Auto start", "Tap an app to let it run in the background and start on its own, or to stop that.", "No apps to show",
        { true },
        {
            when {
                it.pkg in autoSet("auto_on") -> "On"
                it.pkg in autoSet("auto_off") -> "Off"
                else -> null
            }
        }
    ) { a, reload ->
        AlertDialog.Builder(this).setTitle(a.label)
            .setItems(arrayOf("Allow auto start", "Block auto start")) { _, i -> setAutoStartFor(a, i == 0, reload) }
            .show()
    }

    // ---------- tool: Uninstall protection ----------
    private fun uninstallApps(): Set<String> = prefs.getStringSet("uninstall_pkgs", null) ?: emptySet()

    private fun uninstallTool() {
        // Header: one master switch for ALL apps (system-wide restriction).
        var all = prefs.getBoolean("uninstall_block", false)
        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(ROW, null, 18)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        }
        var guard = false
        lateinit var allSw: Switch
        allSw = sw(all) { next ->
            if (!guard) execToast(
                "pm set-user-restriction no_uninstall_apps ${if (next) 1 else 0}",
                if (next) "All apps are protected" else "Protection for all apps is off"
            ) { ok ->
                if (ok) { all = next; prefs.edit().putBoolean("uninstall_block", next).apply() }
                else { guard = true; allSw.isChecked = all; guard = false }
            }
        }
        head.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            addView(label("Protect all apps", 16f, INK, true))
            addView(hint("One switch for every app"))
        })
        head.addView(allSw)

        appPicker(
            "Uninstall protection",
            "Use the switch next to an app to stop it from being uninstalled.", "No apps to show",
            { true }, { null },
            header = head,
            toggle = { it.pkg in uninstallApps() },
            onToggle = { a, on, reload ->
                Thread {
                    val err = try { MyKuzu.setUninstallBlocked(Store.token(this), a.pkg, on) } catch (e: Exception) { "Start the server first. Open the Connect tab." }
                    runOnUiThread {
                        if (err == null) {
                            val set = HashSet(uninstallApps()); if (on) set.add(a.pkg) else set.remove(a.pkg)
                            prefs.edit().putStringSet("uninstall_pkgs", set).apply()
                            toast(if (on) "${a.label} is protected" else "${a.label} is not protected")
                        } else { toast(err); reload() }
                    }
                }.start()
            }
        ) { _, _ -> }
    }

    // ---------- tool: Accessibility (turn an app's accessibility service on/off) ----------
    private fun accessibilityTool() {
        // pkg -> full service names ("pkg/cls") of every accessibility service the app has
        val services = HashMap<String, MutableList<String>>()
        try {
            val intent = Intent("android.accessibilityservice.AccessibilityService")
            @Suppress("DEPRECATION")
            packageManager.queryIntentServices(intent, 0).forEach {
                val si = it.serviceInfo ?: return@forEach
                services.getOrPut(si.packageName) { mutableListOf() }.add(si.packageName + "/" + si.name)
            }
        } catch (e: Exception) {}
        val enabled = LinkedHashSet<String>()
        fun norm(c: String): String {
            val p = c.substringBefore("/"); val n = c.substringAfter("/")
            return p + "/" + (if (n.startsWith(".")) p + n else n)
        }
        // Read what is on right now, then show the list.
        bg("settings get secure enabled_accessibility_services") { c, o ->
            if (c != 0) { toast(if (c == -1) "Start the server first. Open the Connect tab." else "Failed: " + o.trim()); return@bg }
            o.trim().split(":").filter { it.contains("/") }.forEach { enabled.add(norm(it)) }
            appPicker(
                "Accessibility",
                "Switch on an app's accessibility service without opening Settings. Only apps that have one are listed.",
                "No apps with an accessibility service",
                { it.pkg in services }, { null },
                toggle = { a -> services[a.pkg].orEmpty().any { it in enabled } },
                onToggle = { a, on, reload ->
                    val mine = services[a.pkg].orEmpty()
                    val next = LinkedHashSet(enabled)
                    if (on) next.addAll(mine) else next.removeAll(mine.toSet())
                    val value = if (next.isEmpty()) "\"\"" else q(next.joinToString(":"))
                    val cmd = "settings put secure enabled_accessibility_services $value" +
                        (if (on) " && settings put secure accessibility_enabled 1" else "")
                    bg(cmd) { code, out ->
                        if (code == 0) {
                            enabled.clear(); enabled.addAll(next)
                            toast(if (on) "${a.label}: accessibility on" else "${a.label}: accessibility off")
                        } else {
                            toast(if (code == -1) "Start the server first. Open the Connect tab." else "Failed: " + out.trim().lineSequence().firstOrNull().orEmpty())
                            reload()
                        }
                    }
                }
            ) { _, _ -> }
        }
    }

    // ---------- tool: Notifications (allow / block an app's notifications) ----------
    private fun notificationTool() {
        fun blocked() = prefs.getStringSet("notif_off", null) ?: emptySet()
        appPicker(
            "Notifications",
            "Switch off an app to block its notifications. Switch it on to allow them again.",
            "No apps to show",
            { true }, { null },
            toggle = { it.pkg !in blocked() },
            onToggle = { a, on, reload ->
                val p = q(a.pkg)
                val cmd = if (on)
                    "appops set $p POST_NOTIFICATION allow; (pm grant $p android.permission.POST_NOTIFICATIONS) >/dev/null 2>&1; exit 0"
                else
                    "appops set $p POST_NOTIFICATION deny"
                bg(cmd) { code, out ->
                    if (code == 0) {
                        val set = HashSet(blocked()); if (on) set.remove(a.pkg) else set.add(a.pkg)
                        prefs.edit().putStringSet("notif_off", set).apply()
                        toast(if (on) "${a.label}: notifications allowed" else "${a.label}: notifications blocked")
                    } else {
                        toast(if (code == -1) "Start the server first. Open the Connect tab." else "Failed: " + out.trim().lineSequence().firstOrNull().orEmpty())
                        reload()
                    }
                }
            }
        ) { _, _ -> }
    }

    // ---------- tool: Appearance (theme) ----------
    private fun appearanceTool() {
        val names = listOf("Light", "Dark", "AMOLED black")
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun pick(i: Int) {
            if (i == themeMode) return
            getSharedPreferences("aerohub_tools", Context.MODE_PRIVATE).edit().putInt("theme", i).apply()
            recreate()
        }
        names.forEachIndexed { i, n ->
            col.addView(LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(if (i == 0) 0 else 14), 0, 0)
                addView(label(n, 17f, INK).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
                if (i == themeMode) addView(label("\u2713", 20f, ACCENT, true))
                setOnClickListener { pick(i) }
            })
        }
        openPage("Appearance", scrollBody(card(
            settingsTitle("Theme", "AMOLED black uses pure black to save battery on OLED screens."),
            col.apply { setPadding(0, dp(8), 0, 0) }
        )))
    }

    // ---------- shared helpers for the settings tools ----------
    /** Row of buttons; each runs a shell command, tells the result, then calls [after]. */
    private fun choices(after: () -> Unit, vararg c: Pair<String, String>): View =
        rowOf(*c.map { (name, cmd) -> half(name) { execToast(cmd, "$name applied") { ok -> if (ok) after() } } }.toTypedArray())

    private fun settingsTitle(t: String, sub: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(t, 17f, INK, true)); addView(hint(sub))
    }

    private fun readValue(cmd: String, done: (String) -> Unit) = bg(cmd) { c, o ->
        if (c != 0) toast(if (c == -1) "Start the server first. Open the Connect tab." else "Failed: " + o.trim().lineSequence().firstOrNull().orEmpty())
        else done(o.trim())
    }

    // ---------- tool: Animation speed ----------
    private fun animationTool() = readValue("settings get global window_animation_scale") { cur ->
        val now = label("", 15f, MUTED)
        fun scale(v: String) = "settings put global window_animation_scale $v; settings put global transition_animation_scale $v; settings put global animator_duration_scale $v"
        fun load() = bg("settings get global window_animation_scale") { _, o ->
            now.text = "Now: " + (o.trim().takeIf { it != "null" && it.isNotEmpty() } ?: "1.0") + "x"
        }
        now.text = "Now: " + (cur.takeIf { it != "null" && it.isNotEmpty() } ?: "1.0") + "x"
        openPage("Animation speed", scrollBody(card(
            settingsTitle("Animation scale", "Lower is faster. Off removes animations, so the phone feels snappier."),
            now,
            choices({ load() }, "Off" to scale("0"), "0.5x" to scale("0.5"), "1x" to scale("1")),
            choices({ load() }, "1.5x" to scale("1.5"), "2x" to scale("2"))
        )))
    }

    // ---------- tool: Refresh rate ----------
    private fun refreshRateTool() = readValue("settings get system min_refresh_rate; settings get system peak_refresh_rate") { cur ->
        val now = label("", 15f, MUTED)
        fun show(o: String) {
            val v = o.lines().map { it.trim() }
            now.text = "Min: " + (v.getOrNull(0)?.takeIf { it != "null" } ?: "default") + "   Peak: " + (v.getOrNull(1)?.takeIf { it != "null" } ?: "default")
        }
        fun load() = bg("settings get system min_refresh_rate; settings get system peak_refresh_rate") { _, o -> show(o) }
        fun rate(hz: Int) = "settings put system min_refresh_rate $hz; settings put system peak_refresh_rate $hz"
        show(cur)
        openPage("Refresh rate", scrollBody(card(
            settingsTitle("Screen refresh rate", "Pick a rate your screen supports. A phone that does not support a value ignores it."),
            now,
            choices({ load() }, "60 Hz" to rate(60), "90 Hz" to rate(90), "120 Hz" to rate(120)),
            choices({ load() }, "144 Hz" to rate(144), "Reset" to "settings delete system min_refresh_rate; settings delete system peak_refresh_rate")
        )))
    }

    // ---------- tool: System UI tuner ----------
    private fun systemUiTool() = readValue(
        "settings get system status_bar_show_battery_percent; settings get system show_touches; settings get secure clock_seconds"
    ) { cur ->
        val v = cur.lines().map { it.trim() }
        fun flag(i: Int) = v.getOrNull(i) == "1"
        fun switchRow(title: String, sub: String, on: Boolean, cmd: (Boolean) -> String): View {
            var guard = false
            lateinit var w: Switch
            var state = on
            w = sw(on) { next ->
                if (!guard) execToast(cmd(next), "$title ${if (next) "on" else "off"}") { ok ->
                    if (ok) state = next else { guard = true; w.isChecked = state; guard = false }
                }
            }
            return LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, 0)
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    addView(label(title, 16f, INK)); addView(hint(sub))
                })
                addView(w)
            }
        }
        openPage("System UI tuner", scrollBody(
            card(
                settingsTitle("Dark mode", "Forces the system theme."),
                choices({}, "Auto" to "cmd uimode night auto", "On" to "cmd uimode night yes", "Off" to "cmd uimode night no")
            ),
            card(
                settingsTitle("Navigation", "Switch between gestures and the 3 buttons (Android 10+)."),
                choices({},
                    "Gestures" to "cmd overlay enable-exclusive --category com.android.internal.systemui.navbar.gestural",
                    "3 buttons" to "cmd overlay enable-exclusive --category com.android.internal.systemui.navbar.threebutton")
            ),
            card(
                switchRow("Battery percent", "Show the number in the status bar.", flag(0)) {
                    "settings put system status_bar_show_battery_percent ${if (it) 1 else 0}"
                },
                switchRow("Clock seconds", "Show seconds in the status bar clock.", flag(2)) {
                    "settings put secure clock_seconds ${if (it) 1 else 0}"
                },
                switchRow("Show touches", "Draw a dot where the screen is touched.", flag(1)) {
                    "settings put system show_touches ${if (it) 1 else 0}"
                }
            )
        ))
    }

    // ---------- tool: Private DNS ----------
    private fun privateDnsTool() = readValue("settings get global private_dns_mode; settings get global private_dns_specifier") { cur ->
        val now = label("", 15f, MUTED)
        fun show(o: String) {
            val v = o.lines().map { it.trim() }
            val mode = v.getOrNull(0).orEmpty()
            now.text = "Now: " + when (mode) {
                "hostname" -> v.getOrNull(1).orEmpty()
                "opportunistic" -> "Automatic"
                "off" -> "Off"
                else -> "Automatic"
            }
        }
        fun load() = bg("settings get global private_dns_mode; settings get global private_dns_specifier") { _, o -> show(o) }
        fun host(h: String) = "settings put global private_dns_specifier $h; settings put global private_dns_mode hostname"
        show(cur)
        val custom = field("Custom host, for example dns.example.com")
        openPage("Private DNS", scrollBody(
            card(
                settingsTitle("Private DNS", "Applies to Wi-Fi and mobile data."),
                now,
                choices({ load() }, "Automatic" to "settings put global private_dns_mode opportunistic", "Off" to "settings put global private_dns_mode off"),
                choices({ load() },
                    "AdGuard" to host("dns.adguard-dns.com"),
                    "Cloudflare" to host("one.one.one.one"),
                    "Google" to host("dns.google"))
            ),
            card(
                settingsTitle("Custom", "Type your own provider hostname."),
                custom,
                btn("Set") {
                    val h = custom.text.toString().trim()
                    if (!Regex("[A-Za-z0-9.-]+\\.[A-Za-z]{2,}").matches(h)) toast("Enter a valid hostname")
                    else execToast(host(h), "DNS set to $h") { ok -> if (ok) load() }
                }
            )
        ))
    }

    // ---------- tool: Hide status bar ----------
    private fun hideStatusBarTool() {
        var on = prefs.getBoolean("hide_status", false)
        val status = label("", 22f, INK, true)
        val toggle = btn("", true) {}
        fun render() {
            status.text = if (on) "Status bar is hidden" else "Status bar is shown"
            status.setTextColor(if (on) GREEN else MUTED)
            toggle.text = if (on) "Show status bar" else "Hide status bar"
        }
        toggle.setOnClickListener {
            val next = !on
            val old = Build.VERSION.SDK_INT <= 29
            val cmd = when {
                old && next -> "settings put global policy_control immersive.status=*"
                old -> "settings put global policy_control null"
                next -> "cmd statusbar send-disable-flag clock notification-icons system-icons notification-alerts statusbar-expansion"
                else -> "cmd statusbar send-disable-flag none"
            }
            execToast(cmd, if (next) "Status bar hidden" else "Status bar shown") { ok ->
                if (ok) { on = next; prefs.edit().putBoolean("hide_status", on).apply(); render() }
            }
        }
        render()
        openPage("Hide status bar", scrollBody(card(
            status,
            hint(if (Build.VERSION.SDK_INT <= 29)
                "Hides the status bar in every app. Turn it off to bring it back."
            else
                "On Android 11 and newer the bar itself cannot be removed from a shell. This hides its clock, icons and pull-down panel instead. Turn it off to bring them back. It may reset after a reboot."),
            toggle
        )))
    }

    // ---------- tools: Resolution changer / DPI changer ----------
    /** Pulls "Physical <kind>: X" and "Override <kind>: Y" out of `wm size` / `wm density` output. */
    private fun parseWm(out: String, kind: String): Pair<String?, String?> {
        val phys = Regex("Physical $kind: (\\S+)").find(out)?.groupValues?.get(1)
        val over = Regex("Override $kind: (\\S+)").find(out)?.groupValues?.get(1)
        return phys to over
    }

    private fun armRevert(cmd: String) {
        cancelRevert()
        val ctx = applicationContext
        revertCmd = cmd
        revertAt = System.currentTimeMillis() + 15000
        val t = Runnable {
            val c = revertCmd
            revertCmd = null; revertTask = null
            if (c != null) Thread { try { MyKuzu.exec(Store.token(ctx), c) } catch (e: Exception) {} }.start()
        }
        revertTask = t
        ui.postDelayed(t, 15000)
    }

    private fun cancelRevert() {
        revertTask?.let { ui.removeCallbacks(it) }
        revertTask = null; revertCmd = null
    }

    private var keepDialog: AlertDialog? = null
    private val tick = object : Runnable {
        override fun run() {
            val d = keepDialog ?: return
            if (revertCmd == null) { d.dismiss(); return }
            val left = ((revertAt - System.currentTimeMillis()) / 1000).toInt() + 1
            d.setMessage("Going back to the old setting in $left s. Tap Keep if the screen looks fine.")
            ui.postDelayed(this, 500)
        }
    }

    /** Asks "keep this setting?" while the undo countdown runs, so a bad size or DPI can never lock the person out. */
    private fun showKeepDialog() {
        if (revertCmd == null || keepDialog != null || isFinishing || isDestroyed) return
        keepDialog = AlertDialog.Builder(this)
            .setTitle("Keep this setting?")
            .setMessage(" ")
            .setCancelable(false)
            .setPositiveButton("Keep") { _, _ -> cancelRevert() }
            .setNegativeButton("Revert now") { _, _ ->
                val c = revertCmd; cancelRevert()
                if (c != null) bg(c) { _, _ -> }
            }
            .setOnDismissListener { keepDialog = null; ui.removeCallbacks(tick) }
            .show()
        ui.post(tick)
    }

    /** Applies a display change. If it is not confirmed within 15 seconds, [revert] puts the old value back. */
    private fun applyDisplay(cmd: String, revert: String, after: () -> Unit) {
        armRevert(revert)
        bg(cmd) { c, o ->
            if (c == 0) showKeepDialog() else {
                cancelRevert()
                toast(if (c == -1) "Start the server first. Open the Connect tab." else "Failed: " + o.trim().lineSequence().firstOrNull().orEmpty())
            }
            after()
        }
    }

    private fun resolutionTool() {
        val cur = label("Reading the current size…", 14f, MUTED)
        val wF = field("Width (px)", "", true)
        val hF = field("Height (px)", "", true)
        var phys: String? = null
        var over: String? = null
        fun load() {
            bg("wm size") { c, o ->
                if (c != 0) { cur.text = if (c == -1) "Start the server first. Open the Connect tab." else o.trim(); return@bg }
                val (p, ov) = parseWm(o, "size")
                phys = p; over = ov
                cur.text = "Now: " + (ov ?: p ?: "unknown") + (if (ov != null) "   (default $p)" else "")
                (ov ?: p)?.split("x")?.takeIf { it.size == 2 }?.let { wF.setText(it[0]); hF.setText(it[1]) }
            }
        }
        fun scale(pct: Int) {
            val d = phys?.split("x")?.mapNotNull { it.toIntOrNull() }
            if (d == null || d.size != 2) { toast("Current size is not loaded yet"); return }
            wF.setText((d[0] * pct / 100 / 2 * 2).toString()); hF.setText((d[1] * pct / 100 / 2 * 2).toString())
        }
        val applyBtn = btn("Apply") {
            val w = wF.text.toString().toIntOrNull(); val h = hF.text.toString().toIntOrNull()
            if (w == null || h == null || w < 320 || h < 320) { toast("Enter a width and a height of at least 320"); return@btn }
            applyDisplay("wm size ${w}x$h", if (over != null) "wm size $over" else "wm size reset") { load() }
        }
        val resetBtn = btn("Reset to default", false) {
            if (over == null) toast("Already at the default size")
            else applyDisplay("wm size reset", "wm size $over") { load() }
        }
        openPage("Resolution changer", scrollBody(card(
            cur,
            rowOf(half("90%") { scale(90) }, half("80%") { scale(80) }, half("70%") { scale(70) }),
            wF, hF, applyBtn, resetBtn,
            hint("The screen goes back by itself after 15 seconds unless you tap Keep.")
        )))
        load()
    }

    private fun dpiTool() {
        val cur = label("Reading the current DPI…", 14f, MUTED)
        val dF = field("DPI", "", true)
        var phys: String? = null
        var over: String? = null
        fun load() {
            bg("wm density") { c, o ->
                if (c != 0) { cur.text = if (c == -1) "Start the server first. Open the Connect tab." else o.trim(); return@bg }
                val (p, ov) = parseWm(o, "density")
                phys = p; over = ov
                cur.text = "Now: " + (ov ?: p ?: "unknown") + (if (ov != null) "   (default $p)" else "")
                (ov ?: p)?.let { dF.setText(it) }
            }
        }
        fun scale(pct: Int) {
            val p = phys?.toIntOrNull()
            if (p == null) { toast("Current DPI is not loaded yet"); return }
            dF.setText((p * pct / 100).toString())
        }
        val applyBtn = btn("Apply") {
            val d = dF.text.toString().toIntOrNull()
            if (d == null || d < 72 || d > 960) { toast("Enter a DPI between 72 and 960"); return@btn }
            applyDisplay("wm density $d", if (over != null) "wm density $over" else "wm density reset") { load() }
        }
        val resetBtn = btn("Reset to default", false) {
            if (over == null) toast("Already at the default DPI")
            else applyDisplay("wm density reset", "wm density $over") { load() }
        }
        openPage("DPI changer", scrollBody(card(
            cur,
            hint("Lower DPI = smaller things, more on screen. Higher DPI = bigger things."),
            rowOf(half("80%") { scale(80) }, half("90%") { scale(90) }, half("110%") { scale(110) }),
            dF, applyBtn, resetBtn,
            hint("The screen goes back by itself after 15 seconds unless you tap Keep.")
        )))
        load()
    }
}
