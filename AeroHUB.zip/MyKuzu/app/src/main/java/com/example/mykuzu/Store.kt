package com.example.mykuzu

import android.content.Context
import java.security.SecureRandom

data class Grant(val pkg: String, val token: String, val enabled: Boolean)

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("mk", Context.MODE_PRIVATE)
    private fun randomToken() = ByteArray(24).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }

    /** Master token: only the MyKuzu app itself holds it. */
    fun token(c: Context): String {
        sp(c).getString("token", null)?.let { return it }
        val t = randomToken()
        sp(c).edit().putString("token", t).apply()
        return t
    }

    fun masterOn(c: Context) = sp(c).getBoolean("master_on", true)
    fun setMasterOn(c: Context, on: Boolean) = sp(c).edit().putBoolean("master_on", on).apply()

    fun autoStart(c: Context) = sp(c).getBoolean("auto_start", false)
    fun setAutoStart(c: Context, on: Boolean) = sp(c).edit().putBoolean("auto_start", on).apply()

    /** Last TCP port that worked (default 5555). */
    fun tcpPort(c: Context) = sp(c).getInt("tcp_port", 5555)
    fun setTcpPort(c: Context, p: Int) = sp(c).edit().putInt("tcp_port", p).apply()

    fun grants(c: Context): List<Grant> =
        (sp(c).getString("grants", "") ?: "").lines().filter { it.isNotBlank() }.mapNotNull {
            val p = it.split("|")
            if (p.size == 3) Grant(p[0], p[1], p[2] == "1") else null
        }

    private fun save(c: Context, l: List<Grant>) = sp(c).edit()
        .putString("grants", l.joinToString("\n") { "${it.pkg}|${it.token}|${if (it.enabled) 1 else 0}" }).apply()

    /** Allow an app (creates its own token) and return that token. */
    fun allow(c: Context, pkg: String): String {
        val l = grants(c).toMutableList()
        val i = l.indexOfFirst { it.pkg == pkg }
        val g = if (i >= 0) l[i].copy(enabled = true) else Grant(pkg, randomToken(), true)
        if (i >= 0) l[i] = g else l.add(g)
        save(c, l)
        return g.token
    }

    fun setEnabled(c: Context, pkg: String, on: Boolean) =
        save(c, grants(c).map { if (it.pkg == pkg) it.copy(enabled = on) else it })

    fun remove(c: Context, pkg: String) = save(c, grants(c).filter { it.pkg != pkg })

    fun activeTokens(c: Context): List<String> =
        if (!masterOn(c)) emptyList() else grants(c).filter { it.enabled }.map { it.token }

    /**
     * The shell command that launches the server. It runs inline (no script file needed).
     * The process name is built from a variable so that pkill never matches this shell itself.
     */
    const val LOG_FILE = "/data/local/tmp/aerohub_server.log"

    fun startCommand(c: Context, variant: Int = 0): String {
        val csv = activeTokens(c).joinToString(",").ifEmpty { "-" }
        if (variant == 1) {
            // Fallback (Shizuku style): CLASSPATH env + exec inside a detached subshell in its own session.
            return "N=mykuzu_serve; " +
                "pkill -f \"\${N}r\" 2>/dev/null; sleep 0.3; " +
                "APK=\$(pm path ${c.packageName} | head -n1 | cut -d: -f2); " +
                "echo \"apk=\$APK\" >$LOG_FILE; " +
                "( CLASSPATH=\$APK setsid sh -c 'exec app_process /system/bin --nice-name='\${N}'r com.example.mykuzu.server.Server ${token(c)} $csv' >>$LOG_FILE 2>&1 </dev/null & ) ; " +
                "echo MyKuzu started"
        }
        return "N=mykuzu_serve; " +
            "pkill -f \"\${N}r\" 2>/dev/null; sleep 0.3; " +
            "APK=\$(pm path ${c.packageName} | head -n1 | cut -d: -f2); " +
            "S=; command -v setsid >/dev/null 2>&1 && S=setsid; " +
            "\$S nohup app_process -Djava.class.path=\$APK /system/bin --nice-name=\${N}r " +
            "com.example.mykuzu.server.Server ${token(c)} $csv >$LOG_FILE 2>&1 </dev/null & " +
            "echo MyKuzu started"
    }

    /** Tell a running server which apps are allowed right now. */
    fun push(c: Context) {
        Thread { runCatching { MyKuzu.sync(token(c), activeTokens(c)) } }.start()
    }
}
