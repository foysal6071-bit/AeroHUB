package com.example.mykuzu

import android.content.Context
import android.os.Build
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date

/** ADB client (pairing + TCP/TLS connect). Keys are generated once and stored privately. */
class AdbMgr private constructor(ctx: Context) : AbsAdbConnectionManager() {
    private val priv: PrivateKey
    private val cert: Certificate

    init {
        setApi(Build.VERSION.SDK_INT)
        val kf = File(ctx.filesDir, "adb_key")
        val cf = File(ctx.filesDir, "adb_cert")
        if (kf.exists() && cf.exists()) {
            priv = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
            cert = cf.inputStream().use { CertificateFactory.getInstance("X.509").generateCertificate(it) }
        } else {
            val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
            val name = X500Name("CN=MyKuzu")
            val now = Date()
            val end = Date(now.time + 3650L * 24 * 3600 * 1000)
            val builder = JcaX509v3CertificateBuilder(
                name, BigInteger.valueOf(System.nanoTime() and Long.MAX_VALUE), now, end, name, kp.public
            )
            val signer = JcaContentSignerBuilder("SHA512withRSA").build(kp.private)
            val c = JcaX509CertificateConverter().getCertificate(builder.build(signer))
            kf.writeBytes(kp.private.encoded)
            cf.writeBytes(c.encoded)
            priv = kp.private
            cert = c
        }
    }

    override fun getPrivateKey(): PrivateKey = priv
    override fun getCertificate(): Certificate = cert
    override fun getDeviceName(): String = "MyKuzu"

    companion object {
        /** Connects to adbd and runs the MyKuzu start script as the ADB shell user. */
        fun runStart(c: Context, host: String, port: Int) {
            Store.writeScript(c)
            val m = get(c)
            if (!m.connect(host, port)) throw IllegalStateException("Could not connect to $host:$port")
            try {
                m.openStream("shell:sh ${Store.script(c).absolutePath}").use { st ->
                    // don't wait forever: the shell may keep the stream open
                    val t = Thread { runCatching { st.openInputStream().readBytes() } }
                    t.start(); t.join(8000)
                }
            } finally { runCatching { m.disconnect() } }
        }

        @Volatile private var inst: AdbMgr? = null
        fun get(c: Context): AdbMgr = inst ?: synchronized(this) {
            inst ?: AdbMgr(c.applicationContext).also { inst = it }
        }
    }
}
