package com.example.mykuzu

import android.content.Context
import android.os.Build
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.net.InetSocketAddress
import java.net.Socket
import java.security.Principal
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLEngine
import javax.net.ssl.X509ExtendedKeyManager
import javax.net.ssl.X509ExtendedTrustManager
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/** ADB client (pairing + TCP/TLS connect). Keys are generated once and stored privately. */
class AdbMgr private constructor(ctx: Context) : AbsAdbConnectionManager() {
    private val priv: PrivateKey
    private val cert: Certificate

    init {
        setApi(Build.VERSION.SDK_INT)
        val kf = File(ctx.filesDir, "adb_key")
        val cf = File(ctx.filesDir, "adb_cert")
        if (kf.exists() && cf.exists()) {
            priv = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
            cert = cf.inputStream().use { CertificateFactory.getInstance("X.509").generateCertificate(it) }
        } else {
            val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
            val name = X500Name("CN=MyKuzu")
            val now = Date()
            val end = Date(now.time + 3650L * 24 * 3600 * 1000)
            val builder = JcaX509v3CertificateBuilder(
                name, BigInteger.valueOf(System.nanoTime() and Long.MAX_VALUE), now, end, name, kp.public
            )
            val signer = JcaContentSignerBuilder("SHA512withRSA").build(kp.private)
            val c = JcaX509CertificateConverter().getCertificate(builder.build(signer))
            kf.writeBytes(kp.private.encoded)
            cf.writeBytes(c.encoded)
            priv = kp.private
            cert = c
        }
        installTls(priv, cert)
    }

    /**
     * Shizuku-style TLS setup. libadb's own key manager only answers for "RSA" socket requests and has no
     * engine variant, so on some Android versions NO client certificate is sent and adbd drops the TLS
     * handshake even though pairing worked. Here the key manager answers every request (socket and engine),
     * and the context is put where libadb looks it up (its cached SSLContext).
     */
    private fun installTls(key: PrivateKey, c: Certificate) {
        try {
            val km = object : X509ExtendedKeyManager() {
                override fun getClientAliases(keyType: String?, issuers: Array<out Principal>?): Array<String>? = arrayOf("key")
                override fun chooseClientAlias(keyType: Array<out String>?, issuers: Array<out Principal>?, socket: Socket?): String? = "key"
                override fun chooseEngineClientAlias(keyType: Array<out String>?, issuers: Array<out Principal>?, engine: SSLEngine?): String? = "key"
                override fun getServerAliases(keyType: String?, issuers: Array<out Principal>?): Array<String>? = null
                override fun chooseServerAlias(keyType: String?, issuers: Array<out Principal>?, socket: Socket?): String? = null
                override fun getCertificateChain(alias: String?): Array<X509Certificate>? = arrayOf(c as X509Certificate)
                override fun getPrivateKey(alias: String?): PrivateKey? = key
            }
            val tm = object : X509ExtendedTrustManager() {
                override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?, socket: Socket?) {}
                override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?, socket: Socket?) {}
                override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?, engine: SSLEngine?) {}
                override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?, engine: SSLEngine?) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
            }
            val ctx = try { SSLContext.getInstance("TLSv1.3") } catch (e: Exception) { SSLContext.getInstance("TLS") }
            ctx.init(arrayOf(km), arrayOf(tm), java.security.SecureRandom())
            val f = Class.forName("io.github.muntashirakon.adb.SslUtils").getDeclaredField("sslContext")
            f.isAccessible = true
            f.set(null, ctx)
            android.util.Log.i("MyKuzu", "TLS context installed")
        } catch (e: Throwable) {
            android.util.Log.e("MyKuzu", "Could not install TLS context, using library default", e)
            lastDetail = "TLS setup: " + e
        }
    }

    override fun getPrivateKey(): PrivateKey = priv
    override fun getCertificate(): Certificate = cert
    override fun getDeviceName(): String = "MyKuzu"

    companion object {
        @Volatile private var inst: AdbMgr? = null
        /** Full technical detail of the last failed connect (shown in "Check connection"). */
        @Volatile var lastDetail: String = ""
        fun get(c: Context): AdbMgr = inst ?: synchronized(this) {
            inst ?: AdbMgr(c.applicationContext).also { inst = it }
        }

        /** Quick check: is anything listening on host:port? Tells "port closed" apart from "refused/unauthorised". */
        fun reachable(host: String, port: Int, ms: Int = 2500): Boolean = try {
            Socket().use { it.connect(InetSocketAddress(host, port), ms) }
            true
        } catch (e: Exception) { false }

        /** Runs [f] on a worker thread and gives up after [sec] seconds (adb calls can hang forever). */
        private fun <T> timed(sec: Long, what: String, f: () -> T): T {
            val ex = Executors.newSingleThreadExecutor()
            try {
                val fut = ex.submit(Callable<T> { f() })
                try {
                    return fut.get(sec, TimeUnit.SECONDS)
                } catch (e: TimeoutException) {
                    fut.cancel(true)
                    throw IllegalStateException("Timed out while $what. If an \"Allow USB debugging?\" dialog appeared, tap \"Always allow\" and try again.")
                } catch (e: ExecutionException) {
                    throw e.cause ?: e
                }
            } finally { ex.shutdownNow() }
        }

        private fun rootOf(e: Throwable?): Throwable? {
            var t = e; var n = 0
            while (t?.cause != null && t.cause !== t && n++ < 8) t = t.cause
            return t
        }

        private fun explain(e: Throwable?): String {
            val chain = generateSequence(e) { it.cause?.takeIf { c -> c !== it } }.take(8).toList()
            val names = chain.joinToString(" / ") { it.javaClass.simpleName }
            val root = rootOf(e)
            val m = root?.message ?: e?.message ?: root?.javaClass?.simpleName ?: "unknown error"
            return when {
                e?.message?.startsWith("Timed out") == true -> e!!.message!!
                names.contains("Pairing") ->
                    "This phone has not paired with this app (or the pairing was removed). Open Developer options -> Wireless debugging -> Paired devices, forget \"MyKuzu\", then pair again in the Wireless tab."
                names.contains("Auth") ->
                    "ADB authentication failed. Accept the \"Allow USB debugging?\" dialog on this phone (tick \"Always allow\"), or pair again in the Wireless tab."
                m == "Connection failed" || names.contains("SSL") ->
                    "adbd closed the connection ($names: $m). Wireless debugging: forget \"MyKuzu\" in Paired devices and pair again. TCP: accept the \"Allow USB debugging?\" dialog (tick Always allow) and try again."
                else -> "Could not connect: $names: $m"
            }
        }

        /** Connects to adbd with a pre-check, a timeout and up to 3 attempts. Always returns a connected manager or throws a readable error. */
        fun open(c: Context, host: String, port: Int): AdbMgr {
            if (!reachable(host, port)) throw IllegalStateException(
                "Nothing is listening on $host:$port. TCP is off or the port is different. " +
                "Use \"Enable TCP via Wireless\" in the TCP tab, or check the port number."
            )
            // A fresh manager for every connect: re-using one after disconnect() can leave libadb in a broken state,
            // which made the 2nd start (after Stop) fail even though everything was fine.
            runCatching { inst?.disconnect() }
            inst = null
            val m = get(c)
            var last: Throwable? = null
            for (attempt in 1..4) {
                runCatching { m.disconnect() }
                try {
                    if (timed(20, "connecting to $host:$port") { m.connect(host, port) }) return m
                    last = IllegalStateException("adbd refused the connection")
                } catch (e: Throwable) {
                    last = e
                    android.util.Log.e("MyKuzu", "adb connect $host:$port attempt $attempt failed", e)
                    lastDetail = "$host:$port attempt $attempt\n" + android.util.Log.getStackTraceString(e).lines().take(14).joinToString("\n")
                    if (e.message?.startsWith("Timed out") == true) break
                }
                Thread.sleep(1000L * attempt)
            }
            throw IllegalStateException(explain(last))
        }

        fun pairWith(c: Context, host: String, port: Int, code: String): Boolean {
            val m = get(c)
            return timed(20, "pairing") { m.pair(host, port, code) }
        }

        /** Connects to adbd and runs the MyKuzu start command as the ADB shell user. */
        fun runStart(c: Context, host: String, port: Int, variant: Int = 0) {
            val m = open(c, host, port)
            try {
                val st = m.openStream("shell:" + Store.startCommand(c, variant))
                runCatching { st.openInputStream().readBytes() }
                runCatching { st.close() }
            } finally { runCatching { m.disconnect() } }
        }

        /** Reads the server's own log and process list over adb, to explain why it did not start. */
        fun readServerLog(c: Context, host: String, port: Int): String = try {
            val m = open(c, host, port)
            try {
                val st = m.openStream("shell:cat ${Store.LOG_FILE} 2>&1 | tail -n 25; echo ---; ps -A 2>/dev/null | grep mykuzu")
                val out = String(st.openInputStream().readBytes()).trim()
                runCatching { st.close() }
                out.ifEmpty { "(empty)" }
            } finally { runCatching { m.disconnect() } }
        } catch (e: Throwable) { "(could not read log: ${e.message})" }

        /**
         * Asks adbd to restart in TCP mode (same as `adb tcpip <port>`), over an already paired connection.
         * adbd restarts right after the command and drops the connection, so errors AFTER the command
         * was sent are normal and ignored. The caller checks that the port opened.
         */
        fun enableTcp(c: Context, host: String, port: Int, tcpPort: Int) {
            val m = open(c, host, port)
            try {
                val st = m.openStream("tcpip:$tcpPort")
                runCatching { st.openInputStream().readBytes() }
                runCatching { st.close() }
            } finally { runCatching { m.disconnect() } }
        }
    }
}
