package com.example.mykuzu

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Small rolling log of what the watchdog saw (screen on/off, server not answering, restarts). Shown in "Check connection". */
object WdLog {
    private fun file(c: Context) = File(c.filesDir, "watchdog.log")

    @Synchronized
    fun add(c: Context, msg: String) {
        runCatching {
            val f = file(c)
            if (f.length() > 24_000) f.writeText(f.readText().takeLast(12_000).substringAfter('\n'))
            f.appendText(SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date()) + " " + msg + "\n")
        }
    }

    @Synchronized
    fun tail(c: Context, n: Int): String =
        runCatching { file(c).readLines().takeLast(n).joinToString("\n") }.getOrDefault("")
}
