package com.example.mykuzu

import android.app.Application
import org.conscrypt.Conscrypt
import java.security.Security

class MyKuzuApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // TLS 1.3 provider needed for ADB wireless pairing / TLS connection
        Security.insertProviderAt(Conscrypt.newProvider(), 1)
    }
}
