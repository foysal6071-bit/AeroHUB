package com.example.mykuzu

import android.app.Application
import org.conscrypt.Conscrypt
import java.security.Security

class MyKuzuApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // TLS 1.3 provider needed for ADB wireless pairing / TLS connection
        Security.insertProviderAt(Conscrypt.newProvider(), 1)
        // Binder transport (like Shizuku). The server hands its Binder to BinderProvider; when that Binder dies the watchdog
        // restarts the server at once instead of waiting for its next check.
        MyKuzu.init(this)
        MyKuzu.onServerDied = {
            WdLog.add(this, "server Binder died: restarting now")
            if (Store.wanted(this) || Store.autoStart(this)) { WatchdogService.start(this); WatchdogService.kick() }
        }
        // A freshly started AeroHUB has no Binder yet: if the server does not push it within 1.5 s, ask for it.
        Thread {
            Thread.sleep(1500)
            if (!MyKuzu.binderAlive()) runCatching { MyKuzu.requestPush(Store.token(this)) }
        }.start()
    }
}
