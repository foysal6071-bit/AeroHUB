package com.example.mykuzu

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.os.Binder
import android.os.Bundle
import java.security.MessageDigest

/**
 * Where the Binders meet (the Shizuku way):
 *  - "sendBinder": the server (adb shell / root) hands over its Binder. Nobody else may call it.
 *  - "getBinder": an app that holds an AeroHUB token asks for the server's Binder.
 */
class BinderProvider : ContentProvider() {
    override fun onCreate() = true

    private fun same(a: String, b: String) = MessageDigest.isEqual(a.toByteArray(), b.toByteArray())

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle? {
        val c = context ?: return null
        when (method) {
            "sendBinder" -> {
                val uid = Binder.getCallingUid()
                if (uid != 2000 && uid != 0) return null
                val b = extras?.getBinder("b") ?: return null
                // A new server process (restart, supervisor revival, boot) only knows the tokens it was started with. Give it the
                // current list of allowed apps at once, otherwise apps like Control Center are refused ("DENIED") until AeroHUB is opened.
                val fresh = MyKuzu.currentBinder() !== b
                MyKuzu.setBinder(b)
                if (fresh) Store.push(c)
                // The server found us (possibly it just started this process): make sure the watchdog runs.
                if (Store.wanted(c) || Store.autoStart(c)) WatchdogService.start(c)
                return Bundle()
            }
            "getBinder" -> {
                val t = arg ?: return null
                val ok = same(t, Store.token(c)) || Store.activeTokens(c).any { same(t, it) }
                if (!ok) return null
                val b = MyKuzu.currentBinder()
                if (b == null) {
                    // We do not have it yet (this process was just started): ask the server to send it again.
                    Thread { runCatching { MyKuzu.requestPush(Store.token(c)) } }.start()
                    return Bundle()
                }
                return Bundle().apply { putBinder("b", b) }
            }
        }
        return null
    }

    override fun query(u: Uri, p: Array<out String>?, s: String?, a: Array<out String>?, o: String?): Cursor? = null
    override fun getType(u: Uri): String? = null
    override fun insert(u: Uri, v: ContentValues?): Uri? = null
    override fun delete(u: Uri, s: String?, a: Array<out String>?) = 0
    override fun update(u: Uri, v: ContentValues?, s: String?, a: Array<out String>?) = 0
}
