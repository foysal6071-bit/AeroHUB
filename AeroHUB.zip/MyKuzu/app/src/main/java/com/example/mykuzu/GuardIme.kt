package com.example.mykuzu

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo

/**
 * A "do nothing" keyboard. It only exists so MyKuzu can be an enabled keyboard in the system.
 * It never reads, stores or sends any text. If it is ever selected by mistake, it hands typing
 * straight back to the previous keyboard.
 */
class GuardIme : InputMethodService() {
    override fun onCreateInputView(): View = View(this).apply { layoutParams = ViewGroup.LayoutParams(-1, 1) }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        try { switchToPreviousInputMethod() } catch (_: Throwable) {}
    }
}
