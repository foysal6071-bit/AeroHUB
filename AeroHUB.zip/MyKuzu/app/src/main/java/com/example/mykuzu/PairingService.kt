package com.example.mykuzu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Wireless debugging pairing through a notification:
 * finds the pairing port automatically, you type the code in the notification,
 * then it pairs, finds the connect port and starts the MyKuzu server.
 */
class PairingService : Service() {
    companion object {
        const val ACTION_START = "com.example.mykuzu.pair.START"
        const val ACTION_CODE = "com.example.mykuzu.pair.CODE"
        private const val KEY = "code"
        private const val CH = "pairing"
        private const val ID = 71
    }

    private var mdns: Mdns? = null
    @Volatile private var port = -1
    @Volatile private var pairHost = "127.0.0.1"
    private val nm by lazy { getSystemService(NotificationManager::class.java) }
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        nm.createNotificationChannel(NotificationChannel(CH, "Pairing", NotificationManager.IMPORTANCE_HIGH))
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ done("Pairing timed out") }, 5 * 60 * 1000L)
        if (i?.action == ACTION_CODE) {
            val code = RemoteInput.getResultsFromIntent(i)?.getCharSequence(KEY)?.toString()?.trim()
            fg(note("Pairing…", "Please wait", false))
            Thread { pair(code) }.start()
        } else {
            fg(note("Looking for pairing service…", "Open Wireless debugging and tap \"Pair device with pairing code\"", false))
            if (mdns == null) {
                mdns = Mdns(this, "_adb-tls-pairing._tcp", { port = -1 }) { h, p ->
                    if (p != port) {
                        port = p; pairHost = h
                        nm.notify(ID, note("Pairing service found", "Tap \"Enter code\" and type the 6-digit code", true))
                    }
                }.also { it.start() }
            }
        }
        return START_NOT_STICKY
    }

    private fun fg(n: Notification) {
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        else startForeground(ID, n)
    }

    private fun note(title: String, text: String, withInput: Boolean): Notification {
        val b = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(text)
            .setOngoing(true).setOnlyAlertOnce(true)
        if (withInput) {
            val ri = RemoteInput.Builder(KEY).setLabel("6-digit pairing code").build()
            val pi = PendingIntent.getForegroundService(
                this, 1, Intent(this, PairingService::class.java).setAction(ACTION_CODE),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            b.addAction(
                Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_edit), "Enter code", pi)
                    .addRemoteInput(ri).build()
            )
        }
        return b.build()
    }

    private fun err(e: Throwable) = "${e.javaClass.simpleName}: ${e.message ?: "no details"}"

    private fun pair(code: String?) {
        if (code.isNullOrEmpty() || port <= 0) {
            nm.notify(ID, note("Could not pair", "Open \"Pair device with pairing code\" again, then enter the code", port > 0)); return
        }
        try {
            val mgr = AdbMgr.get(this)
            var ok = false
            var last: Throwable? = null
            for (h in listOf("127.0.0.1", pairHost).distinct()) {
                try { if (mgr.pair(h, port, code)) { ok = true; break } } catch (e: Throwable) { last = e }
            }
            if (!ok) error(last?.let { "Pairing: " + err(it) } ?: "Wrong code or pairing window closed")

            nm.notify(ID, note("Paired", "Finding the connection port…", false))
            val (chost, cport) = connectTarget() ?: error("Connection port not found. Keep Wi-Fi and Wireless debugging on")

            nm.notify(ID, note("Connecting…", "Port $cport", false))
            startServer(chost, cport)

            nm.notify(ID, note("Starting server…", "Waiting for it to answer", false))
            var up = false
            for (i in 0 until 12) { if (MyKuzu.ping(Store.token(this)) != null) { up = true; break }; Thread.sleep(700) }
            done(if (up) "MyKuzu server is running" else "Paired, but the server did not start. See /data/local/tmp/mykuzu.log")
        } catch (e: Throwable) {
            nm.notify(ID, note("Pairing failed", err(e), port > 0))
        }
    }

    /** Tries loopback first, then the Wi-Fi address; retries because adbd needs a moment after pairing. */
    private fun startServer(host: String, p: Int) {
        var last: Throwable? = null
        for (h in listOf("127.0.0.1", host).distinct()) {
            for (i in 0 until 3) {
                try { AdbMgr.runStart(this, h, p); return } catch (e: Throwable) { last = e; Thread.sleep(900) }
            }
        }
        throw IllegalStateException("Connect failed (${last?.let { err(it) }})")
    }

    private fun connectTarget(): Pair<String, Int>? {
        val latch = CountDownLatch(1)
        var r: Pair<String, Int>? = null
        val d = Mdns(this, "_adb-tls-connect._tcp") { h, x -> if (r == null) { r = h to x; latch.countDown() } }
        d.start()
        latch.await(12, TimeUnit.SECONDS)
        d.stop()
        return r
    }

    private fun done(msg: String) {
        handler.removeCallbacksAndMessages(null)
        mdns?.stop(); mdns = null
        stopForeground(STOP_FOREGROUND_DETACH)
        nm.notify(ID, Notification.Builder(this, CH).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("MyKuzu").setContentText(msg).setAutoCancel(true).build())
        stopSelf()
    }

    override fun onDestroy() { mdns?.stop(); super.onDestroy() }
}
