package com.example.mykuzu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Wireless debugging pairing through a notification:
 * finds the pairing port automatically, you type the code in the notification,
 * then it pairs, finds the connect port and starts the MyKuzu server.
 */
class PairingService : Service() {
    companion object {
        const val ACTION_START = "com.example.mykuzu.pair.START"
        const val ACTION_CODE = "com.example.mykuzu.pair.CODE"
        private const val KEY = "code"
        // New channel id: a channel keeps the settings it was first created with, so the old one cannot be made to pop up.
        private const val CH = "pairing_popup"
        private const val ID = 71
        /** Progress the app shows after it comes to the front. [busy] is true from the moment the code is accepted until the end. */
        @Volatile var busy = false
        @Volatile var status = ""
    }

    private var mdns: Mdns? = null
    @Volatile private var port = -1
    private val nm by lazy { getSystemService(NotificationManager::class.java) }
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        nm.createNotificationChannel(NotificationChannel(CH, "Pairing code (popup)", NotificationManager.IMPORTANCE_HIGH).apply {
            enableVibration(true); setShowBadge(false); lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        })
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ done("Pairing timed out") }, 5 * 60 * 1000L)
        if (i?.action == ACTION_CODE) {
            val code = RemoteInput.getResultsFromIntent(i)?.getCharSequence(KEY)?.toString()?.trim()
            fg(note("Pairing…", "Please wait", false))
            Thread { pair(code) }.start()
        } else {
            fg(note("Looking for pairing service…", "Open Wireless debugging and tap \"Pair device with pairing code\"", false))
            if (mdns == null) {
                mdns = Mdns(this, "_adb-tls-pairing._tcp") { _, p ->
                    if (p != port) {
                        port = p
                        nm.notify(ID, note("Pairing service found", "Tap \"Enter code\" and type the 6-digit code", true))
                    }
                }.also { it.start() }
            }
        }
        return START_NOT_STICKY
    }

    private fun fg(n: Notification) {
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        else startForeground(ID, n)
    }

    private fun note(title: String, text: String, withInput: Boolean): Notification {
        val b = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(text)
            .setOngoing(true)
            // The "enter code" notification must alert again (popup), even though it replaces the "looking" one.
            .setOnlyAlertOnce(!withInput)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        if (withInput) {
            val ri = RemoteInput.Builder(KEY).setLabel("6-digit pairing code").build()
            val pi = PendingIntent.getForegroundService(
                this, 1, Intent(this, PairingService::class.java).setAction(ACTION_CODE),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            b.addAction(
                Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_edit), "Enter code", pi)
                    .addRemoteInput(ri).build()
            )
        }
        return b.build()
    }

    private fun pair(code: String?) {
        if (code.isNullOrEmpty() || port <= 0) {
            nm.notify(ID, note("Could not pair", "Enter the code again", port > 0)); return
        }
        busy = true; status = "Pairing…"
        try {
            if (!AdbMgr.pairWith(this, "127.0.0.1", port, code)) error("Wrong code or pairing window closed")
            status = "Paired. Connecting…"
            nm.notify(ID, note("Paired", "Connecting…", false))
            val cport = connectPort() ?: error("Wireless debugging port not found. Is Wi-Fi on?")
            bringAppToFront(cport)
            status = "Connecting… starting the server"
            AdbMgr.runStart(this, "127.0.0.1", cport)
            Thread.sleep(1200)
            val ok = MyKuzu.ping(Store.token(this)) != null
            done(if (ok) "AeroHUB server is running" else "Start command sent. Open AeroHUB to check")
        } catch (e: Throwable) {
            busy = false; status = "Pairing failed: " + (e.message ?: "try again")
            nm.notify(ID, note("Pairing failed", e.message ?: "Try again", port > 0))
        }
    }

    /**
     * Brings AeroHUB back to the front as soon as the connection works. A service cannot open an activity from the
     * background on new Android versions, but the ADB shell can, so the second try runs "am start" through adb.
     */
    private fun bringAppToFront(cport: Int) {
        runCatching {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
        }
        runCatching { AdbMgr.runShell(this, "127.0.0.1", cport, "am start -n $packageName/com.example.mykuzu.MainActivity") }
    }

    private fun connectPort(): Int? = Mdns.findLocal(this, "_adb-tls-connect._tcp", 15)?.second

    private fun done(msg: String) {
        busy = false; status = msg
        handler.removeCallbacksAndMessages(null)
        mdns?.stop(); mdns = null
        stopForeground(STOP_FOREGROUND_DETACH)
        nm.notify(ID, Notification.Builder(this, CH).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("AeroHUB").setContentText(msg).setAutoCancel(true).build())
        stopSelf()
    }

    override fun onDestroy() { mdns?.stop(); super.onDestroy() }
}
