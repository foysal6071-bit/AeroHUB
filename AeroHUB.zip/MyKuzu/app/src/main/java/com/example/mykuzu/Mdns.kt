package com.example.mykuzu

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Handler
import android.os.Looper
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Finds the Wireless debugging services (pairing / connect) advertised on this device via mDNS. */
class Mdns(ctx: Context, private val type: String, private val onFound: (host: String, port: Int) -> Unit) {
    private val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var listener: NsdManager.DiscoveryListener? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var stopped = false

    /** Resolving can fail with "already active" when several services show up together, so retry a few times. */
    @Suppress("DEPRECATION")
    private fun resolve(s: NsdServiceInfo, left: Int) {
        if (stopped) return
        try {
            nsd.resolveService(s, object : NsdManager.ResolveListener {
                override fun onResolveFailed(si: NsdServiceInfo, errorCode: Int) {
                    if (left > 0 && !stopped) main.postDelayed({ resolve(s, left - 1) }, 400)
                }
                override fun onServiceResolved(r: NsdServiceInfo) {
                    if (!stopped) onFound(r.host?.hostAddress ?: "127.0.0.1", r.port)
                }
            })
        } catch (e: Exception) {
            if (left > 0 && !stopped) main.postDelayed({ resolve(s, left - 1) }, 400)
        }
    }

    fun start() {
        stopped = false
        val l = object : NsdManager.DiscoveryListener {
            override fun onServiceFound(s: NsdServiceInfo) { resolve(s, 5) }
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onServiceLost(s: NsdServiceInfo) {}
        }
        listener = l
        nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, l)
    }

    fun stop() {
        stopped = true
        listener?.let { runCatching { nsd.stopServiceDiscovery(it) } }
        listener = null
    }

    companion object {
        /**
         * Like [findOne], but only accepts a service whose port really answers on THIS phone (127.0.0.1).
         * This skips stale mDNS entries (old port after Wireless debugging was toggled) and
         * services of other devices on the same Wi-Fi, which made "connect" fail before.
         */
        fun findLocal(ctx: Context, type: String, sec: Long): Pair<String, Int>? {
            val found = java.util.concurrent.ConcurrentLinkedQueue<Pair<String, Int>>()
            val d = Mdns(ctx, type) { host, port -> found.add(host to port) }
            d.start()
            try {
                val end = System.currentTimeMillis() + sec * 1000
                while (System.currentTimeMillis() < end) {
                    for (c in found.toList()) {
                        // Some phones only listen on the Wi-Fi address, not on 127.0.0.1, so accept either.
                        if (AdbMgr.reachable("127.0.0.1", c.second, 700) ||
                            (c.first != "127.0.0.1" && AdbMgr.reachable(c.first, c.second, 700))) return c
                    }
                    Thread.sleep(300)
                }
            } finally { d.stop() }
            return null
        }

        /** Waits up to [sec] seconds for the first service of [type]. Returns host to port, or null. */
        fun findOne(ctx: Context, type: String, sec: Long): Pair<String, Int>? {
            val latch = CountDownLatch(1)
            var res: Pair<String, Int>? = null
            val d = Mdns(ctx, type) { host, port ->
                if (res == null) { res = host to port; latch.countDown() }
            }
            d.start()
            latch.await(sec, TimeUnit.SECONDS)
            d.stop()
            return res
        }
    }
}
