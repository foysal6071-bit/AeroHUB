package com.example.mykuzu

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Handler
import android.os.Looper

/** Finds the Wireless debugging services (pairing / connect) advertised on this device via mDNS. */
class Mdns(
    ctx: Context,
    private val type: String,
    private val onLost: (() -> Unit)? = null,
    private val onFound: (host: String, port: Int) -> Unit
) {
    private val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var listener: NsdManager.DiscoveryListener? = null

    private fun resolve(s: NsdServiceInfo, tries: Int) {
        @Suppress("DEPRECATION")
        nsd.resolveService(s, object : NsdManager.ResolveListener {
            override fun onResolveFailed(si: NsdServiceInfo, errorCode: Int) {
                // e.g. FAILURE_ALREADY_ACTIVE: another resolve is running, try again shortly
                if (tries < 6 && listener != null) main.postDelayed({ if (listener != null) resolve(si, tries + 1) }, 400L)
            }
            override fun onServiceResolved(r: NsdServiceInfo) {
                val h = r.host?.hostAddress?.substringBefore('%') ?: "127.0.0.1"
                onFound(h, r.port)
            }
        })
    }

    fun start() {
        val l = object : NsdManager.DiscoveryListener {
            override fun onServiceFound(s: NsdServiceInfo) { resolve(s, 0) }
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onServiceLost(s: NsdServiceInfo) { onLost?.invoke() }
        }
        listener = l
        nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, l)
    }

    fun stop() {
        main.removeCallbacksAndMessages(null)
        listener?.let { runCatching { nsd.stopServiceDiscovery(it) } }
        listener = null
    }
}
