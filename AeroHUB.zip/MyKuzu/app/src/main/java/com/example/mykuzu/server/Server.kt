package com.example.mykuzu.server

import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.Base64
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.system.exitProcess

/**
 * Runs as shell (adb) or root via app_process.
 * Args: <masterToken> [comma-separated app tokens or "-"]
 * The master token (MyKuzu app) can SYNC the allowed app tokens at any time, which is how apps are turned on/off.
 * Commands: PING, EXEC <base64>, SYNC <tokens>, LOG (master), STOP (master).
 */
object Server {
    const val PORT = 27183
    const val VERSION = 2
    private const val MAX_OUT = 512 * 1024
    private const val TIMEOUT_SEC = 60L
    @Volatile private var appTokens: Set<String> = emptySet()
    private val log = ConcurrentLinkedDeque<String>()

    private fun parse(s: String?): Set<String> =
        s?.split(",")?.filter { it.length >= 16 }?.toSet() ?: emptySet()

    private fun eq(a: String, b: String) = MessageDigest.isEqual(a.toByteArray(), b.toByteArray())

    private fun addLog(who: String, code: Int, cmd: String) {
        val c = Base64.getEncoder().encodeToString(cmd.take(300).toByteArray())
        log.addLast("${System.currentTimeMillis()}|$who|$code|$c")
        while (log.size > 200) log.pollFirst()
    }

    @JvmStatic
    fun main(args: Array<String>) {
        val token = args.getOrNull(0) ?: exitProcess(1)
        appTokens = parse(args.getOrNull(1))
        // SO_REUSEADDR + retry: after a Stop the old port sits in TIME_WAIT for ~1 minute, and a plain bind then fails
        // silently, which is why the 2nd start never worked.
        var ss: ServerSocket? = null
        var lastErr: Exception? = null
        repeat(40) {
            if (ss == null) {
                try {
                    ss = ServerSocket().apply {
                        reuseAddress = true
                        bind(java.net.InetSocketAddress(InetAddress.getByName("127.0.0.1"), PORT), 50)
                    }
                } catch (e: Exception) { lastErr = e; Thread.sleep(500) }
            }
        }
        val server = ss ?: run { System.err.println("bind failed on port $PORT: $lastErr"); exitProcess(2) }
        System.err.println("AeroHUB server listening on $PORT")
        while (true) {
            val s = server.accept()
            thread { try { handle(s, token) } catch (_: Exception) {} }
        }
    }

    /** Runs a command with a time limit and an output cap. Exit code 124 means it timed out. */
    private fun runCmd(cmd: String): Pair<Int, ByteArray> {
        val proc = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        runCatching { proc.outputStream.close() }
        val buf = ByteArrayOutputStream()
        val rd = thread(isDaemon = true) {
            try {
                val b = ByteArray(8192)
                val ins = proc.inputStream
                while (true) {
                    val n = ins.read(b)
                    if (n < 0) break
                    synchronized(buf) {
                        val room = MAX_OUT - buf.size()
                        if (room > 0) buf.write(b, 0, minOf(n, room))
                    }
                }
            } catch (_: Exception) {}
        }
        val done = proc.waitFor(TIMEOUT_SEC, TimeUnit.SECONDS)
        if (!done) proc.destroyForcibly()
        rd.join(1500)
        val bytes = synchronized(buf) { buf.toByteArray() }
        val extra = if (!done) "\n[timed out after ${TIMEOUT_SEC}s]".toByteArray() else ByteArray(0)
        return (if (done) proc.exitValue() else 124) to (bytes + extra)
    }

    private fun handle(s: Socket, token: String) {
        s.use {
            s.soTimeout = 15000
            val line = BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: return
            val out = s.getOutputStream()
            fun reply(t: String) { out.write((t + "\n").toByteArray()); out.flush() }
            val p = line.split(" ", limit = 3)
            if (p.size < 2) { reply("DENIED"); return }
            val isMaster = eq(p[0], token)
            val isApp = !isMaster && appTokens.any { eq(p[0], it) }
            if (!isMaster && !isApp) { reply("DENIED"); return }
            when (p[1]) {
                "PING" -> reply("OK ${android.os.Process.myUid()} $VERSION")
                "EXEC" -> {
                    val cmd = String(Base64.getDecoder().decode(p.getOrElse(2) { "" }))
                    val (code, bytes) = runCmd(cmd)
                    addLog(if (isMaster) "app" else p[0].take(8), code, cmd)
                    reply("$code " + Base64.getEncoder().encodeToString(bytes))
                }
                "SYNC" -> if (isMaster) { appTokens = parse(p.getOrNull(2)); reply("OK") } else reply("DENIED")
                "LOG" -> if (isMaster) reply("OK " + log.joinToString(";")) else reply("DENIED")
                "STOP" -> if (isMaster) { reply("OK"); exitProcess(0) } else reply("DENIED")
                else -> reply("ERR unknown")
            }
        }
    }
}
