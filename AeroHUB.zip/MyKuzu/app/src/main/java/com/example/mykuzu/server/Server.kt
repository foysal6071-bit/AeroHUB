package com.example.mykuzu.server

import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.Base64
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.system.exitProcess

/**
 * Runs as shell (adb) or root via app_process.
 * Args: <masterToken> [comma-separated app tokens or "-"]
 * The master token (MyKuzu app) can SYNC the allowed app tokens at any time, which is how apps are turned on/off.
 * Commands: PING, ACTIVITY, EXEC <base64>, UBLOCK <pkg> <1|0|?>, STREAM <base64>, SBFLAGS <what> <what2>, BEAT, SYNC <tokens>, LOG (master), STOP (master).
 */
object Server {
    const val PORT = 27183
    const val VERSION = 11
    /** Binder transport (like Shizuku): the server hands its Binder to AeroHUB's provider, apps then talk to it without any network. */
    private const val PKG = "com.example.mykuzu"
    private const val AUTH = "$PKG.binder"
    private const val DESC = "$PKG.IServer"
    private const val TX_REQUEST = 1
    private const val TX_STREAM = 2
    private const val BIG_REPLY = 100_000                 // longer replies travel through a pipe (a Binder transaction is limited to ~1 MB)
    @Volatile private var masterToken = ""
    @Volatile private var pushState = "not pushed yet"
    private const val MAX_OUT = 512 * 1024
    private const val TIMEOUT_SEC = 60L
    @Volatile private var appTokens: Set<String> = emptySet()
    private val log = ConcurrentLinkedDeque<String>()

    /* ---------- activity tracking: while any app is interacting, the server counts as "busy" ---------- */
    private val openConns = java.util.concurrent.atomic.AtomicInteger(0)      // connections being served right now (streams stay open)
    @Volatile private var lastActivity = System.currentTimeMillis()
    private const val BUSY_GRACE_MS = 120_000L                                // still "busy" this long after the last app command

    private fun touch() { lastActivity = System.currentTimeMillis() }
    /** [self] = connections of the caller itself that must not count (the watchdog's own query). */
    private fun busy(self: Int = 0): Boolean =
        openConns.get() - self > 0 || sbWhat != 0 || System.currentTimeMillis() - lastActivity < BUSY_GRACE_MS

    private fun parse(s: String?): Set<String> =
        s?.split(",")?.filter { it.length >= 16 }?.toSet() ?: emptySet()

    private fun eq(a: String, b: String) = MessageDigest.isEqual(a.toByteArray(), b.toByteArray())

    private fun addLog(who: String, code: Int, cmd: String) {
        val c = Base64.getEncoder().encodeToString(cmd.take(300).toByteArray())
        log.addLast("${System.currentTimeMillis()}|$who|$code|$c")
        while (log.size > 200) log.pollFirst()
    }

    @JvmStatic
    fun main(args: Array<String>) {
        val token = args.getOrNull(0) ?: exitProcess(1)
        masterToken = token
        appTokens = parse(args.getOrNull(1))
        // SO_REUSEADDR + retry: after a Stop the old port sits in TIME_WAIT for ~1 minute, and a plain bind then fails
        // silently, which is why the 2nd start never worked.
        var ss: ServerSocket? = null
        var lastErr: Exception? = null
        repeat(40) {
            if (ss == null) {
                try {
                    ss = ServerSocket().apply {
                        reuseAddress = true
                        bind(java.net.InetSocketAddress(InetAddress.getByName("127.0.0.1"), PORT), 50)
                    }
                } catch (e: Exception) { lastErr = e; Thread.sleep(500) }
            }
        }
        val server = ss ?: run { System.err.println("bind failed on port $PORT: $lastErr"); exitProcess(2) }
        System.err.println("AeroHUB server listening on $PORT")
        // Diagnostics: when and how the server stops. A shutdown-hook line means it got a signal / STOP; if the log
        // simply ends after an "alive" line, the process was killed (SIGKILL) and the last time tells when.
        fun ts() = java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        val adj = runCatching { java.io.File("/proc/self/oom_score_adj").readText().trim() }.getOrDefault("?")
        System.err.println("${ts()} start pid=${android.os.Process.myPid()} uid=${android.os.Process.myUid()} oom_score_adj=$adj v$VERSION")
        // Like Shizuku's libshizuku.so: leave the adb/shell session's cgroup so the process is not treated as part of a
        // (frozen / killed) app or session when the screen turns off. Best effort, every result goes to the server log.
        switchCgroup().forEach { System.err.println("${ts()} $it") }
        raiseOomProtection().let { System.err.println("${ts()} $it") }
        // Self-revival without adb or Wi-Fi: a tiny detached shell watches this process and starts a new server if it dies
        // (works with the phone locked, when Wireless debugging may be unreachable). STOP leaves a flag so it stays dead.
        runCatching { java.io.File(STOP_FLAG).delete() }
        System.err.println("${ts()} " + startSupervisor(token, args.getOrNull(1) ?: "-"))
        // Pause detector + cgroup guard. A frozen process (cgroup freezer / deep sleep) cannot answer the app for a few seconds after
        // screen on. The log line tells that apart from a real death, and the cgroup is moved again if the system put it back.
        thread(isDaemon = true, name = "pause-watch") {
            var last = System.currentTimeMillis()
            var tickN = 0
            var failedMoves = 0
            while (true) {
                Thread.sleep(1000)
                val now = System.currentTimeMillis()
                val gap = now - last; last = now
                if (gap > 3500) System.err.println("${ts()} pause detected: ${gap / 1000}s without running (frozen or CPU asleep), cgroup=${cgNow()}")
                if ((++tickN % 5 == 0 || gap > 3500) && failedMoves < 3 && !cgNow().contains("uid_0")) {
                    val r = switchCgroup()
                    if (cgNow().contains("uid_0")) { failedMoves = 0; System.err.println("${ts()} cgroup moved back to uid_0") }
                    else { failedMoves++; System.err.println("${ts()} cgroup guard: move failed ($failedMoves/3): " + r.lastOrNull()) }
                }
            }
        }
        // app_process installs a handler that KILLS the whole process on any uncaught exception in any thread. Log it instead,
        // so one stray error can never stop the server (and the log says what happened).
        Thread.setDefaultUncaughtExceptionHandler { t, e -> System.err.println("${ts()} uncaught in ${t.name}: $e") }
        Runtime.getRuntime().addShutdownHook(Thread { System.err.println("${ts()} shutdown hook: process is exiting (signal or STOP)") })
        thread(isDaemon = true) {
            while (true) {
                Thread.sleep(60_000)
                val a = runCatching { java.io.File("/proc/self/oom_score_adj").readText().trim() }.getOrDefault("?")
                System.err.println("${ts()} alive adj=$a binder=$pushState" + if (busy()) " (busy)" else "")
            }
        }
        // Android 12+ "phantom process killer" can kill background shell processes like this server. Switch it off (best effort).
        thread(isDaemon = true) {
            runCatching {
                runCmd("settings put global settings_enable_monitor_phantom_procs false 2>/dev/null; " +
                    "device_config put activity_manager max_phantom_processes 2147483647 2>/dev/null; exit 0")
            }
        }
        // While apps are interacting, repeat that protection now and then (the system can reset it) and keep the process at a low nice value.
        thread(isDaemon = true) {
            while (true) {
                Thread.sleep(60_000)
                if (busy()) runCatching {
                    runCmd("device_config put activity_manager max_phantom_processes 2147483647 2>/dev/null; exit 0")
                    System.err.println("${ts()} busy: protection refreshed (conns=${openConns.get()})")
                }
            }
        }
        // Hand the Binder to AeroHUB (and again every 30 s, so a restarted AeroHUB process gets it too; this also keeps AeroHUB itself alive).
        thread(isDaemon = true, name = "binder-push") {
            var lastMsg = ""
            while (true) {
                val r = try { pushBinder() } catch (e: Throwable) { "ERR " + (e.message ?: e.toString()).lineSequence().first() }
                pushState = r
                if (r != lastMsg) System.err.println("${ts()} binder push: $r")
                lastMsg = r
                Thread.sleep(if (r == "OK") 30_000 else 10_000)
            }
        }
        while (true) {
            val s = try { server.accept() } catch (e: Throwable) {
                System.err.println("${ts()} accept failed: $e")
                if (server.isClosed) exitProcess(3)
                Thread.sleep(200); continue
            }
            try { thread { try { handle(s, token) } catch (_: Throwable) {} } }
            catch (e: Throwable) { System.err.println("${ts()} cannot start handler: $e"); runCatching { s.close() } }
        }
    }

    /**
     * Moves this process into the root uid cgroup (Shizuku does the same: "switch cgroup, moved this process into ...").
     * Tries cgroup v2 first, then every v1 hierarchy listed in /proc/self/cgroup. Never throws.
     */
    private fun switchCgroup(): List<String> {
        val out = ArrayList<String>()
        val pid = android.os.Process.myPid().toString()
        val cands = LinkedHashSet<String>()
        cands.add("/sys/fs/cgroup/uid_0/cgroup.procs")
        cands.add("/sys/fs/cgroup/cgroup.procs")
        runCatching {
            java.io.File("/proc/self/cgroup").readLines().forEach { line ->
                val parts = line.split(":", limit = 3)
                if (parts.size == 3 && parts[1].isNotBlank()) {
                    parts[1].split(",").forEach { ctl ->
                        val name = ctl.removePrefix("name=")
                        cands.add("/sys/fs/cgroup/$name/uid_0/cgroup.procs")
                        cands.add("/dev/$name/uid_0/cgroup.procs")
                        cands.add("/acct/uid_0/cgroup.procs")
                    }
                }
            }
        }.onFailure { out.add("cgroup: cannot read /proc/self/cgroup (${it.message})") }
        var moved = 0
        for (path in cands) {
            val f = java.io.File(path)
            if (!f.exists()) continue
            try {
                java.io.FileOutputStream(f).use { it.write(pid.toByteArray()) }
                out.add("cgroup: moved pid $pid into $path"); moved++
                if (path.startsWith("/sys/fs/cgroup/uid_0/")) break      // v2 done, no need to try the rest
            } catch (e: Throwable) {
                out.add("cgroup: $path refused (${(e.message ?: e.toString()).lineSequence().first()})")
            }
        }
        if (moved == 0) out.add("cgroup: can't switch cgroup, every path refused or missing")
        val now = runCatching { java.io.File("/proc/self/cgroup").readText().trim().replace("\n", " ; ") }.getOrDefault("?")
        out.add("cgroup now: $now")
        return out
    }

    /** Asks the kernel to make the low-memory killer prefer other processes. The shell user is often refused; the result is logged. */
    private fun raiseOomProtection(): String = try {
        java.io.File("/proc/self/oom_score_adj").writeText("-900")
        "oom_score_adj set to -900"
    } catch (e: Throwable) {
        "oom_score_adj unchanged (${(e.message ?: e.toString()).lineSequence().first()})"
    }

    private const val STOP_FLAG = "/data/local/tmp/aerohub_stop"

    private fun q(x: String) = "'" + x.replace("'", "'\\''") + "'"

    /**
     * Starts a detached shell (own session) that waits for this process to die and then starts the server again,
     * unless STOP was requested or another server is already running. No adb needed, so it also works while the phone is locked.
     * The process name is built from a variable so that "pkill -f mykuzu_server" and pidof checks never match this shell.
     */
    private fun startSupervisor(token: String, csv: String): String = try {
        val apk = (System.getProperty("java.class.path") ?: System.getenv("CLASSPATH") ?: "").split(":").firstOrNull { it.isNotBlank() }
            ?: return "supervisor: apk path unknown, not started"
        val logPath = runCatching { java.nio.file.Files.readSymbolicLink(java.nio.file.Paths.get("/proc/self/fd/2")).toString() }
            .getOrNull()?.takeIf { it.startsWith("/") && !it.contains("/dev/null") } ?: "/data/local/tmp/aerohub_server.log"
        val me = android.os.Process.myPid()
        val script = "N=mykuzu_serve; " +
            "while kill -0 $me 2>/dev/null; do sleep 2; done; " +
            "[ -f $STOP_FLAG ] && exit 0; sleep 3; [ -f $STOP_FLAG ] && exit 0; " +
            "P=\$(pidof \"\${N}r\" 2>/dev/null); [ -z \"\$P\" ] && P=\$(pgrep -f \"\${N}r\" 2>/dev/null | head -n1); " +
            "[ -n \"\$P\" ] && exit 0; " +
            "echo \"supervisor: server died, starting it again\" >>${q(logPath)}; " +
            "CLASSPATH=${q(apk)} exec app_process /system/bin --nice-name=\${N}r com.example.mykuzu.server.Server ${q(token)} ${q(csv)} >>${q(logPath)} 2>&1 </dev/null"
        val outer = "S=; command -v setsid >/dev/null 2>&1 && S=setsid; \$S sh -c ${q(script)} >/dev/null 2>&1 </dev/null &"
        ProcessBuilder("sh", "-c", outer).redirectErrorStream(true).start().also { runCatching { it.outputStream.close() } }
        "supervisor: started (watching pid $me)"
    } catch (e: Throwable) { "supervisor: not started (${e.message})" }

    private fun cgNow(): String = runCatching { java.io.File("/proc/self/cgroup").readText().trim().replace("\n", " ; ") }.getOrDefault("?")

    /** Runs a command with a time limit and an output cap. Exit code 124 means it timed out. */
    private fun runCmd(cmd: String): Pair<Int, ByteArray> {
        val proc = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        runCatching { proc.outputStream.close() }
        val buf = ByteArrayOutputStream()
        val rd = thread(isDaemon = true) {
            try {
                val b = ByteArray(8192)
                val ins = proc.inputStream
                while (true) {
                    val n = ins.read(b)
                    if (n < 0) break
                    synchronized(buf) {
                        val room = MAX_OUT - buf.size()
                        if (room > 0) buf.write(b, 0, minOf(n, room))
                    }
                }
            } catch (_: Exception) {}
        }
        val done = proc.waitFor(TIMEOUT_SEC, TimeUnit.SECONDS)
        if (!done) proc.destroyForcibly()
        rd.join(1500)
        val bytes = synchronized(buf) { buf.toByteArray() }
        val extra = if (!done) "\n[timed out after ${TIMEOUT_SEC}s]".toByteArray() else ByteArray(0)
        return (if (done) proc.exitValue() else 124) to (bytes + extra)
    }

    /**
     * Per-app uninstall protection (the same flag device-owner apps use via setUninstallBlocked).
     * Calls the hidden IPackageManager.setBlockUninstallForUser; arg is "1" (block), "0" (allow) or "?" (read).
     */
    private fun uninstallBlock(pkg: String, arg: String): String {
        if (!Regex("[A-Za-z0-9._]+").matches(pkg)) return "ERR bad package"
        return try {
            val binder = Class.forName("android.os.ServiceManager")
                .getMethod("getService", String::class.java).invoke(null, "package") as android.os.IBinder
            val pm = Class.forName("android.content.pm.IPackageManager\$Stub")
                .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, binder)!!
            val int = Int::class.javaPrimitiveType
            if (arg == "?") {
                val r = pm.javaClass.getMethod("getBlockUninstallForUser", String::class.java, int).invoke(pm, pkg, 0) as Boolean
                "OK " + if (r) 1 else 0
            } else {
                pm.javaClass.getMethod("setBlockUninstallForUser", String::class.java, Boolean::class.javaPrimitiveType, int)
                    .invoke(pm, pkg, arg == "1", 0)
                "OK"
            }
        } catch (e: java.lang.reflect.InvocationTargetException) {
            "ERR " + (e.targetException?.message ?: e.targetException.toString()).lineSequence().first()
        } catch (e: Throwable) {
            "ERR " + (e.message ?: e.toString()).lineSequence().first()
        }
    }

    /* ---------- status bar disable flags (one token for the life of this process) ---------- */
    private val sbToken: android.os.IBinder = android.os.Binder()
    private const val NAV_FLAGS = 0x00200000 or 0x00400000 or 0x01000000      // home, back, recents
    private const val BAR_FLAGS = 0x00020000 or 0x00100000 or 0x00800000      // notification icons, system info, clock
    @Volatile private var sbWhat = 0
    @Volatile private var lastBeat = 0L
    @Volatile private var watchdog: Thread? = null

    private fun sbCall(svc: Any, name: String, what: Int): Boolean {
        val c = svc.javaClass
        val int = Int::class.javaPrimitiveType
        try {
            c.getMethod(name, int, android.os.IBinder::class.java, String::class.java).invoke(svc, what, sbToken, "com.android.shell")
            return true
        } catch (_: NoSuchMethodException) {
        } catch (_: Throwable) {
            return false
        }
        return try {
            c.getMethod(name + "ForUser", int, android.os.IBinder::class.java, String::class.java, int)
                .invoke(svc, what, sbToken, "com.android.shell", 0)
            true
        } catch (_: Throwable) { false }
    }

    @Synchronized
    private fun sbApply(what: Int, what2: Int): Boolean = try {
        val binder = Class.forName("android.os.ServiceManager")
            .getMethod("getService", String::class.java).invoke(null, "statusbar") as android.os.IBinder
        val svc = Class.forName("com.android.internal.statusbar.IStatusBarService\$Stub")
            .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, binder)!!
        val ok = sbCall(svc, "disable", what)
        sbCall(svc, "disable2", what2)
        ok
    } catch (_: Throwable) { false }

    /** Gives the navigation buttons back if an app stopped sending heartbeats (it crashed or was killed). */
    private fun ensureWatchdog(what2: () -> Int) {
        if (watchdog?.isAlive == true) return
        watchdog = Thread {
            try {
                while (sbWhat and NAV_FLAGS != 0) {
                    Thread.sleep(2000)
                    if (sbWhat and NAV_FLAGS != 0 && System.currentTimeMillis() - lastBeat > 8000) {
                        sbWhat = sbWhat and (NAV_FLAGS or BAR_FLAGS).inv()
                        sbApply(sbWhat, what2())
                    }
                }
            } catch (_: InterruptedException) {}
        }.apply { isDaemon = true; name = "nav-watchdog"; start() }
    }
    @Volatile private var sbWhat2 = 0

    private fun handle(s: Socket, token: String) {
        openConns.incrementAndGet()
        try { handleInner(s, token) } finally { openConns.decrementAndGet() }
    }

    private fun authorized(t: String, token: String) = eq(t, token) || appTokens.any { eq(t, it) }

    /** Starts the command of a STREAM request; returns null if the token is not allowed. */
    private fun startStream(p: List<String>, token: String): Process? {
        if (p.size < 2 || !authorized(p[0], token)) return null
        touch()
        val cmd = String(Base64.getDecoder().decode(p.getOrElse(2) { "" }))
        addLog(if (eq(p[0], token)) "app" else p[0].take(8), 0, "stream: $cmd")
        val proc = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        runCatching { proc.outputStream.close() }
        return proc
    }

    /** One request line "<token> <COMMAND> <args>" in, one reply line out. Used by the socket AND the Binder transport. */
    private fun process(line: String, token: String): String {
        val p = line.split(" ", limit = 3)
        if (p.size < 2) return "DENIED"
        val isMaster = eq(p[0], token)
        val isApp = !isMaster && appTokens.any { eq(p[0], it) }
        if (!isMaster && !isApp) return "DENIED"
        // Watchdog polling (master PING / ACTIVITY) is not "app interaction"; everything else is.
        if (!(isMaster && (p[1] == "PING" || p[1] == "ACTIVITY"))) touch()
        val who = if (isMaster) "app" else p[0].take(8)
        return when (p[1]) {
            "ACTIVITY" -> "OK ${if (busy(1)) 1 else 0} ${openConns.get() - 1} ${System.currentTimeMillis() - lastActivity}"
            "PING" -> "OK ${android.os.Process.myUid()} $VERSION"
            "PUSH" -> pushBinder().also { pushState = it }
            "EXEC" -> {
                val cmd = String(Base64.getDecoder().decode(p.getOrElse(2) { "" }))
                val (code, bytes) = runCmd(cmd)
                addLog(who, code, cmd)
                "$code " + Base64.getEncoder().encodeToString(bytes)
            }
            "UBLOCK" -> {
                val a = p.getOrElse(2) { "" }.split(" ")
                val r = uninstallBlock(a.getOrElse(0) { "" }, a.getOrElse(1) { "?" })
                if (a.getOrElse(1) { "?" } != "?") addLog(who, if (r.startsWith("OK")) 0 else 1, "uninstall-protect ${a.getOrElse(0) { "" }} ${a.getOrElse(1) { "" }}")
                r
            }
            "BEAT" -> { lastBeat = System.currentTimeMillis(); "OK" }
            "SBFLAGS" -> {
                val a = p.getOrElse(2) { "" }.split(" ")
                val w = a.getOrNull(0)?.toIntOrNull(); val w2 = a.getOrNull(1)?.toIntOrNull()
                if (w == null || w2 == null) "ERR bad flags" else {
                    lastBeat = System.currentTimeMillis()
                    val ok = sbApply(w, w2)
                    if (ok) { sbWhat = w; sbWhat2 = w2; if (w and NAV_FLAGS != 0) ensureWatchdog { sbWhat2 } }
                    if (ok) "OK" else "ERR statusbar"
                }
            }
            "SYNC" -> if (isMaster) { appTokens = parse(p.getOrNull(2)); "OK" } else "DENIED"
            "LOG" -> if (isMaster) "OK " + log.joinToString(";") else "DENIED"
            "STOP" -> if (isMaster) { runCatching { java.io.File(STOP_FLAG).writeText("stop") }; thread(isDaemon = true) { Thread.sleep(300); exitProcess(0) }; "OK" } else "DENIED"
            else -> "ERR unknown"
        }
    }

    private fun handleInner(s: Socket, token: String) {
        s.use {
            s.soTimeout = 15000
            val line = BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: return
            val out = s.getOutputStream()
            fun reply(t: String) { out.write((t + "\n").toByteArray()); out.flush() }
            val p = line.split(" ", limit = 3)
            if (p.size >= 2 && p[1] == "STREAM") {
                val proc = startStream(p, token)
                if (proc == null) { reply("DENIED"); return }
                s.soTimeout = 0
                reply("OK")
                // when the app closes the socket, stop the command
                thread(isDaemon = true) { try { while (s.getInputStream().read() >= 0) {} } catch (_: Exception) {}; proc.destroyForcibly() }
                try {
                    val b = ByteArray(8192)
                    val ins = proc.inputStream
                    while (true) {
                        val n = ins.read(b)
                        if (n < 0) break
                        out.write(b, 0, n); out.flush()
                    }
                } catch (_: Exception) {
                } finally { proc.destroyForcibly(); touch() }
                return
            }
            reply(process(line, token))
        }
    }

    /* ---------- Binder transport ---------- */

    private fun pipeWith(data: ByteArray): android.os.ParcelFileDescriptor {
        val pipe = android.os.ParcelFileDescriptor.createPipe()
        thread(isDaemon = true) {
            try { android.os.ParcelFileDescriptor.AutoCloseOutputStream(pipe[1]).use { it.write(data) } } catch (_: Exception) {}
        }
        return pipe[0]
    }

    private val binderObj = object : android.os.Binder() {
        override fun onTransact(code: Int, data: android.os.Parcel, reply: android.os.Parcel?, flags: Int): Boolean {
            if (code != TX_REQUEST && code != TX_STREAM) return super.onTransact(code, data, reply, flags)
            openConns.incrementAndGet()
            return try {
                data.enforceInterface(DESC)
                val line = data.readString() ?: ""
                if (code == TX_REQUEST) {
                    val r = try { process(line, masterToken) } catch (e: Throwable) { "ERR " + (e.message ?: e.toString()).lineSequence().first() }
                    reply?.writeNoException()
                    if (r.length > BIG_REPLY) {
                        reply?.writeInt(1)
                        pipeWith(r.toByteArray()).writeToParcel(reply!!, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE)
                    } else { reply?.writeInt(0); reply?.writeString(r) }
                } else {
                    val proc = try { startStream(line.split(" ", limit = 3), masterToken) } catch (e: Throwable) { null }
                    reply?.writeNoException()
                    if (proc == null) reply?.writeInt(0) else {
                        val pipe = android.os.ParcelFileDescriptor.createPipe()
                        reply?.writeInt(1)
                        pipe[0].writeToParcel(reply!!, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE)
                        thread(isDaemon = true) {
                            openConns.incrementAndGet()
                            val os = android.os.ParcelFileDescriptor.AutoCloseOutputStream(pipe[1])
                            try {
                                val b = ByteArray(8192)
                                val ins = proc.inputStream
                                while (true) { val n = ins.read(b); if (n < 0) break; os.write(b, 0, n); os.flush() }
                            } catch (_: Exception) {
                            } finally { proc.destroyForcibly(); runCatching { os.close() }; openConns.decrementAndGet(); touch() }
                        }
                    }
                }
                true
            } finally { openConns.decrementAndGet() }
        }
    }

    /** IContentProvider.call has a different signature on almost every Android version. */
    private fun callProvider(provider: Any, method: String, extras: android.os.Bundle) {
        val pkg = "com.android.shell"
        fun attribution(): Any {
            val b = Class.forName("android.content.AttributionSource\$Builder").getConstructor(Int::class.javaPrimitiveType).newInstance(android.system.Os.getuid())
            b.javaClass.getMethod("setPackageName", String::class.java).invoke(b, pkg)
            return b.javaClass.getMethod("build").invoke(b)!!
        }
        var last: Throwable? = null
        for (m in provider.javaClass.methods.filter { it.name == "call" }) {
            val t = m.parameterTypes
            if (t.isEmpty()) continue
            val args: Array<Any?>? = when {
                t[0].name == "android.content.AttributionSource" -> arrayOf(attribution(), AUTH, method, null, extras)
                t.size == 6 -> arrayOf(pkg, null, AUTH, method, null, extras)
                t.size == 5 -> arrayOf(pkg, AUTH, method, null, extras)
                t.size == 4 -> arrayOf(pkg, method, null, extras)
                else -> null
            }
            if (args == null) continue
            try { m.invoke(provider, *args); return }
            catch (e: java.lang.reflect.InvocationTargetException) { throw e.targetException }
            catch (e: IllegalArgumentException) { last = e }
        }
        throw last ?: NoSuchMethodException("IContentProvider.call")
    }

    /** Gives our Binder to AeroHUB's BinderProvider (the same way Shizuku sends its Binder to its manager app). Returns "OK" or "ERR ...". */
    @Synchronized
    private fun pushBinder(): String {
        val tok = android.os.Binder()
        var am: Any? = null
        return try {
            val amBinder = Class.forName("android.os.ServiceManager")
                .getMethod("getService", String::class.java).invoke(null, "activity") as android.os.IBinder
            val amo = Class.forName("android.app.IActivityManager\$Stub")
                .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, amBinder)!!
            am = amo
            val get = amo.javaClass.methods.first { it.name == "getContentProviderExternal" }
            val holder = (if (get.parameterCount >= 4) get.invoke(amo, AUTH, 0, tok, "AeroHUB") else get.invoke(amo, AUTH, 0, tok))
                ?: return "ERR provider not found (update AeroHUB)"
            val provider = holder.javaClass.getField("provider").get(holder) ?: return "ERR provider not found (update AeroHUB)"
            val extras = android.os.Bundle().apply { putBinder("b", binderObj) }
            callProvider(provider, "sendBinder", extras)
            "OK"
        } catch (e: java.lang.reflect.InvocationTargetException) {
            "ERR " + (e.targetException?.message ?: e.targetException.toString()).lineSequence().first()
        } catch (e: Throwable) {
            "ERR " + (e.message ?: e.toString()).lineSequence().first()
        } finally {
            runCatching { am?.let { it.javaClass.getMethod("removeContentProviderExternal", String::class.java, android.os.IBinder::class.java).invoke(it, AUTH, tok) } }
        }
    }

    private fun ts() = java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())
}
