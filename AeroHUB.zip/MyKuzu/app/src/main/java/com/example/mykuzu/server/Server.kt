package com.example.mykuzu.server

import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.Base64
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.system.exitProcess

/**
 * Runs as shell (adb) or root via app_process.
 * Args: <masterToken> [comma-separated app tokens or "-"]
 * The master token (MyKuzu app) can SYNC the allowed app tokens at any time, which is how apps are turned on/off.
 * Commands: PING, ACTIVITY, EXEC <base64>, UBLOCK <pkg> <1|0|?>, STREAM <base64>, SBFLAGS <what> <what2>, BEAT, SYNC <tokens>, LOG (master), STOP (master).
 */
object Server {
    const val PORT = 27183
    const val VERSION = 7
    private const val MAX_OUT = 512 * 1024
    private const val TIMEOUT_SEC = 60L
    @Volatile private var appTokens: Set<String> = emptySet()
    private val log = ConcurrentLinkedDeque<String>()

    /* ---------- activity tracking: while any app is interacting, the server counts as "busy" ---------- */
    private val openConns = java.util.concurrent.atomic.AtomicInteger(0)      // connections being served right now (streams stay open)
    @Volatile private var lastActivity = System.currentTimeMillis()
    private const val BUSY_GRACE_MS = 120_000L                                // still "busy" this long after the last app command

    private fun touch() { lastActivity = System.currentTimeMillis() }
    /** [self] = connections of the caller itself that must not count (the watchdog's own query). */
    private fun busy(self: Int = 0): Boolean =
        openConns.get() - self > 0 || sbWhat != 0 || System.currentTimeMillis() - lastActivity < BUSY_GRACE_MS

    private fun parse(s: String?): Set<String> =
        s?.split(",")?.filter { it.length >= 16 }?.toSet() ?: emptySet()

    private fun eq(a: String, b: String) = MessageDigest.isEqual(a.toByteArray(), b.toByteArray())

    private fun addLog(who: String, code: Int, cmd: String) {
        val c = Base64.getEncoder().encodeToString(cmd.take(300).toByteArray())
        log.addLast("${System.currentTimeMillis()}|$who|$code|$c")
        while (log.size > 200) log.pollFirst()
    }

    @JvmStatic
    fun main(args: Array<String>) {
        val token = args.getOrNull(0) ?: exitProcess(1)
        appTokens = parse(args.getOrNull(1))
        // SO_REUSEADDR + retry: after a Stop the old port sits in TIME_WAIT for ~1 minute, and a plain bind then fails
        // silently, which is why the 2nd start never worked.
        var ss: ServerSocket? = null
        var lastErr: Exception? = null
        repeat(40) {
            if (ss == null) {
                try {
                    ss = ServerSocket().apply {
                        reuseAddress = true
                        bind(java.net.InetSocketAddress(InetAddress.getByName("127.0.0.1"), PORT), 50)
                    }
                } catch (e: Exception) { lastErr = e; Thread.sleep(500) }
            }
        }
        val server = ss ?: run { System.err.println("bind failed on port $PORT: $lastErr"); exitProcess(2) }
        System.err.println("AeroHUB server listening on $PORT")
        // Diagnostics: when and how the server stops. A shutdown-hook line means it got a signal / STOP; if the log
        // simply ends after an "alive" line, the process was killed (SIGKILL) and the last time tells when.
        fun ts() = java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        val adj = runCatching { java.io.File("/proc/self/oom_score_adj").readText().trim() }.getOrDefault("?")
        System.err.println("${ts()} start pid=${android.os.Process.myPid()} uid=${android.os.Process.myUid()} oom_score_adj=$adj v$VERSION")
        // app_process installs a handler that KILLS the whole process on any uncaught exception in any thread. Log it instead,
        // so one stray error can never stop the server (and the log says what happened).
        Thread.setDefaultUncaughtExceptionHandler { t, e -> System.err.println("${ts()} uncaught in ${t.name}: $e") }
        Runtime.getRuntime().addShutdownHook(Thread { System.err.println("${ts()} shutdown hook: process is exiting (signal or STOP)") })
        thread(isDaemon = true) {
            while (true) {
                Thread.sleep(60_000)
                val a = runCatching { java.io.File("/proc/self/oom_score_adj").readText().trim() }.getOrDefault("?")
                System.err.println("${ts()} alive adj=$a" + if (busy()) " (busy)" else "")
            }
        }
        // Android 12+ "phantom process killer" can kill background shell processes like this server. Switch it off (best effort).
        thread(isDaemon = true) {
            runCatching {
                runCmd("settings put global settings_enable_monitor_phantom_procs false 2>/dev/null; " +
                    "device_config put activity_manager max_phantom_processes 2147483647 2>/dev/null; exit 0")
            }
        }
        // While apps are interacting, repeat that protection now and then (the system can reset it) and keep the process at a low nice value.
        thread(isDaemon = true) {
            while (true) {
                Thread.sleep(60_000)
                if (busy()) runCatching {
                    runCmd("device_config put activity_manager max_phantom_processes 2147483647 2>/dev/null; exit 0")
                    System.err.println("${ts()} busy: protection refreshed (conns=${openConns.get()})")
                }
            }
        }
        while (true) {
            val s = try { server.accept() } catch (e: Throwable) {
                System.err.println("${ts()} accept failed: $e")
                if (server.isClosed) exitProcess(3)
                Thread.sleep(200); continue
            }
            try { thread { try { handle(s, token) } catch (_: Throwable) {} } }
            catch (e: Throwable) { System.err.println("${ts()} cannot start handler: $e"); runCatching { s.close() } }
        }
    }

    /** Runs a command with a time limit and an output cap. Exit code 124 means it timed out. */
    private fun runCmd(cmd: String): Pair<Int, ByteArray> {
        val proc = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        runCatching { proc.outputStream.close() }
        val buf = ByteArrayOutputStream()
        val rd = thread(isDaemon = true) {
            try {
                val b = ByteArray(8192)
                val ins = proc.inputStream
                while (true) {
                    val n = ins.read(b)
                    if (n < 0) break
                    synchronized(buf) {
                        val room = MAX_OUT - buf.size()
                        if (room > 0) buf.write(b, 0, minOf(n, room))
                    }
                }
            } catch (_: Exception) {}
        }
        val done = proc.waitFor(TIMEOUT_SEC, TimeUnit.SECONDS)
        if (!done) proc.destroyForcibly()
        rd.join(1500)
        val bytes = synchronized(buf) { buf.toByteArray() }
        val extra = if (!done) "\n[timed out after ${TIMEOUT_SEC}s]".toByteArray() else ByteArray(0)
        return (if (done) proc.exitValue() else 124) to (bytes + extra)
    }

    /**
     * Per-app uninstall protection (the same flag device-owner apps use via setUninstallBlocked).
     * Calls the hidden IPackageManager.setBlockUninstallForUser; arg is "1" (block), "0" (allow) or "?" (read).
     */
    private fun uninstallBlock(pkg: String, arg: String): String {
        if (!Regex("[A-Za-z0-9._]+").matches(pkg)) return "ERR bad package"
        return try {
            val binder = Class.forName("android.os.ServiceManager")
                .getMethod("getService", String::class.java).invoke(null, "package") as android.os.IBinder
            val pm = Class.forName("android.content.pm.IPackageManager\$Stub")
                .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, binder)!!
            val int = Int::class.javaPrimitiveType
            if (arg == "?") {
                val r = pm.javaClass.getMethod("getBlockUninstallForUser", String::class.java, int).invoke(pm, pkg, 0) as Boolean
                "OK " + if (r) 1 else 0
            } else {
                pm.javaClass.getMethod("setBlockUninstallForUser", String::class.java, Boolean::class.javaPrimitiveType, int)
                    .invoke(pm, pkg, arg == "1", 0)
                "OK"
            }
        } catch (e: java.lang.reflect.InvocationTargetException) {
            "ERR " + (e.targetException?.message ?: e.targetException.toString()).lineSequence().first()
        } catch (e: Throwable) {
            "ERR " + (e.message ?: e.toString()).lineSequence().first()
        }
    }

    /* ---------- status bar disable flags (one token for the life of this process) ---------- */
    private val sbToken: android.os.IBinder = android.os.Binder()
    private const val NAV_FLAGS = 0x00200000 or 0x00400000 or 0x01000000      // home, back, recents
    private const val BAR_FLAGS = 0x00020000 or 0x00100000 or 0x00800000      // notification icons, system info, clock
    @Volatile private var sbWhat = 0
    @Volatile private var lastBeat = 0L
    @Volatile private var watchdog: Thread? = null

    private fun sbCall(svc: Any, name: String, what: Int): Boolean {
        val c = svc.javaClass
        val int = Int::class.javaPrimitiveType
        try {
            c.getMethod(name, int, android.os.IBinder::class.java, String::class.java).invoke(svc, what, sbToken, "com.android.shell")
            return true
        } catch (_: NoSuchMethodException) {
        } catch (_: Throwable) {
            return false
        }
        return try {
            c.getMethod(name + "ForUser", int, android.os.IBinder::class.java, String::class.java, int)
                .invoke(svc, what, sbToken, "com.android.shell", 0)
            true
        } catch (_: Throwable) { false }
    }

    @Synchronized
    private fun sbApply(what: Int, what2: Int): Boolean = try {
        val binder = Class.forName("android.os.ServiceManager")
            .getMethod("getService", String::class.java).invoke(null, "statusbar") as android.os.IBinder
        val svc = Class.forName("com.android.internal.statusbar.IStatusBarService\$Stub")
            .getMethod("asInterface", android.os.IBinder::class.java).invoke(null, binder)!!
        val ok = sbCall(svc, "disable", what)
        sbCall(svc, "disable2", what2)
        ok
    } catch (_: Throwable) { false }

    /** Gives the navigation buttons back if an app stopped sending heartbeats (it crashed or was killed). */
    private fun ensureWatchdog(what2: () -> Int) {
        if (watchdog?.isAlive == true) return
        watchdog = Thread {
            try {
                while (sbWhat and NAV_FLAGS != 0) {
                    Thread.sleep(2000)
                    if (sbWhat and NAV_FLAGS != 0 && System.currentTimeMillis() - lastBeat > 8000) {
                        sbWhat = sbWhat and (NAV_FLAGS or BAR_FLAGS).inv()
                        sbApply(sbWhat, what2())
                    }
                }
            } catch (_: InterruptedException) {}
        }.apply { isDaemon = true; name = "nav-watchdog"; start() }
    }
    @Volatile private var sbWhat2 = 0

    private fun handle(s: Socket, token: String) {
        openConns.incrementAndGet()
        try { handleInner(s, token) } finally { openConns.decrementAndGet() }
    }

    private fun handleInner(s: Socket, token: String) {
        s.use {
            s.soTimeout = 15000
            val line = BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: return
            val out = s.getOutputStream()
            fun reply(t: String) { out.write((t + "\n").toByteArray()); out.flush() }
            val p = line.split(" ", limit = 3)
            if (p.size < 2) { reply("DENIED"); return }
            val isMaster = eq(p[0], token)
            val isApp = !isMaster && appTokens.any { eq(p[0], it) }
            if (!isMaster && !isApp) { reply("DENIED"); return }
            // Watchdog polling (master PING / ACTIVITY) is not "app interaction"; everything else is.
            if (!(isMaster && (p[1] == "PING" || p[1] == "ACTIVITY"))) touch()
            when (p[1]) {
                "ACTIVITY" -> reply("OK ${if (busy(1)) 1 else 0} ${openConns.get() - 1} ${System.currentTimeMillis() - lastActivity}")
                "PING" -> reply("OK ${android.os.Process.myUid()} $VERSION")
                "EXEC" -> {
                    val cmd = String(Base64.getDecoder().decode(p.getOrElse(2) { "" }))
                    val (code, bytes) = runCmd(cmd)
                    addLog(if (isMaster) "app" else p[0].take(8), code, cmd)
                    reply("$code " + Base64.getEncoder().encodeToString(bytes))
                }
                "UBLOCK" -> {
                    val a = p.getOrElse(2) { "" }.split(" ")
                    val r = uninstallBlock(a.getOrElse(0) { "" }, a.getOrElse(1) { "?" })
                    if (a.getOrElse(1) { "?" } != "?") addLog(if (isMaster) "app" else p[0].take(8), if (r.startsWith("OK")) 0 else 1, "uninstall-protect ${a.getOrElse(0) { "" }} ${a.getOrElse(1) { "" }}")
                    reply(r)
                }
                "BEAT" -> { lastBeat = System.currentTimeMillis(); reply("OK") }
                "SBFLAGS" -> {
                    val a = p.getOrElse(2) { "" }.split(" ")
                    val w = a.getOrNull(0)?.toIntOrNull(); val w2 = a.getOrNull(1)?.toIntOrNull()
                    if (w == null || w2 == null) reply("ERR bad flags") else {
                        lastBeat = System.currentTimeMillis()
                        val ok = sbApply(w, w2)
                        if (ok) { sbWhat = w; sbWhat2 = w2; if (w and NAV_FLAGS != 0) ensureWatchdog { sbWhat2 } }
                        reply(if (ok) "OK" else "ERR statusbar")
                    }
                }
                "STREAM" -> {
                    val cmd = String(Base64.getDecoder().decode(p.getOrElse(2) { "" }))
                    addLog(if (isMaster) "app" else p[0].take(8), 0, "stream: $cmd")
                    s.soTimeout = 0
                    val proc = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
                    runCatching { proc.outputStream.close() }
                    reply("OK")
                    // when the app closes the socket, stop the command
                    thread(isDaemon = true) { try { while (s.getInputStream().read() >= 0) {} } catch (_: Exception) {}; proc.destroyForcibly() }
                    try {
                        val b = ByteArray(8192)
                        val ins = proc.inputStream
                        while (true) {
                            val n = ins.read(b)
                            if (n < 0) break
                            out.write(b, 0, n); out.flush()
                        }
                    } catch (_: Exception) {
                    } finally { proc.destroyForcibly(); touch() }
                }
                "SYNC" -> if (isMaster) { appTokens = parse(p.getOrNull(2)); reply("OK") } else reply("DENIED")
                "LOG" -> if (isMaster) reply("OK " + log.joinToString(";")) else reply("DENIED")
                "STOP" -> if (isMaster) { reply("OK"); exitProcess(0) } else reply("DENIED")
                else -> reply("ERR unknown")
            }
        }
    }
}
