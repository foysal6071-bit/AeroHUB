package com.example.mykuzu.server

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.Base64
import kotlin.concurrent.thread
import kotlin.system.exitProcess

/**
 * Runs as shell (adb) or root via app_process.
 * Args: <masterToken> [comma-separated app tokens or "-"]
 * The master token (MyKuzu app) can SYNC the allowed app tokens at any time, which is how apps are turned on/off.
 */
object Server {
    const val PORT = 27183
    @Volatile private var appTokens: Set<String> = emptySet()

    private fun parse(s: String?): Set<String> =
        s?.split(",")?.filter { it.length >= 16 }?.toSet() ?: emptySet()

    private fun eq(a: String, b: String) = MessageDigest.isEqual(a.toByteArray(), b.toByteArray())

    @JvmStatic
    fun main(args: Array<String>) {
        val token = args.getOrNull(0) ?: exitProcess(1)
        appTokens = parse(args.getOrNull(1))
        val ss = try { ServerSocket(PORT, 50, InetAddress.getByName("127.0.0.1")) } catch (e: Exception) { exitProcess(2) }
        while (true) {
            val s = ss.accept()
            thread { try { handle(s, token) } catch (_: Exception) {} }
        }
    }

    private fun handle(s: Socket, token: String) {
        s.use {
            val line = BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: return
            val out = s.getOutputStream()
            fun reply(t: String) { out.write((t + "\n").toByteArray()); out.flush() }
            val p = line.split(" ", limit = 3)
            if (p.size < 2) { reply("DENIED"); return }
            val isMaster = eq(p[0], token)
            val isApp = !isMaster && appTokens.any { eq(p[0], it) }
            if (!isMaster && !isApp) { reply("DENIED"); return }
            when (p[1]) {
                "PING" -> reply("OK ${android.os.Process.myUid()}")
                "EXEC" -> {
                    val cmd = String(Base64.getDecoder().decode(p.getOrElse(2) { "" }))
                    val proc = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
                    val bytes = proc.inputStream.readBytes()
                    val code = proc.waitFor()
                    reply("$code " + Base64.getEncoder().encodeToString(bytes))
                }
                "SYNC" -> if (isMaster) { appTokens = parse(p.getOrNull(2)); reply("OK") } else reply("DENIED")
                "STOP" -> if (isMaster) { reply("OK"); exitProcess(0) } else reply("DENIED")
                else -> reply("ERR unknown")
            }
        }
    }
}
