package com.example.mykuzu

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock

/**
 * Watchdog: keeps the server alive 24h.
 * - Foreground service + partial wake lock + Wi-Fi lock (screen off does not stop the CPU or put Wi-Fi to sleep)
 * - Exempts AeroHUB from Doze / battery limits through the server itself (no dialog needed), because in Doze
 *   even a foreground service loses network access, and that includes the 127.0.0.1 connection to the server
 * - Checks the server every 15s, restarts it if it is really down (with back-off)
 * - Wakes up at once on screen on / unlock / network change
 * - An alarm every 5 min revives this service if the system killed it
 */
class WatchdogService : Service() {
    companion object {
        private const val ID = 73
        private const val CH = "watchdog"
        private const val ALARM_MS = 2 * 60_000L
        private const val BUSY_HOLD_MS = 3 * 60_000L      // stay in strict mode this long after the server last reported activity
        private const val EXEMPT_OK_MS = 30 * 60_000L     // re-apply now and then (the standby bucket falls back over time)
        private const val EXEMPT_RETRY_MS = 2 * 60_000L
        @Volatile private var nextExempt = 0L
        @Volatile private var live: WatchdogService? = null

        /** The server's Binder died: stop waiting, check (and restart) now. */
        fun kick() { live?.let { it.hurryUntil = SystemClock.elapsedRealtime() + 90_000L; it.poke() } }
        @Volatile private var nextWake = 0L
        private const val WAKE_EVERY_MS = 20_000L

        /**
         * Wakes the apps that use AeroHUB (the enabled ones in the Apps list) when they are not running: removes their
         * background limits, then sends them a WAKE broadcast (and BOOT_COMPLETED), including to force-stopped apps.
         * Blocks: call from a background thread. Needs the server.
         */
        fun wakeApps(c: Context, force: Boolean = false) {
            if (!Store.wakeApps(c) || !Store.masterOn(c)) return
            val now = SystemClock.elapsedRealtime()
            if (!force && now < nextWake) return
            nextWake = now + WAKE_EVERY_MS
            val pkgs = Store.grants(c).filter { it.enabled && it.pkg != c.packageName && Regex("[A-Za-z0-9._]+").matches(it.pkg) }.map { it.pkg }
            if (pkgs.isEmpty()) return
            val cmd = "run() { if command -v pidof >/dev/null 2>&1; then pidof \"\$1\" >/dev/null 2>&1; " +
                "else ps -A 2>/dev/null | grep -q \" \$1\\\$\"; fi; }; " +
                "for P in ${pkgs.joinToString(" ")}; do " +
                "if ! run \"\$P\"; then " +
                "am set-inactive \"\$P\" false >/dev/null 2>&1; am set-standby-bucket \"\$P\" active >/dev/null 2>&1; " +
                "cmd appops set \"\$P\" RUN_IN_BACKGROUND allow >/dev/null 2>&1; cmd appops set \"\$P\" RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1; " +
                "am broadcast -f 32 -p \"\$P\" -a ${MyKuzu.ACTION_WAKE} >/dev/null 2>&1; " +
                "am broadcast -f 32 -p \"\$P\" -a android.intent.action.BOOT_COMPLETED >/dev/null 2>&1; " +
                "sleep 1; if run \"\$P\"; then echo \"woke:\$P\"; else echo \"failed:\$P\"; fi; " +
                "fi; done; exit 0"
            val out = try { MyKuzu.exec(Store.token(c), cmd).second } catch (_: Throwable) { return }
            out.lines().filter { it.startsWith("woke:") || it.startsWith("failed:") }.forEach {
                WdLog.add(c, if (it.startsWith("woke:")) "woke closed app " + it.removePrefix("woke:")
                             else "could not wake " + it.removePrefix("failed:") + " (it needs a WAKE or boot receiver)")
            }
        }

        /** Second revive path besides the alarm: the system's JobScheduler re-runs this (persisted, survives reboot) every 15 min. */
        fun scheduleJob(c: Context) {
            runCatching {
                val js = c.getSystemService(android.app.job.JobScheduler::class.java)
                if (js.getPendingJob(92) != null) return
                js.schedule(android.app.job.JobInfo.Builder(92, android.content.ComponentName(c, WatchdogJob::class.java))
                    .setPeriodic(15 * 60_000L).setPersisted(true).build())
            }
        }

        fun start(c: Context) {
            if (!Store.watchdogOn(c)) return
            runCatching { c.startForegroundService(Intent(c, WatchdogService::class.java)) }
        }

        fun stop(c: Context) {
            runCatching { c.stopService(Intent(c, WatchdogService::class.java)) }
            cancelAlarm(c)
        }

        private fun pi(c: Context) = PendingIntent.getBroadcast(
            c, 91, Intent(c, WatchdogReceiver::class.java).setAction("com.example.mykuzu.WATCHDOG_ALARM"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        fun scheduleAlarm(c: Context) {
            runCatching {
                c.getSystemService(AlarmManager::class.java)
                    .setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + ALARM_MS, pi(c))
            }
        }

        fun cancelAlarm(c: Context) { runCatching { c.getSystemService(AlarmManager::class.java).cancel(pi(c)) } }

        /**
         * Asks the running server (adb shell, UID 2000) to take AeroHUB out of Doze and background limits.
         * Same effect as "Don't optimise battery" but it needs no dialog and cannot be dismissed by mistake.
         * Blocks: call from a background thread. Does nothing if the server is not running.
         */
        fun exempt(c: Context, force: Boolean = false) {
            val now = SystemClock.elapsedRealtime()
            if (!force && now < nextExempt) return
            nextExempt = now + EXEMPT_RETRY_MS
            val p = c.packageName
            // Battery optimisation exemption + permissions the foreground service needs, granted through the server (no dialogs).
            val cmd = "cmd deviceidle whitelist +$p 2>/dev/null; " +
                "cmd deviceidle except-idle-whitelist +$p 2>/dev/null; " +
                "pm grant $p android.permission.POST_NOTIFICATIONS 2>/dev/null; " +
                "pm grant $p android.permission.WRITE_SECURE_SETTINGS 2>/dev/null; " +
                "cmd appops set $p POST_NOTIFICATION allow 2>/dev/null; " +
                "cmd appops set $p START_FOREGROUND allow 2>/dev/null; " +
                "cmd appops set $p RUN_IN_BACKGROUND allow 2>/dev/null; " +
                "cmd appops set $p RUN_ANY_IN_BACKGROUND allow 2>/dev/null; " +
                "cmd appops set $p AUTO_START allow 2>/dev/null; " +
                "cmd appops set $p SCHEDULE_EXACT_ALARM allow 2>/dev/null; " +
                // Screen lock: switch Doze off completely, keep Wi-Fi awake, and stop adb authorisation from timing out
                "cmd deviceidle disable all 2>/dev/null; " +
                "am set-bg-restriction-level --user 0 $p unrestricted 2>/dev/null; " +
                "cmd appops set $p AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore 2>/dev/null; " +
                "settings put global cached_apps_freezer disabled 2>/dev/null; " +
                "settings put global wifi_sleep_policy 2 2>/dev/null; " +
                "settings put global adb_allowed_connection_time 0 2>/dev/null; " +
                "settings put global wifi_networks_available_notification_on 0 2>/dev/null; " +
                "am set-standby-bucket $p active 2>/dev/null; exit 0"
            val ok = try { MyKuzu.exec(Store.token(c), cmd).first == 0 } catch (_: Throwable) { false }
            if (ok) {
                nextExempt = now + EXEMPT_OK_MS
                // Foreground service: make sure it is running as soon as the server is connected
                if (Store.watchdogOn(c)) start(c)
            }
            WdLog.add(c, if (ok) "battery/Doze exemption applied" else "battery/Doze exemption failed (server not reachable)")
        }
    }

    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private var worker: Thread? = null
    private val lock = Object()
    private var fails = 0
    private var lastTransport = ""
    private var nextPushTry = 0L
    private var lastPushMsg = ""
    private var silentMiss = 0    // checks in a row where the server was silent but its Binder was alive
    private var aliveMiss = 0      // times in a row the server process was alive but did not answer the app
    // Per instance (not static): a quick destroy + create can no longer leave two workers running or none.
    @Volatile private var running = false
    // While apps are using the server the watchdog is stricter: checks every few seconds, never kills a server that may just be
    // slow to answer, and restarts at once (no back-off) if it really is gone.
    @Volatile private var busyUntil = 0L
    @Volatile private var hurryUntil = 0L
    private fun isBusy() = SystemClock.elapsedRealtime() < busyUntil

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    WdLog.add(c, "screen off")
                    nextExempt = 0L      // re-apply the Doze / Wi-Fi protection right when the screen locks
                    Thread {
                        runCatching { WdLog.add(c, "state: " + Starter.snapshot(c)) }
                        Thread.sleep(3000); runCatching { exempt(c, true) }
                    }.start()
                }
                Intent.ACTION_SCREEN_ON -> {
                    WdLog.add(c, "screen on")
                    Thread { runCatching { WdLog.add(c, "state: " + Starter.snapshot(c)) } }.start()
                }
            }
            // Screen on / unlock / network change: if the server is down, retry quickly for a while (Wi-Fi needs a few seconds to come back).
            if (i.action != Intent.ACTION_SCREEN_OFF) hurryUntil = SystemClock.elapsedRealtime() + 90_000L
            poke()
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        live = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Watchdog", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, CH).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("AeroHUB").setContentText("Watchdog is keeping the server alive").setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        else startForeground(ID, n)

        wake = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aerohub:watchdog").apply { setReferenceCounted(false); acquire() }

        // Keeps Wi-Fi awake with the screen off. Wireless debugging switches itself off when Wi-Fi drops, and then the
        // server cannot be restarted. (HIGH_PERF is deprecated on Android 14 but still honoured as the strongest mode.)
        wifi = runCatching {
            @Suppress("DEPRECATION")
            applicationContext.getSystemService(WifiManager::class.java)
                .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "aerohub:wifi").apply { setReferenceCounted(false); acquire() }
        }.getOrNull()

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction("android.net.conn.CONNECTIVITY_CHANGE")
            addAction("android.net.wifi.STATE_CHANGE")
            addAction(Intent.ACTION_POWER_CONNECTED)
        }
        registerReceiver(rx, f)
        WdLog.add(this, "watchdog started")
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        scheduleAlarm(this); scheduleJob(this)
        if (worker?.isAlive != true) {
            running = true
            worker = Thread { loop() }.apply { isDaemon = true; start() }
        }
        poke()
        return START_STICKY
    }

    private fun poke() { synchronized(lock) { lock.notifyAll() } }

    private fun loop() {
        while (running) {
            try { check() } catch (_: Throwable) {}
            scheduleAlarm(this)
            val hurry = fails > 0 && SystemClock.elapsedRealtime() < hurryUntil
            val wait = if (isBusy() || hurry) 4_000L else if (fails == 0) 15_000L else minOf(15_000L * (1L shl minOf(fails, 3)), 120_000L)
            synchronized(lock) { try { lock.wait(wait) } catch (_: InterruptedException) {} }
        }
    }

    /** Several tries: right after screen on or when leaving Doze the first connect can fail while the server is fine. */
    private fun serverUp(): Boolean {
        // Right after screen on / unlock the app's own network access can need several seconds to come back: be patient.
        val hurry = SystemClock.elapsedRealtime() < hurryUntil
        // The Binder to the server just died: the server is almost certainly gone, do not wait long.
        val died = MyKuzu.diedAt != 0L && System.currentTimeMillis() - MyKuzu.diedAt < 60_000L
        val tries = if (died) 2 else if (hurry) 10 else if (isBusy()) 6 else 3
        repeat(tries) { n ->
            if (MyKuzu.ping(Store.token(this)) != null) { silentMiss = 0; return true }
            if (n < tries - 1) Thread.sleep(if (died) 800 else if (hurry || isBusy()) 1500 else 2000)
        }
        // Shizuku style: a live Binder proves the server process exists. It just does not answer yet (frozen / Doze right after
        // screen on). Restarting it now would kill a healthy server, so leave it alone, unless it stays silent for a long time.
        if (MyKuzu.binderAlive() && silentMiss < 12) {
            if (silentMiss++ == 0) WdLog.add(this, "server does not answer but its Binder is alive: process is running, not restarting")
            return true
        }
        silentMiss = 0
        return false
    }

    private fun check() {
        if (!Store.wanted(this)) {
            // A server that answers although "wanted" is off was started by a path that never set it: adopt it, so it is restarted if it dies.
            if (MyKuzu.ping(Store.token(this)) != null) Store.adoptRunning(this)
            if (!Store.wanted(this)) return                  // user pressed Stop (or nothing was ever started): do not restart
        }
        if (serverUp()) {
            fails = 0; aliveMiss = 0; exempt(this)
            val tr = MyKuzu.transport()
            if (tr != lastTransport) { lastTransport = tr; WdLog.add(this, "link to server: $tr") }
            // No Binder yet: ask the server to send it and log why if that does not work (shows up in Check connection).
            if (tr != "Binder" && SystemClock.elapsedRealtime() >= nextPushTry) {
                nextPushTry = SystemClock.elapsedRealtime() + 60_000L
                val pr = MyKuzu.requestPush(Store.token(this)) ?: "no answer (old server? tap Restart)"
                if (pr != lastPushMsg) { lastPushMsg = pr; WdLog.add(this, "binder push: $pr") }
            }
            runCatching { wakeApps(this) }
            if (MyKuzu.busy(Store.token(this)) == true) busyUntil = SystemClock.elapsedRealtime() + BUSY_HOLD_MS
            return
        }
        WdLog.add(this, "server not answering" + (if (isBusy()) " while apps were using it" else "") + ", checking")
        runCatching { WdLog.add(this, "state: " + Starter.snapshot(this)) }
        // soft: a server process that is still alive in the shell is NOT killed; only after several misses in a row it is restarted anyway.
        val r = try { Starter.auto(this, soft = aliveMiss < 4) } catch (e: Throwable) { Starter.msg(e) }
        if (r.startsWith("Server alive")) {
            aliveMiss++
            WdLog.add(this, "server process is alive but the app cannot reach it yet ($aliveMiss/4), not restarting")
            return
        }
        WdLog.add(this, "restart result: " + r.lines().first())
        if (r.startsWith("Server started")) { fails = 0; nextExempt = 0L } else if (!isBusy()) fails++
    }

    override fun onTaskRemoved(rootIntent: Intent?) { scheduleAlarm(this); super.onTaskRemoved(rootIntent) }

    override fun onDestroy() {
        running = false
        if (live === this) live = null
        poke()
        WdLog.add(this, "watchdog stopped")
        runCatching { unregisterReceiver(rx) }
        runCatching { wake?.takeIf { it.isHeld }?.release() }
        runCatching { wifi?.takeIf { it.isHeld }?.release() }
        super.onDestroy()
    }
}

/** Revives the watchdog (alarm) and re-arms it after boot or app update. */
class WatchdogReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!Store.watchdogOn(c)) return
        if (Store.wanted(c) || Store.autoStart(c)) WatchdogService.start(c)
        WatchdogService.scheduleAlarm(c)
    }
}

/** JobScheduler revive: restarts the watchdog service if the system stopped it. */
class WatchdogJob : android.app.job.JobService() {
    override fun onStartJob(p: android.app.job.JobParameters?): Boolean {
        if (Store.watchdogOn(this) && (Store.wanted(this) || Store.autoStart(this))) WatchdogService.start(this)
        return false
    }
    override fun onStopJob(p: android.app.job.JobParameters?) = false
}
