package com.example.mykuzu

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock

/**
 * Watchdog: keeps the server alive 24h.
 * - Foreground service + partial wake lock (screen off does not stop it)
 * - Checks the server every 15s, restarts it if it is down (with back-off)
 * - Wakes up at once on screen on / unlock / network change
 * - An alarm every 5 min revives this service if the system killed it
 */
class WatchdogService : Service() {
    companion object {
        private const val ID = 73
        private const val CH = "watchdog"
        private const val ALARM_MS = 5 * 60_000L
        @Volatile private var alive = false

        fun start(c: Context) {
            if (!Store.watchdogOn(c)) return
            runCatching { c.startForegroundService(Intent(c, WatchdogService::class.java)) }
        }

        fun stop(c: Context) {
            runCatching { c.stopService(Intent(c, WatchdogService::class.java)) }
            cancelAlarm(c)
        }

        private fun pi(c: Context) = PendingIntent.getBroadcast(
            c, 91, Intent(c, WatchdogReceiver::class.java).setAction("com.example.mykuzu.WATCHDOG_ALARM"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        fun scheduleAlarm(c: Context) {
            runCatching {
                c.getSystemService(AlarmManager::class.java)
                    .setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + ALARM_MS, pi(c))
            }
        }

        fun cancelAlarm(c: Context) { runCatching { c.getSystemService(AlarmManager::class.java).cancel(pi(c)) } }
    }

    private var wake: PowerManager.WakeLock? = null
    private var worker: Thread? = null
    private val lock = Object()
    private var fails = 0

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { poke() }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Watchdog", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, CH).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("AeroHUB").setContentText("Watchdog is keeping the server alive").setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        else startForeground(ID, n)

        wake = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aerohub:watchdog").apply { setReferenceCounted(false); acquire() }

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction("android.net.conn.CONNECTIVITY_CHANGE")
            addAction("android.net.wifi.STATE_CHANGE")
            addAction(Intent.ACTION_POWER_CONNECTED)
        }
        registerReceiver(rx, f)
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        scheduleAlarm(this)
        if (!alive) {
            alive = true
            worker = Thread { loop() }.apply { isDaemon = true; start() }
        }
        poke()
        return START_STICKY
    }

    private fun poke() { synchronized(lock) { lock.notifyAll() } }

    private fun loop() {
        while (alive) {
            try { check() } catch (_: Throwable) {}
            scheduleAlarm(this)
            val wait = if (fails == 0) 15_000L else minOf(15_000L * (1L shl minOf(fails, 3)), 120_000L)
            synchronized(lock) { try { lock.wait(wait) } catch (_: InterruptedException) {} }
        }
    }

    private fun check() {
        if (!Store.wanted(this)) return                      // user pressed Stop: do not restart
        if (MyKuzu.ping(Store.token(this)) != null) { fails = 0; return }
        Thread.sleep(2000)                                   // screen-on glitch: check once more before restarting
        if (MyKuzu.ping(Store.token(this)) != null) { fails = 0; return }
        val r = try { Starter.auto(this) } catch (e: Throwable) { Starter.msg(e) }
        if (r.startsWith("Server started")) fails = 0 else fails++
    }

    override fun onTaskRemoved(rootIntent: Intent?) { scheduleAlarm(this); super.onTaskRemoved(rootIntent) }

    override fun onDestroy() {
        alive = false
        poke()
        runCatching { unregisterReceiver(rx) }
        runCatching { wake?.takeIf { it.isHeld }?.release() }
        super.onDestroy()
    }
}

/** Revives the watchdog (alarm) and re-arms it after boot or app update. */
class WatchdogReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!Store.watchdogOn(c)) return
        if (Store.wanted(c) || Store.autoStart(c)) WatchdogService.start(c)
        WatchdogService.scheduleAlarm(c)
    }
}
