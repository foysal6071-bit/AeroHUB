package com.example.mykuzu

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock

/**
 * Watchdog: keeps the server alive 24h.
 * - Foreground service + partial wake lock + Wi-Fi lock (screen off does not stop the CPU or put Wi-Fi to sleep)
 * - Exempts AeroHUB from Doze / battery limits through the server itself (no dialog needed), because in Doze
 *   even a foreground service loses network access, and that includes the 127.0.0.1 connection to the server
 * - Checks the server every 15s, restarts it if it is really down (with back-off)
 * - Wakes up at once on screen on / unlock / network change
 * - An alarm every 5 min revives this service if the system killed it
 */
class WatchdogService : Service() {
    companion object {
        private const val ID = 73
        private const val CH = "watchdog"
        private const val ALARM_MS = 5 * 60_000L
        private const val EXEMPT_OK_MS = 30 * 60_000L     // re-apply now and then (the standby bucket falls back over time)
        private const val EXEMPT_RETRY_MS = 2 * 60_000L
        @Volatile private var nextExempt = 0L

        fun start(c: Context) {
            if (!Store.watchdogOn(c)) return
            runCatching { c.startForegroundService(Intent(c, WatchdogService::class.java)) }
        }

        fun stop(c: Context) {
            runCatching { c.stopService(Intent(c, WatchdogService::class.java)) }
            cancelAlarm(c)
        }

        private fun pi(c: Context) = PendingIntent.getBroadcast(
            c, 91, Intent(c, WatchdogReceiver::class.java).setAction("com.example.mykuzu.WATCHDOG_ALARM"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        fun scheduleAlarm(c: Context) {
            runCatching {
                c.getSystemService(AlarmManager::class.java)
                    .setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + ALARM_MS, pi(c))
            }
        }

        fun cancelAlarm(c: Context) { runCatching { c.getSystemService(AlarmManager::class.java).cancel(pi(c)) } }

        /**
         * Asks the running server (adb shell, UID 2000) to take AeroHUB out of Doze and background limits.
         * Same effect as "Don't optimise battery" but it needs no dialog and cannot be dismissed by mistake.
         * Blocks: call from a background thread. Does nothing if the server is not running.
         */
        fun exempt(c: Context, force: Boolean = false) {
            val now = SystemClock.elapsedRealtime()
            if (!force && now < nextExempt) return
            nextExempt = now + EXEMPT_RETRY_MS
            val p = c.packageName
            val cmd = "cmd deviceidle whitelist +$p; " +
                "cmd appops set $p RUN_IN_BACKGROUND allow; " +
                "cmd appops set $p RUN_ANY_IN_BACKGROUND allow; " +
                "cmd appops set $p AUTO_START allow; " +
                "am set-standby-bucket $p active; exit 0"
            val ok = try { MyKuzu.exec(Store.token(c), cmd).first == 0 } catch (_: Throwable) { false }
            if (ok) nextExempt = now + EXEMPT_OK_MS
            WdLog.add(c, if (ok) "battery/Doze exemption applied" else "battery/Doze exemption failed (server not reachable)")
        }
    }

    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private var worker: Thread? = null
    private val lock = Object()
    private var fails = 0
    // Per instance (not static): a quick destroy + create can no longer leave two workers running or none.
    @Volatile private var running = false

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> WdLog.add(c, "screen off")
                Intent.ACTION_SCREEN_ON -> WdLog.add(c, "screen on")
            }
            poke()
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Watchdog", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, CH).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("AeroHUB").setContentText("Watchdog is keeping the server alive").setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        else startForeground(ID, n)

        wake = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aerohub:watchdog").apply { setReferenceCounted(false); acquire() }

        // Keeps Wi-Fi awake with the screen off. Wireless debugging switches itself off when Wi-Fi drops, and then the
        // server cannot be restarted. (HIGH_PERF is deprecated on Android 14 but still honoured as the strongest mode.)
        wifi = runCatching {
            @Suppress("DEPRECATION")
            applicationContext.getSystemService(WifiManager::class.java)
                .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "aerohub:wifi").apply { setReferenceCounted(false); acquire() }
        }.getOrNull()

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction("android.net.conn.CONNECTIVITY_CHANGE")
            addAction("android.net.wifi.STATE_CHANGE")
            addAction(Intent.ACTION_POWER_CONNECTED)
        }
        registerReceiver(rx, f)
        WdLog.add(this, "watchdog started")
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        scheduleAlarm(this)
        if (worker?.isAlive != true) {
            running = true
            worker = Thread { loop() }.apply { isDaemon = true; start() }
        }
        poke()
        return START_STICKY
    }

    private fun poke() { synchronized(lock) { lock.notifyAll() } }

    private fun loop() {
        while (running) {
            try { check() } catch (_: Throwable) {}
            scheduleAlarm(this)
            val wait = if (fails == 0) 15_000L else minOf(15_000L * (1L shl minOf(fails, 3)), 120_000L)
            synchronized(lock) { try { lock.wait(wait) } catch (_: InterruptedException) {} }
        }
    }

    /** Several tries: right after screen on or when leaving Doze the first connect can fail while the server is fine. */
    private fun serverUp(): Boolean {
        repeat(3) { n ->
            if (MyKuzu.ping(Store.token(this)) != null) return true
            if (n < 2) Thread.sleep(2000)
        }
        return false
    }

    private fun check() {
        if (!Store.wanted(this)) return                      // user pressed Stop: do not restart
        if (serverUp()) { fails = 0; exempt(this); return }
        WdLog.add(this, "server not answering (3 tries), restarting")
        val r = try { Starter.auto(this) } catch (e: Throwable) { Starter.msg(e) }
        WdLog.add(this, "restart result: " + r.lines().first())
        if (r.startsWith("Server started")) { fails = 0; nextExempt = 0L } else fails++
    }

    override fun onTaskRemoved(rootIntent: Intent?) { scheduleAlarm(this); super.onTaskRemoved(rootIntent) }

    override fun onDestroy() {
        running = false
        poke()
        WdLog.add(this, "watchdog stopped")
        runCatching { unregisterReceiver(rx) }
        runCatching { wake?.takeIf { it.isHeld }?.release() }
        runCatching { wifi?.takeIf { it.isHeld }?.release() }
        super.onDestroy()
    }
}

/** Revives the watchdog (alarm) and re-arms it after boot or app update. */
class WatchdogReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!Store.watchdogOn(c)) return
        if (Store.wanted(c) || Store.autoStart(c)) WatchdogService.start(c)
        WatchdogService.scheduleAlarm(c)
    }
}
