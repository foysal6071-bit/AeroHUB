package com.example.mykuzu

import android.app.Activity
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Shizuku status + permission request. */
object ShizukuHelper {
    const val REQ = 4601

    fun running(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun granted(): Boolean = try {
        running() && !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun status(): String = when {
        !running() -> "Shizuku is not running. Install it and start it first."
        granted() -> "Shizuku permission granted."
        else -> "Shizuku is running. Permission not granted yet."
    }

    /** Asks Shizuku for permission. Result arrives in the listener registered in MainActivity. */
    fun request(a: Activity): String {
        if (!running()) return "Shizuku is not running. Install it and start it first."
        return try {
            when {
                Shizuku.isPreV11() -> "Please update Shizuku"
                granted() -> "Shizuku permission already granted."
                Shizuku.shouldShowRequestPermissionRationale() ->
                    "Permission was denied before. Open Shizuku > Authorized apps and allow MyKuzu."
                else -> { Shizuku.requestPermission(REQ); "Allow the request in the Shizuku dialog." }
            }
        } catch (e: Throwable) { "Shizuku error: ${e.message}" }
    }
}
