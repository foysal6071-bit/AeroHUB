package com.example.mykuzu

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Socket
import java.util.Base64

/** Client API. Copy this file into any app that wants to use MyKuzu. Call from a background thread. */
object MyKuzu {
    const val PORT = 27183
    const val ACTION_REQUEST = "com.example.mykuzu.action.REQUEST_PERMISSION"

    private fun request(token: String, line: String): String {
        val s = Socket("127.0.0.1", PORT)
        try {
            s.soTimeout = 60000
            s.getOutputStream().apply { write("$token $line\n".toByteArray()); flush() }
            return BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: ""
        } finally { s.close() }
    }

    /** Returns server uid (2000 = adb shell, 0 = root) or null if not running / denied. */
    fun ping(token: String): Int? = try {
        request(token, "PING").takeIf { it.startsWith("OK ") }?.substring(3)?.toInt()
    } catch (e: Exception) { null }

    /** Runs a shell command with the server's privileges. Returns exit code and output. */
    fun exec(token: String, cmd: String): Pair<Int, String> {
        val r = request(token, "EXEC " + Base64.getEncoder().encodeToString(cmd.toByteArray()))
        if (r == "DENIED") throw SecurityException("Invalid token")
        val p = r.split(" ", limit = 2)
        return p[0].toInt() to String(Base64.getDecoder().decode(p.getOrElse(1) { "" }))
    }

    /** Master-only: set the list of allowed app tokens on the server. */
    fun sync(masterToken: String, appTokens: List<String>) {
        request(masterToken, "SYNC " + appTokens.joinToString(",").ifEmpty { "-" })
    }

    fun stop(token: String) { try { request(token, "STOP") } catch (_: Exception) {} }

    // ---- Ready-made system actions (all run with the server's privileges) ----
    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    fun forceStop(t: String, pkg: String) = exec(t, "am force-stop ${q(pkg)}")
    fun clearData(t: String, pkg: String) = exec(t, "pm clear ${q(pkg)}")
    fun setAppEnabled(t: String, pkg: String, on: Boolean) =
        exec(t, if (on) "pm enable ${q(pkg)}" else "pm disable-user --user 0 ${q(pkg)}")
    fun uninstallForUser(t: String, pkg: String) = exec(t, "pm uninstall --user 0 ${q(pkg)}")
    fun grantPermission(t: String, pkg: String, perm: String) = exec(t, "pm grant ${q(pkg)} ${q(perm)}")
    fun revokePermission(t: String, pkg: String, perm: String) = exec(t, "pm revoke ${q(pkg)} ${q(perm)}")
    /** namespace: "global", "secure" or "system" */
    fun putSetting(t: String, ns: String, key: String, value: String) = exec(t, "settings put ${q(ns)} ${q(key)} ${q(value)}")
    fun getSetting(t: String, ns: String, key: String) = exec(t, "settings get ${q(ns)} ${q(key)}").second.trim()
    fun setDensity(t: String, dpi: Int?) = exec(t, if (dpi == null) "wm density reset" else "wm density $dpi")
    fun screenshot(t: String, path: String) = exec(t, "screencap -p ${q(path)}")
    fun reboot(t: String) = exec(t, "svc power reboot")
}
