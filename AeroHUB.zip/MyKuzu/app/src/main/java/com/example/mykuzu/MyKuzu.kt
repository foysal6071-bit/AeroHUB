package com.example.mykuzu

import android.content.Context
import android.net.Uri
import android.os.IBinder
import android.os.Parcel
import android.os.ParcelFileDescriptor
import android.os.RemoteException
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Socket
import java.util.Base64

/**
 * Client API. Copy this file into any app that wants to use MyKuzu. Call from a background thread.
 *
 * Transport: like Shizuku, the server hands its Binder to AeroHUB, and apps talk to it over Binder (no network, so Doze and
 * screen-off cannot cut the connection). Call [init] once (for example in Application.onCreate) to use it; without [init], or when
 * the Binder is not available, everything falls back to the old local TCP connection automatically.
 * On Android 11+ your manifest also needs: <queries><provider android:authorities="com.example.mykuzu.binder"/></queries>
 */
object MyKuzu {
    const val PORT = 27183
    const val ACTION_REQUEST = "com.example.mykuzu.action.REQUEST_PERMISSION"
    /**
     * AeroHUB sends this broadcast (explicitly to your package, also when the app was force-stopped) when your app is not
     * running. Declare a receiver for it in your manifest (android:exported="true"); when it fires, start your service or
     * reconnect. Android BOOT_COMPLETED is sent too, so an existing boot receiver also wakes the app.
     */
    const val ACTION_WAKE = "com.example.mykuzu.action.WAKE"

    const val PROVIDER_AUTHORITY = "com.example.mykuzu.binder"
    private const val DESCRIPTOR = "com.example.mykuzu.IServer"
    private const val TX_REQUEST = 1
    private const val TX_STREAM = 2

    @Volatile private var server: IBinder? = null
    @Volatile private var appCtx: Context? = null
    @Volatile private var lastLookup = 0L
    /** Time (ms) the server's Binder last died, 0 if it never did while this process ran. */
    @Volatile var diedAt = 0L
        private set
    /** Called on a Binder thread when the server's Binder dies (AeroHUB uses it to restart the server at once). */
    @Volatile var onServerDied: (() -> Unit)? = null

    /** Enables the Binder transport (also in apps that copy this file). */
    fun init(c: Context) { appCtx = c.applicationContext }

    /** True while a live Binder to the server is held. */
    fun binderAlive(): Boolean = server?.isBinderAlive == true
    fun currentBinder(): IBinder? = server?.takeIf { it.isBinderAlive }
    fun transport(): String = if (binderAlive()) "Binder" else "TCP"

    /** AeroHUB's own BinderProvider calls this when the server hands over its Binder. */
    fun setBinder(b: IBinder?) { if (b == null) server = null else adopt(b, true) }

    private fun adopt(b: IBinder, notify: Boolean) {
        server = b
        try {
            b.linkToDeath({
                if (server === b) {
                    server = null; diedAt = System.currentTimeMillis()
                    if (notify) try { onServerDied?.invoke() } catch (_: Throwable) {}
                }
            }, 0)
        } catch (_: Throwable) { server = null }
    }

    /** The server's Binder, or null. In other apps it is fetched from AeroHUB's provider (at most every 3 s while missing). */
    private fun binder(token: String): IBinder? {
        server?.let { if (it.isBinderAlive) return it }
        val c = appCtx ?: return null
        if (c.packageName == "com.example.mykuzu") return null        // AeroHUB itself gets it pushed by the server
        val now = System.currentTimeMillis()
        if (now - lastLookup < 3000) return null
        lastLookup = now
        return try {
            val r = c.contentResolver.call(Uri.parse("content://$PROVIDER_AUTHORITY"), "getBinder", token, null)
            val b = r?.getBinder("b")
            if (b != null && b.isBinderAlive) { adopt(b, false); b } else null
        } catch (_: Throwable) { null }
    }

    private fun tcp(token: String, line: String): String {
        val s = Socket("127.0.0.1", PORT)
        try {
            s.soTimeout = 90000
            s.getOutputStream().apply { write("$token $line\n".toByteArray()); flush() }
            return BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: throw java.io.IOException("No reply from server")
        } finally { s.close() }
    }

    private fun request(token: String, line: String): String {
        val b = binder(token)
        if (b != null) {
            val d = Parcel.obtain(); val r = Parcel.obtain()
            try {
                d.writeInterfaceToken(DESCRIPTOR)
                d.writeString("$token $line")
                b.transact(TX_REQUEST, d, r, 0)
                r.readException()
                return if (r.readInt() == 1) {
                    val pfd = ParcelFileDescriptor.CREATOR.createFromParcel(r)
                    String(ParcelFileDescriptor.AutoCloseInputStream(pfd).use { it.readBytes() })
                } else r.readString() ?: throw java.io.IOException("No reply from server")
            } catch (e: RemoteException) {
                if (server === b) server = null          // dead: use TCP this time
            } finally { d.recycle(); r.recycle() }
        }
        return tcp(token, line)
    }

    /** Asks the server to hand its Binder to AeroHUB again (used by a freshly started AeroHUB). Uses TCP. */
    fun requestPush(token: String): String? = try { tcp(token, "PUSH") } catch (_: Exception) { null }

    /** When the server last answered a ping (ms, 0 = never) and the uid it reported. */
    @Volatile var lastOkAt = 0L
        private set
    @Volatile var lastUid = 2000
        private set

    /** Returns server uid (2000 = adb shell, 0 = root) or null if not running / denied. */
    fun ping(token: String): Int? = try {
        request(token, "PING").takeIf { it.startsWith("OK ") }?.split(" ")?.get(1)?.toInt()
            ?.also { lastOkAt = System.currentTimeMillis(); lastUid = it }
    } catch (e: Exception) { null }

    /**
     * True only while a live Binder to the server is held (exactly like Shizuku): the Binder dies together with the server process,
     * so a held Binder proves the process exists even if it does not answer for a moment after screen on.
     */
    fun presumedAlive(): Boolean = binderAlive()

    /** Server protocol version (1 = old server without versioning), or null if not running / denied. */
    fun version(token: String): Int? = try {
        request(token, "PING").takeIf { it.startsWith("OK ") }?.split(" ")?.getOrNull(2)?.toIntOrNull() ?: 1
    } catch (e: Exception) { null }

    /**
     * Needs server version 6+. Returns true if apps are using the server right now (open connections / streams, or a command within
     * the last 2 minutes), false if idle, null if the server is not running or too old to say.
     */
    fun busy(token: String): Boolean? = try {
        request(token, "ACTIVITY").takeIf { it.startsWith("OK ") }?.split(" ")?.getOrNull(1)?.let { it == "1" }
    } catch (e: Exception) { null }

    /** Runs a shell command with the server's privileges. Returns exit code and output. */
    fun exec(token: String, cmd: String): Pair<Int, String> {
        val r = request(token, "EXEC " + Base64.getEncoder().encodeToString(cmd.toByteArray()))
        if (r == "DENIED") throw SecurityException("Invalid token")
        val p = r.split(" ", limit = 2)
        return p[0].toInt() to String(Base64.getDecoder().decode(p.getOrElse(1) { "" }))
    }

    /** Like [exec] but returns the raw output bytes (for binary output such as screencap). */
    fun execBytes(token: String, cmd: String): Pair<Int, ByteArray> {
        val r = request(token, "EXEC " + Base64.getEncoder().encodeToString(cmd.toByteArray()))
        if (r == "DENIED") throw SecurityException("Invalid token")
        val p = r.split(" ", limit = 2)
        return p[0].toInt() to Base64.getDecoder().decode(p.getOrElse(1) { "" })
    }

    /** Needs server version 4+. Sets the status bar / navigation "disable" flags (kept until changed or the server stops). */
    fun statusFlags(token: String, what: Int, what2: Int): Boolean = request(token, "SBFLAGS $what $what2").startsWith("OK")

    /** Needs server version 4+. Tells the server the app is alive (it gives the navigation buttons back if the beats stop). */
    fun beat(token: String) { request(token, "BEAT") }

    /**
     * Needs server version 4+. Runs [cmd] and calls [onLine] for every output line until it returns false or the command ends.
     * Blocks the calling thread. [onOpen] gets a Closeable that stops the stream from another thread. Use "exec <program>" in [cmd] so it stops cleanly.
     */
    fun stream(token: String, cmd: String, onOpen: (java.io.Closeable) -> Unit, onLine: (String) -> Boolean) {
        val b = binder(token)
        if (b != null) {
            var pfd: ParcelFileDescriptor? = null
            val d = Parcel.obtain(); val r = Parcel.obtain()
            try {
                d.writeInterfaceToken(DESCRIPTOR)
                d.writeString("$token STREAM ${Base64.getEncoder().encodeToString(cmd.toByteArray())}")
                b.transact(TX_STREAM, d, r, 0)
                r.readException()
                if (r.readInt() == 0) throw java.io.IOException("Stream refused")
                pfd = ParcelFileDescriptor.CREATOR.createFromParcel(r)
            } catch (e: RemoteException) {
                if (server === b) server = null
            } finally { d.recycle(); r.recycle() }
            if (pfd != null) {
                val ins = ParcelFileDescriptor.AutoCloseInputStream(pfd)
                try {
                    onOpen(ins)
                    val rd = BufferedReader(InputStreamReader(ins))
                    while (true) { val line = rd.readLine() ?: break; if (!onLine(line)) break }
                } finally { try { ins.close() } catch (_: Exception) {} }
                return
            }
        }
        val s = Socket("127.0.0.1", PORT)
        try {
            s.soTimeout = 0
            s.getOutputStream().apply { write("$token STREAM ${Base64.getEncoder().encodeToString(cmd.toByteArray())}\n".toByteArray()); flush() }
            val r = BufferedReader(InputStreamReader(s.getInputStream()))
            if (r.readLine() != "OK") throw java.io.IOException("Stream refused")
            onOpen(s)
            while (true) { val line = r.readLine() ?: break; if (!onLine(line)) break }
        } finally { try { s.close() } catch (_: Exception) {} }
    }

    /** Per-app uninstall protection. Returns null on success, otherwise an error message. Needs server version 3+. */
    fun setUninstallBlocked(token: String, pkg: String, on: Boolean): String? {
        val r = request(token, "UBLOCK $pkg ${if (on) 1 else 0}")
        return when {
            r == "DENIED" -> throw SecurityException("Invalid token")
            r.startsWith("OK") -> null
            r.startsWith("ERR unknown") -> "Server is outdated. Tap Restart in the Connect tab."
            else -> r.removePrefix("ERR ").ifBlank { "Failed" }
        }
    }

    /** Master-only: set the list of allowed app tokens on the server. */
    fun sync(masterToken: String, appTokens: List<String>) {
        request(masterToken, "SYNC " + appTokens.joinToString(",").ifEmpty { "-" })
    }

    /** Master-only: recent commands run by the server, as "time|who|exit|base64cmd" lines. */
    fun log(masterToken: String): List<String> {
        val r = request(masterToken, "LOG")
        if (!r.startsWith("OK")) return emptyList()
        return r.removePrefix("OK").trim().split(";").filter { it.isNotBlank() }
    }

    fun stop(token: String) { try { request(token, "STOP") } catch (_: Exception) {} }

    // ---- Ready-made system actions (all run with the server's privileges) ----
    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    fun forceStop(t: String, pkg: String) = exec(t, "am force-stop ${q(pkg)}")
    fun clearData(t: String, pkg: String) = exec(t, "pm clear ${q(pkg)}")
    fun setAppEnabled(t: String, pkg: String, on: Boolean) =
        exec(t, if (on) "pm enable ${q(pkg)}" else "pm disable-user --user 0 ${q(pkg)}")
    fun uninstallForUser(t: String, pkg: String) = exec(t, "pm uninstall --user 0 ${q(pkg)}")
    fun grantPermission(t: String, pkg: String, perm: String) = exec(t, "pm grant ${q(pkg)} ${q(perm)}")
    fun revokePermission(t: String, pkg: String, perm: String) = exec(t, "pm revoke ${q(pkg)} ${q(perm)}")
    /** namespace: "global", "secure" or "system" */
    fun putSetting(t: String, ns: String, key: String, value: String) = exec(t, "settings put ${q(ns)} ${q(key)} ${q(value)}")
    fun getSetting(t: String, ns: String, key: String) = exec(t, "settings get ${q(ns)} ${q(key)}").second.trim()
    fun setDensity(t: String, dpi: Int?) = exec(t, if (dpi == null) "wm density reset" else "wm density $dpi")
    fun screenshot(t: String, path: String) = exec(t, "screencap -p ${q(path)}")
    fun reboot(t: String) = exec(t, "svc power reboot")
}
