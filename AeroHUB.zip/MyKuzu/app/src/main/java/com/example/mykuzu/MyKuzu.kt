package com.example.mykuzu

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Socket
import java.util.Base64

/** Client API. Copy this file into any app that wants to use MyKuzu. Call from a background thread. */
object MyKuzu {
    const val PORT = 27183
    const val ACTION_REQUEST = "com.example.mykuzu.action.REQUEST_PERMISSION"

    private fun request(token: String, line: String): String {
        val s = Socket("127.0.0.1", PORT)
        try {
            s.soTimeout = 90000
            s.getOutputStream().apply { write("$token $line\n".toByteArray()); flush() }
            return BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: throw java.io.IOException("No reply from server")
        } finally { s.close() }
    }

    /** Returns server uid (2000 = adb shell, 0 = root) or null if not running / denied. */
    fun ping(token: String): Int? = try {
        request(token, "PING").takeIf { it.startsWith("OK ") }?.split(" ")?.get(1)?.toInt()
    } catch (e: Exception) { null }

    /** Server protocol version (1 = old server without versioning), or null if not running / denied. */
    fun version(token: String): Int? = try {
        request(token, "PING").takeIf { it.startsWith("OK ") }?.split(" ")?.getOrNull(2)?.toIntOrNull() ?: 1
    } catch (e: Exception) { null }

    /** Runs a shell command with the server's privileges. Returns exit code and output. */
    fun exec(token: String, cmd: String): Pair<Int, String> {
        val r = request(token, "EXEC " + Base64.getEncoder().encodeToString(cmd.toByteArray()))
        if (r == "DENIED") throw SecurityException("Invalid token")
        val p = r.split(" ", limit = 2)
        return p[0].toInt() to String(Base64.getDecoder().decode(p.getOrElse(1) { "" }))
    }

    /** Like [exec] but returns the raw output bytes (for binary output such as screencap). */
    fun execBytes(token: String, cmd: String): Pair<Int, ByteArray> {
        val r = request(token, "EXEC " + Base64.getEncoder().encodeToString(cmd.toByteArray()))
        if (r == "DENIED") throw SecurityException("Invalid token")
        val p = r.split(" ", limit = 2)
        return p[0].toInt() to Base64.getDecoder().decode(p.getOrElse(1) { "" })
    }

    /** Needs server version 4+. Sets the status bar / navigation "disable" flags (kept until changed or the server stops). */
    fun statusFlags(token: String, what: Int, what2: Int): Boolean = request(token, "SBFLAGS $what $what2").startsWith("OK")

    /** Needs server version 4+. Tells the server the app is alive (it gives the navigation buttons back if the beats stop). */
    fun beat(token: String) { request(token, "BEAT") }

    /**
     * Needs server version 4+. Runs [cmd] and calls [onLine] for every output line until it returns false or the command ends.
     * Blocks the calling thread. [onOpen] gets a Closeable that stops the stream from another thread. Use "exec <program>" in [cmd] so it stops cleanly.
     */
    fun stream(token: String, cmd: String, onOpen: (java.io.Closeable) -> Unit, onLine: (String) -> Boolean) {
        val s = Socket("127.0.0.1", PORT)
        try {
            s.soTimeout = 0
            s.getOutputStream().apply { write("$token STREAM ${Base64.getEncoder().encodeToString(cmd.toByteArray())}\n".toByteArray()); flush() }
            val r = BufferedReader(InputStreamReader(s.getInputStream()))
            if (r.readLine() != "OK") throw java.io.IOException("Stream refused")
            onOpen(s)
            while (true) { val line = r.readLine() ?: break; if (!onLine(line)) break }
        } finally { try { s.close() } catch (_: Exception) {} }
    }

    /** Per-app uninstall protection. Returns null on success, otherwise an error message. Needs server version 3+. */
    fun setUninstallBlocked(token: String, pkg: String, on: Boolean): String? {
        val r = request(token, "UBLOCK $pkg ${if (on) 1 else 0}")
        return when {
            r == "DENIED" -> throw SecurityException("Invalid token")
            r.startsWith("OK") -> null
            r.startsWith("ERR unknown") -> "Server is outdated. Tap Restart server in the Connect tab."
            else -> r.removePrefix("ERR ").ifBlank { "Failed" }
        }
    }

    /** Master-only: set the list of allowed app tokens on the server. */
    fun sync(masterToken: String, appTokens: List<String>) {
        request(masterToken, "SYNC " + appTokens.joinToString(",").ifEmpty { "-" })
    }

    /** Master-only: recent commands run by the server, as "time|who|exit|base64cmd" lines. */
    fun log(masterToken: String): List<String> {
        val r = request(masterToken, "LOG")
        if (!r.startsWith("OK")) return emptyList()
        return r.removePrefix("OK").trim().split(";").filter { it.isNotBlank() }
    }

    fun stop(token: String) { try { request(token, "STOP") } catch (_: Exception) {} }

    // ---- Ready-made system actions (all run with the server's privileges) ----
    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    fun forceStop(t: String, pkg: String) = exec(t, "am force-stop ${q(pkg)}")
    fun clearData(t: String, pkg: String) = exec(t, "pm clear ${q(pkg)}")
    fun setAppEnabled(t: String, pkg: String, on: Boolean) =
        exec(t, if (on) "pm enable ${q(pkg)}" else "pm disable-user --user 0 ${q(pkg)}")
    fun uninstallForUser(t: String, pkg: String) = exec(t, "pm uninstall --user 0 ${q(pkg)}")
    fun grantPermission(t: String, pkg: String, perm: String) = exec(t, "pm grant ${q(pkg)} ${q(perm)}")
    fun revokePermission(t: String, pkg: String, perm: String) = exec(t, "pm revoke ${q(pkg)} ${q(perm)}")
    /** namespace: "global", "secure" or "system" */
    fun putSetting(t: String, ns: String, key: String, value: String) = exec(t, "settings put ${q(ns)} ${q(key)} ${q(value)}")
    fun getSetting(t: String, ns: String, key: String) = exec(t, "settings get ${q(ns)} ${q(key)}").second.trim()
    fun setDensity(t: String, dpi: Int?) = exec(t, if (dpi == null) "wm density reset" else "wm density $dpi")
    fun screenshot(t: String, path: String) = exec(t, "screencap -p ${q(path)}")
    fun reboot(t: String) = exec(t, "svc power reboot")
}
