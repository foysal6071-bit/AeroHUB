package com.example.mykuzu

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Starts the server after the phone boots, when "Start on boot" is on. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED && Store.autoStart(c)) {
            runCatching { c.startForegroundService(Intent(c, BootService::class.java)) }
        }
    }
}
