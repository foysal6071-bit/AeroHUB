package com.example.mykuzu

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Starts the server (and the watchdog) after boot or app update. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED && Store.autoStart(c)) {
            runCatching { c.startForegroundService(Intent(c, BootService::class.java)) }
        }
        if (Store.wanted(c) || Store.autoStart(c)) WatchdogService.start(c)
    }
}
