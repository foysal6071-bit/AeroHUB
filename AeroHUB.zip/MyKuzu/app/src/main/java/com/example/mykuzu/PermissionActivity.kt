package com.example.mykuzu

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.SystemClock
import android.view.MotionEvent
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Other apps call startActivityForResult(Intent(MyKuzu.ACTION_REQUEST)); result has extra "token" (per-app). */
class PermissionActivity : Activity() {
    // Colours follow the in-app Appearance setting (0 = Light, 1 = Dark, 2 = AMOLED)
    private var ACCENT = 0; private var CARD = 0; private var INK = 0; private var SUB = 0; private var LINE = 0
    private var CHIP = 0; private var DENY_BG = 0; private var DENY_INK = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun applyTheme() {
        when (getSharedPreferences("aerohub_tools", Context.MODE_PRIVATE).getInt("theme", 0)) {
            1 -> { ACCENT = 0xFF3B82F6.toInt(); CARD = 0xFF1F2430.toInt(); INK = 0xFFF3F4F6.toInt(); SUB = 0xFF9CA3AF.toInt(); LINE = 0x1FFFFFFF; CHIP = 0xFF2A3040.toInt(); DENY_BG = 0xFF2A3040.toInt(); DENY_INK = 0xFFF3F4F6.toInt() }
            2 -> { ACCENT = 0xFF3B82F6.toInt(); CARD = 0xFF121212.toInt(); INK = 0xFFF3F4F6.toInt(); SUB = 0xFF9CA3AF.toInt(); LINE = 0x1FFFFFFF; CHIP = 0xFF1E1E1E.toInt(); DENY_BG = 0xFF1E1E1E.toInt(); DENY_INK = 0xFFF3F4F6.toInt() }
            else -> { ACCENT = 0xFF2563EB.toInt(); CARD = 0xFFFFFFFF.toInt(); INK = 0xFF111827.toInt(); SUB = 0xFF6B7280.toInt(); LINE = 0x1A000000; CHIP = 0xFFF3F4F6.toInt(); DENY_BG = 0xFFF3F4F6.toInt(); DENY_INK = 0xFF111827.toInt() }
        }
    }

    private fun cancel() { setResult(RESULT_CANCELED); finish() }
    override fun onBackPressed() { cancel() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = callingPackage
        if (pkg == null) { finish(); return }
        applyTheme()
        window.setBackgroundDrawable(ColorDrawable(0x80000000.toInt()))
        val pm = packageManager
        val label = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
        val icon = try { pm.getApplicationIcon(pkg) } catch (e: Exception) { null }

        if (!Store.masterOn(this)) {
            showCard(icon, "App access is off", "Turn on \"App access\" in AeroHUB to allow apps to connect.", null, null, null, "OK") { cancel() }
            return
        }

        showCard(
            icon, label, pkg,
            "wants to connect to AeroHUB",
            listOf("Run commands with elevated (adb shell) access", "Change system settings and manage apps"),
            "Deny", "Allow",
            onNegative = { cancel() }
        ) {
            val t = Store.allow(this, pkg)
            Store.push(this)
            setResult(RESULT_OK, Intent().putExtra("token", t)); finish()
        }
    }

    private fun pill(color: Int, r: Int = 12) = GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(color) }

    private fun button(text: String, bg: Int, ink: Int, onClick: () -> Unit) = TextView(this).apply {
        this.text = text; setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f); setTextColor(ink)
        setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER
        background = pill(bg); isClickable = true
        filterTouchesWhenObscured = true          // blocks tap-jacking by overlays, so no artificial delay is needed
        setOnClickListener { onClick() }
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> v.alpha = 0.75f
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.alpha = 1f
            }
            false
        }
    }

    private fun showCard(
        icon: android.graphics.drawable.Drawable?, title: String, sub: String,
        negative: String?, positive: String?, extra: String?, ok: String, onOk: () -> Unit
    ) {
        build(icon, title, sub, null, null, null, ok, {}, onOk)
    }

    private fun showCard(
        icon: android.graphics.drawable.Drawable?, title: String, pkg: String, headline: String,
        bullets: List<String>, negative: String, positive: String, onNegative: () -> Unit, onPositive: () -> Unit
    ) {
        build(icon, title, pkg, headline, bullets, negative, positive, onNegative, onPositive)
    }

    private fun build(
        icon: android.graphics.drawable.Drawable?, title: String, sub: String, headline: String?,
        bullets: List<String>?, negative: String?, positive: String,
        onNegative: () -> Unit, onPositive: () -> Unit
    ) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = pill(CARD, 24)
            isClickable = true
            elevation = dp(16).toFloat()
            setPadding(dp(24), dp(28), dp(24), dp(20))
            gravity = Gravity.CENTER_HORIZONTAL
        }
        if (icon != null) {
            card.addView(android.widget.ImageView(this).apply { setImageDrawable(icon) }, LinearLayout.LayoutParams(dp(56), dp(56)))
        }
        card.addView(TextView(this).apply {
            text = title; setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f); setTypeface(null, Typeface.BOLD)
            setTextColor(INK); gravity = Gravity.CENTER; setPadding(0, dp(14), 0, 0)
        })
        if (headline != null) {
            card.addView(TextView(this).apply {
                text = sub; setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f); setTextColor(SUB); gravity = Gravity.CENTER
            })
            card.addView(TextView(this).apply {
                text = headline; setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f); setTextColor(INK); gravity = Gravity.CENTER
                setPadding(0, dp(12), 0, 0)
            })
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = pill(CHIP, 14); setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            bullets?.forEach { b ->
                box.addView(TextView(this).apply {
                    text = "\u2022  $b"; setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f); setTextColor(INK); setPadding(0, dp(2), 0, dp(2))
                })
            }
            card.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
            card.addView(TextView(this).apply {
                text = "You can turn this off anytime in AeroHUB."
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f); setTextColor(SUB); gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0)
            })
        } else {
            card.addView(TextView(this).apply {
                text = sub; setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f); setTextColor(SUB); gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0)
            })
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        if (negative != null) {
            row.addView(button(negative, DENY_BG, DENY_INK, onNegative), LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(10) })
        }
        row.addView(button(positive, ACCENT, 0xFFFFFFFF.toInt(), onPositive), LinearLayout.LayoutParams(0, dp(48), 1f))
        card.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })

        val root = FrameLayout(this).apply { setOnClickListener { cancel() } }
        root.addView(card, FrameLayout.LayoutParams(dp(320), -2, Gravity.CENTER))
        setContentView(root)

        card.alpha = 0f; card.translationY = dp(24).toFloat(); card.scaleX = 0.96f; card.scaleY = 0.96f
        card.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(220).start()
    }
}
