package com.example.mykuzu

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.SystemClock
import android.view.MotionEvent
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Other apps call startActivityForResult(Intent(MyKuzu.ACTION_REQUEST)); result has extra "token" (per-app). */
class PermissionActivity : Activity() {
    // iOS-style alert; colours follow the in-app Appearance setting (0 = Light, 1 = Dark, 2 = AMOLED)
    private var BLUE = 0; private var CARD = 0; private var INK = 0; private var LINE = 0; private var PRESS = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun applyTheme() {
        when (getSharedPreferences("aerohub_tools", Context.MODE_PRIVATE).getInt("theme", 0)) {
            1 -> { BLUE = 0xFF0A84FF.toInt(); CARD = 0xF22C2C2E.toInt(); INK = 0xFFFFFFFF.toInt(); LINE = 0x66545458; PRESS = 0x22FFFFFF }
            2 -> { BLUE = 0xFF0A84FF.toInt(); CARD = 0xF21C1C1E.toInt(); INK = 0xFFFFFFFF.toInt(); LINE = 0x66545458; PRESS = 0x22FFFFFF }
            else -> { BLUE = 0xFF007AFF.toInt(); CARD = 0xF2F9F9F9.toInt(); INK = 0xFF000000.toInt(); LINE = 0x4D3C3C43; PRESS = 0x14000000 }
        }
    }

    // No touch (or Back) works for the first 2 seconds after the popup appears
    private val LOCK_MS = 2000L
    private var shownAt = 0L
    private fun locked() = SystemClock.uptimeMillis() - shownAt < LOCK_MS

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean = if (locked()) true else super.dispatchTouchEvent(ev)

    private fun cancel() { setResult(RESULT_CANCELED); finish() }
    override fun onBackPressed() { if (!locked()) cancel() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = callingPackage
        if (pkg == null) { finish(); return }
        applyTheme()
        window.setBackgroundDrawable(ColorDrawable(0x66000000))
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }

        if (!Store.masterOn(this)) {
            showAlert(
                "App access is off",
                SpannableStringBuilder("Turn on \"App access\" in AeroHUB to allow apps."),
                null, {}, "OK"
            ) { cancel() }
            return
        }

        val name = "\"$label\""
        val msg = SpannableStringBuilder("$name wants to run commands with AeroHUB's elevated access. You can turn it off anytime in AeroHUB.")
        msg.setSpan(StyleSpan(Typeface.BOLD), 0, name.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        showAlert("Permission request", msg, "Deny", { cancel() }, "Allow") {
            val t = Store.allow(this, pkg)
            Store.push(this)
            setResult(RESULT_OK, Intent().putExtra("token", t)); finish()
        }
    }

    private fun hairline(vertical: Boolean) = View(this).apply {
        setBackgroundColor(LINE)
        layoutParams = if (vertical) LinearLayout.LayoutParams(1, -1) else LinearLayout.LayoutParams(-1, 1)
    }

    private fun alertButton(text: String, bold: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text; setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f); setTextColor(BLUE)
        setTypeface(null, if (bold) Typeface.BOLD else Typeface.NORMAL)
        gravity = Gravity.CENTER
        isClickable = true
        setOnClickListener { onClick() }
        setOnTouchListener { v, e ->
            when (e.action) {
                android.view.MotionEvent.ACTION_DOWN -> v.setBackgroundColor(PRESS)
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> v.setBackgroundColor(0)
            }
            false
        }
        layoutParams = LinearLayout.LayoutParams(0, dp(46), 1f)
    }

    private fun showAlert(
        title: String, message: CharSequence,
        negative: String?, onNegative: () -> Unit,
        positive: String, onPositive: () -> Unit
    ) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(CARD) }
            isClickable = true
            clipToOutline = true
            elevation = dp(10).toFloat()
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(20), dp(18), dp(18))
        }
        body.addView(TextView(this).apply {
            text = title; setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f); setTypeface(null, Typeface.BOLD)
            setTextColor(INK); gravity = Gravity.CENTER
        })
        body.addView(TextView(this).apply {
            text = message; setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f); setTextColor(INK); gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        })
        card.addView(body)
        card.addView(hairline(false))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        if (negative != null) {
            row.addView(alertButton(negative, false, onNegative))
            row.addView(hairline(true))
        }
        row.addView(alertButton(positive, true, onPositive))
        card.addView(row)

        val root = FrameLayout(this).apply { setOnClickListener { cancel() } }
        root.addView(card, FrameLayout.LayoutParams(dp(290), -2, Gravity.CENTER))
        setContentView(root)

        // iOS-style pop-in: slightly large -> normal, fading in
        card.alpha = 0f; card.scaleX = 1.12f; card.scaleY = 1.12f
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(200).start()

        // buttons look dimmed while locked, then light up after 2 seconds
        shownAt = SystemClock.uptimeMillis()
        row.alpha = 0.35f
        row.animate().alpha(1f).setStartDelay(LOCK_MS - 300).setDuration(300).start()
    }
}
