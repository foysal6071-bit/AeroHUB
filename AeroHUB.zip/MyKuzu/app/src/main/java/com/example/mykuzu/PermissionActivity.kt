package com.example.mykuzu

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle

/** Other apps call startActivityForResult(Intent(MyKuzu.ACTION_REQUEST)); result has extra "token" (per-app). */
class PermissionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = callingPackage
        if (pkg == null) { finish(); return }
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)) } catch (e: Exception) { pkg }
        if (!Store.masterOn(this)) {
            AlertDialog.Builder(this)
                .setTitle("App access is off")
                .setMessage("Turn on \"App access\" in MyKuzu to allow apps.")
                .setPositiveButton("OK") { _, _ -> setResult(RESULT_CANCELED); finish() }
                .setOnCancelListener { setResult(RESULT_CANCELED); finish() }
                .show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Permission request")
            .setMessage("\"$label\" wants to run commands with MyKuzu's elevated access. You can turn it off anytime in MyKuzu.")
            .setPositiveButton("Allow") { _, _ ->
                val t = Store.allow(this, pkg)
                Store.push(this)
                setResult(RESULT_OK, Intent().putExtra("token", t)); finish()
            }
            .setNegativeButton("Deny") { _, _ -> setResult(RESULT_CANCELED); finish() }
            .setOnCancelListener { setResult(RESULT_CANCELED); finish() }
            .show()
    }
}
