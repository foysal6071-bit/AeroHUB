# MyKuzu - a small privileged service

Runs a small server (via `app_process`) as **adb shell (UID 2000)**; approved apps can run commands with that privilege.

## Build (GitHub)
Upload all files to a repo. Every push to `main` builds the APK and publishes it under Releases (or Actions -> "Build & Release APK" -> artifact `MyKuzu-apk`).
If the release step fails with a permission error: Settings -> Actions -> General -> Workflow permissions -> "Read and write permissions".

## Three tabs
- **Connect**: server status, Auto start, start methods (Wireless / TCP), Start on boot, Check connection.
- **Tools** (need the server running; app tools show a searchable list of installed apps, no package names to type):
  - **Uninstall protection**: a switch for each app in the list (stops that app from being uninstalled), plus one "Protect all apps" switch at the top. Needs server version 3: tap Restart once after updating.
  - **Resolution changer** and **DPI changer**: set a new value or reset. The change is undone after 15 seconds unless you tap Keep.
  - **App disable** / **App enable**: turn an app off or on. Enable lists only the apps that are off.
  - **Auto start**: let an app run in the background and start on its own (or stop that).
  - **Accessibility**: one switch per app that has an accessibility service; turns it on/off without opening Settings.
  - **Animation speed**, **Refresh rate**, **System UI tuner** (dark mode, navigation style, battery percent, clock seconds, show touches) and **Private DNS** (presets or your own host).
  - **Appearance**: Light, Dark or AMOLED black theme.
  - **Hide status bar**: one switch to hide the status bar (Android 10 and older) or its clock, icons and pull-down panel (Android 11+).
  - **Notifications**: one switch per app to allow or block its notifications.
- **Apps**: the apps that asked for access, with one switch per app and a master switch to block all of them. Long-press an app to remove it.

## Start the server
Tap **Auto start**: it tries TCP first, then Wireless debugging. Or pick a method:

1. **Wireless debugging (no PC, Android 11+)**: *Pair* -> tap "Pair device with pairing code" in Developer options -> type the 6-digit code in the MyKuzu notification. The server starts automatically.
2. **TCP (works without Wi-Fi)**: after pairing once, open the TCP tab and press **Enable TCP via Wireless** (MyKuzu runs the equivalent of `adb tcpip 5555` itself). Then press **Connect & Start**. Accept the "Allow USB debugging?" dialog the first time (tick "Always allow").

TCP stays on until the phone reboots. Turn on **Start on boot** (Advanced) to start the server again after every reboot (needs Wi-Fi + Android 11+; MyKuzu grants itself WRITE_SECURE_SETTINGS once, to switch Wireless debugging on).

## If TCP does not connect
Use **Advanced -> Check connection**. It shows whether the TCP port is open, whether Wireless debugging is found, and what to do next. MyKuzu now checks the port first, uses timeouts, retries 3 times and shows a clear error (port closed / authorisation needed / timed out).

## Use from another app
Copy `MyKuzu.kt` into your app, add INTERNET permission, then:
```kotlin
startActivityForResult(Intent(MyKuzu.ACTION_REQUEST).setPackage("com.example.mykuzu"), 1)

// background thread: MyKuzu.exec(token, "pm list packages")
```
Commands time out after 60 s and output is capped at 512 KB.

## App access
Each app that asks gets its own token. The **App access** card lists them: switch each app on/off, use the top switch to block all apps, long-press to remove. Changes apply instantly to the running server.

## Advanced
- **Restart**, and an "outdated server" notice after an app update.
- **Busy protection (server version 6)**: while apps use the server (open streams or a command in the last 2 min) the watchdog checks every 4 s, waits longer before declaring the server dead (so it never kills a slow but healthy one), and restarts at once if it is really gone. The server also switches off the Android 12+ phantom-process killer. Tap Restart once after updating.

- **Screen off / on (build 1.6)**: every way of starting the server (Auto start, Start, Connect & Start, Pair) now tells the watchdog to keep it alive, so a server that stops while the screen is off is started again by itself (before, only Auto start / Start did this). After a screen on or network change the watchdog retries every 4 s for 90 s. **Check connection** shows the ADB state at each screen off / on and the end of the server log, which tells why the server stopped. For the fastest recovery without Wi-Fi, switch ADB to TCP once (TCP tab).

The APK is signed with `app/debug.keystore` so new builds install over old ones. Use your own key if you publish the app publicly.

## For apps that need more (server version 4)
- `MyKuzu.execBytes` returns raw output bytes (for example `screencap`).
- `MyKuzu.stream` runs a command and delivers its output line by line (for example `getevent`).
- `MyKuzu.statusFlags` / `MyKuzu.beat` set the status bar and navigation "disable" flags; the buttons come back if the beats stop.
