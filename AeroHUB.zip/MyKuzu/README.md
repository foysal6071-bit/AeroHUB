# MyKuzu - a small privileged service

Runs a small server (via `app_process`) as **adb shell (UID 2000)**; approved apps can run commands with that privilege.

## Build (GitHub)
Upload all files to a repo. Every push to `main` builds the APK and publishes it under Releases (or Actions -> "Build & Release APK" -> artifact `MyKuzu-apk`).
If the release step fails with a permission error: Settings -> Actions -> General -> Workflow permissions -> "Read and write permissions".

## Three tabs
- **Connect**: server status, Auto start, start methods (Wireless / TCP), Start on boot, Check connection.
- **Tools** (need the server running; app tools show a searchable list of installed apps, no package names to type):
  - **Uninstall protection**: a switch for each app in the list (stops that app from being uninstalled), plus one "Protect all apps" switch at the top. Needs server version 3: tap Restart once after updating.
  - **Resolution changer** and **DPI changer**: set a new value or reset. The change is undone after 15 seconds unless you tap Keep.
  - **App disable** / **App enable**: turn an app off or on. Enable lists only the apps that are off.
  - **Auto start**: let an app run in the background and start on its own (or stop that).
  - **Accessibility**: one switch per app that has an accessibility service; turns it on/off without opening Settings.
  - **Animation speed**, **Refresh rate**, **System UI tuner** (dark mode, navigation style, battery percent, clock seconds, show touches) and **Private DNS** (presets or your own host).
  - **Appearance**: Light, Dark or AMOLED black theme.
  - **Hide status bar**: one switch to hide the status bar (Android 10 and older) or its clock, icons and pull-down panel (Android 11+).
  - **Notifications**: one switch per app to allow or block its notifications.
- **Apps**: the apps that asked for access, with one switch per app and a master switch to block all of them. Long-press an app to remove it.

## Start the server
Tap **Auto start**: it tries TCP first, then Wireless debugging. Or pick a method:

1. **Wireless debugging (no PC, Android 11+)**: *Pair* -> tap "Pair device with pairing code" in Developer options -> type the 6-digit code in the MyKuzu notification. The server starts automatically.
2. **TCP (works without Wi-Fi)**: after pairing once, open the TCP tab and press **Enable TCP via Wireless** (MyKuzu runs the equivalent of `adb tcpip 5555` itself). Then press **Connect & Start**. Accept the "Allow USB debugging?" dialog the first time (tick "Always allow").

TCP stays on until the phone reboots. Turn on **Start on boot** (Advanced) to start the server again after every reboot (needs Wi-Fi + Android 11+; MyKuzu grants itself WRITE_SECURE_SETTINGS once, to switch Wireless debugging on).

## If TCP does not connect
Use **Advanced -> Check connection**. It shows whether the TCP port is open, whether Wireless debugging is found, and what to do next. MyKuzu now checks the port first, uses timeouts, retries 3 times and shows a clear error (port closed / authorisation needed / timed out).

## Use from another app
Copy `MyKuzu.kt` into your app, add INTERNET permission, then:
```kotlin
startActivityForResult(Intent(MyKuzu.ACTION_REQUEST).setPackage("com.example.mykuzu"), 1)

// background thread: MyKuzu.exec(token, "pm list packages")
```
Commands time out after 60 s and output is capped at 512 KB.

## App access
Each app that asks gets its own token. The **App access** card lists them: switch each app on/off, use the top switch to block all apps, long-press to remove. Changes apply instantly to the running server.

## Advanced
- **Restart**, and an "outdated server" notice after an app update.
- **Busy protection (server version 6)**: while apps use the server (open streams or a command in the last 2 min) the watchdog checks every 4 s, waits longer before declaring the server dead (so it never kills a slow but healthy one), and restarts at once if it is really gone. The server also switches off the Android 12+ phantom-process killer. Tap Restart once after updating.

- **Screen off / on (build 1.6)**: every way of starting the server (Auto start, Start, Connect & Start, Pair) now tells the watchdog to keep it alive, so a server that stops while the screen is off is started again by itself (before, only Auto start / Start did this). After a screen on or network change the watchdog retries every 4 s for 90 s. **Check connection** shows the ADB state at each screen off / on and the end of the server log, which tells why the server stopped. For the fastest recovery without Wi-Fi, switch ADB to TCP once (TCP tab). Server version 7: an uncaught error can no longer kill the server (it is written to the server log instead); tap Restart once after updating.

The APK is signed with `app/debug.keystore` so new builds install over old ones. Use your own key if you publish the app publicly.

## For apps that need more (server version 4)
- `MyKuzu.execBytes` returns raw output bytes (for example `screencap`).
- `MyKuzu.stream` runs a command and delivers its output line by line (for example `getevent`).
- `MyKuzu.statusFlags` / `MyKuzu.beat` set the status bar and navigation "disable" flags; the buttons come back if the beats stop.

## Wake closed apps (build 1.7)
Settings -> **Wake closed apps** (on by default). Every 20 s, while the server is running, the watchdog checks every app that is switched on in the **Apps** list. If an app is not running it removes that app's background limits and sends it the broadcast `com.example.mykuzu.action.WAKE` (also to force-stopped apps) plus `BOOT_COMPLETED`, so its process starts in the background. Your app needs a receiver:
```xml
<receiver android:name=".WakeReceiver" android:exported="true">
    <intent-filter><action android:name="com.example.mykuzu.action.WAKE"/></intent-filter>
</receiver>
```
In `onReceive`, start your service / reconnect. The result ("woke closed app ..." or "could not wake ...") appears in the watchdog log under **Check connection**.

## Screen off / on fix (build 1.8)
Shizuku talks to its server over Binder, AeroHUB over a local TCP socket. After screen on, that socket can be unreachable for a few seconds (Doze / network not back yet). Before 1.8 the watchdog took that for "server dead" and restarted it with `pkill`, which killed a healthy server and often could not start a new one (adb not ready yet). Now:
- After screen on / unlock the watchdog waits up to ~15 s for the server to answer.
- If it still does not answer, the watchdog asks the shell whether the server process is alive. If it is, it is **left running** (log: "server process is alive but the app cannot reach it yet"). Only after 4 such misses in a row it is restarted.
- The watchdog log (Check connection) shows which case happened.

## Binder transport (build 1.9, server version 8)
Like Shizuku, the server now talks to AeroHUB (and to other apps) over **Binder**, not only over a local TCP socket:
- The server hands its Binder to AeroHUB's `BinderProvider` (the same trick Shizuku uses for its manager app), at start and every 30 s.
- AeroHUB and apps then call the server directly. No network is involved, so Doze, screen off or Wi-Fi sleep cannot cut the link.
- When the server dies, AeroHUB is told **at once** (Binder death notification) and restarts it immediately, no more waiting for the next 15 s check.
- If the Binder is not available (old server, push failed), everything falls back to TCP automatically. The Connect tab shows `Link: Binder` or `Link: TCP`; the watchdog log (Check connection) shows "binder push: ..." with the reason if Binder delivery fails.
- Tap **Restart** once after updating (server version 8).

For other apps: call `MyKuzu.init(context)` once (Application.onCreate) and add to the manifest
`<queries><provider android:authorities="com.example.mykuzu.binder"/></queries>`. Without `init` they keep using TCP.

## Cgroup switch (build 1.10, server version 9)
Same trick as Shizuku's `libshizuku.so`: at start the server moves itself into the root uid cgroup (`/sys/fs/cgroup/uid_0/cgroup.procs`, or every v1 hierarchy from `/proc/self/cgroup`), so the system no longer treats it as part of the adb session / a freezable app when the screen turns off. It also tries to lower `oom_score_adj` (shell is often refused). Every result is in the server log (`cgroup: moved pid ...` / `refused`), visible under **Check connection**. Tap **Restart** once after updating.

## Self-revival, works with the phone locked (build 1.11, server version 10)
The server now starts a tiny detached shell (own session) that watches it. If the server process dies for any reason, the shell starts a new one itself, with no adb and no Wi-Fi, so it also works while the screen is locked. Pressing **Stop** leaves a flag (`/data/local/tmp/aerohub_stop`) so the server is not revived; the next start removes it. The server log shows `supervisor: started (watching pid ...)` and, after a revival, `supervisor: server died, starting it again`. Tap **Restart** once after updating.

## Screen on: "Running" no longer flips to "Not running" (build 1.12, server version 11)
Shizuku shows "running" as long as its Binder is alive; AeroHUB used a failed ping. After screen on the server may need a few seconds to answer (frozen / Doze), and the UI showed "Not running" after ~3 s although the process was fine, and the watchdog could restart a healthy server.
- The Connect tab keeps "Running" (subtitle "reconnecting...") while the Binder is alive or the server answered less than 20 s ago, and re-checks every 3 s.
- The watchdog does not restart a server whose Binder is alive; only after 12 silent checks in a row.
- The server logs `pause detected: Ns without running (frozen or CPU asleep)` when it was frozen, and moves itself back into the `uid_0` cgroup if the system put it elsewhere (`cgroup guard`). Check connection shows these lines.
- Tap **Restart** once after updating.

## Build 1.13, server version 12
- Status follows the Binder only (like Shizuku): "Running ... reconnecting" shows only while the server's Binder is really alive. When the server process dies the Binder dies with it and the UI says "Not running" at once.
- Supervisor is stronger: checks every second, moves itself out of the adb session's cgroup, and the server restarts the supervisor if something killed it.
- When the supervisor finds the server dead it writes the system-log lines about the death (am_kill, phantom, lmkd, adbd, freezer...) into the server log, so **Check connection** shows who killed the server.

## Build 1.14: apps are no longer refused after the server restarts
A server started by the supervisor (or any start path that does not pass the current list) only knew the tokens from its first start, so apps such as Control Center got "DENIED" until AeroHUB was opened. Now, whenever a new server hands its Binder to AeroHUB, AeroHUB immediately sends the current list of allowed apps (`SYNC`). `setBinder` also no longer registers a new death listener every 30 s.

## Build 1.15, server version 13
The shell that adbd opens for the start command now moves itself into the root uid cgroup before it starts anything (same order as Shizuku's native starter), and the server does the same as its very first action (before the port bind, which could take up to 20 s). Result lines in the server log: `start shell cgroup: ...` and `cgroup: moved pid ...` / `refused`.

## Build 1.16: the watchdog no longer kills a healthy server
When the watchdog had to start the server and the new one did not answer within 8 s, the 2nd and 3rd start variants ran `pkill` and killed that new, healthy server, and so on. Right after screen on the answer can take longer, so this loop kept the server "off". Now every variant of a watchdog start leaves a live server alone (like Shizuku, which never kills its own server). Only the user's **Restart** and the 4-misses rule still restart a server on purpose.
