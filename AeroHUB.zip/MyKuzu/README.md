# MyKuzu - a small privileged service

Runs a small server (via `app_process`) as **adb shell (UID 2000)**; approved apps can run commands with that privilege.

## Build (GitHub)
Upload all files to a repo. Every push to `main` builds the APK and publishes it under Releases (or Actions -> "Build & Release APK" -> artifact `MyKuzu-apk`).
If the release step fails with a permission error: Settings -> Actions -> General -> Workflow permissions -> "Read and write permissions".

## Two tabs
- **Connect**: server status, Auto start, start methods (Wireless / TCP), App access, Start on boot, Check connection.
- **Tools**: Accessibility, Activities launcher, App installer, App ops, App manager, Permissions, Device info, Display, Files, System settings, Power, Keyboard guard, Terminal, Activity log. Needs the server running.

## Start the server
Tap **Auto start**: it tries TCP first, then Wireless debugging. Or pick a method:

1. **Wireless debugging (no PC, Android 11+)**: *Start pairing* -> tap "Pair device with pairing code" in Developer options -> type the 6-digit code in the MyKuzu notification. The server starts automatically.
2. **TCP (works without Wi-Fi)**: after pairing once, open the TCP tab and press **Enable TCP via Wireless** (MyKuzu runs the equivalent of `adb tcpip 5555` itself). Then press **Connect & Start**. Accept the "Allow USB debugging?" dialog the first time (tick "Always allow").

TCP stays on until the phone reboots. Turn on **Start on boot** (Advanced) to start the server again after every reboot (needs Wi-Fi + Android 11+; MyKuzu grants itself WRITE_SECURE_SETTINGS once, to switch Wireless debugging on).

## If TCP does not connect
Use **Advanced -> Check connection**. It shows whether the TCP port is open, whether Wireless debugging is found, and what to do next. MyKuzu now checks the port first, uses timeouts, retries 3 times and shows a clear error (port closed / authorisation needed / timed out).

## Use from another app
Copy `MyKuzu.kt` into your app, add INTERNET permission, then:
```kotlin
startActivityForResult(Intent(MyKuzu.ACTION_REQUEST).setPackage("com.example.mykuzu"), 1)

// background thread: MyKuzu.exec(token, "pm list packages")
```
Commands time out after 60 s and output is capped at 512 KB.

## App access
Each app that asks gets its own token. The **App access** card lists them: switch each app on/off, use the top switch to block all apps, long-press to remove. Changes apply instantly to the running server.

## Advanced
- **Activity log** (Tools tab): the last 200 commands the server ran and which app ran them.
- **Restart server**, and an "outdated server" notice after an app update.
- **System tools**: device info, screenshot, animations, reboot, force stop, clear data, disable/enable/uninstall for the current user, grant/revoke permissions, screen density, system settings. What is possible depends on the server's UID (root can do more).

The APK is signed with `app/debug.keystore` so new builds install over old ones. Use your own key if you publish the app publicly.
