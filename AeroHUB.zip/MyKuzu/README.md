# MyKuzu - a minimal Shizuku-style privileged service

Runs a small server (via `app_process`) as **adb shell (uid 2000)** or **root**; approved apps can run commands with that privilege.

## Build (GitHub)
Upload all files to a repo -> Actions -> "Build APK" -> download artifact `MyKuzu-debug-apk`.

## Start the server (pick one)
1. **Wireless debugging (no PC, Android 11+)**: Developer options > Wireless debugging > Pair device with pairing code. In MyKuzu enter the pairing port + code, press *Pair device*; then enter the wireless debugging port and press *Connect & Start*.
2. **ADB over TCP**: once from a PC run `adb tcpip 5555`, then press *Connect & Start* in MyKuzu.
3. **Root**: press *Start with root*.
4. **PC**: `adb shell sh /sdcard/Android/data/com.example.mykuzu/files/start.sh`

The server must be started again after a reboot.

## Use from another app
Copy `MyKuzu.kt` into your app, add INTERNET permission, then:
```kotlin
startActivityForResult(Intent(MyKuzu.ACTION_REQUEST).setPackage("com.example.mykuzu"), 1)

// background thread: MyKuzu.exec(token, "pm list packages")
```

## App access
Each app that asks gets its own token. In MyKuzu, the **App access** card lists them: turn each app on/off with its switch, use the top switch to block all apps at once, long-press to remove. Changes apply instantly to the running server.

## System tools
The app has a **System tools** card (device info, screenshot, animations, reboot, force stop, clear data, disable/enable/uninstall for the current user, grant/revoke permissions, screen density, system settings). Other apps can use the same actions through `MyKuzu.forceStop(...)`, `MyKuzu.grantPermission(...)`, `MyKuzu.putSetting(...)` etc. in `MyKuzu.kt`.
What is possible depends on the server's UID: ADB shell (2000) covers the actions above; root (0) can do more (write to /system, change SELinux mode, etc.) through the Terminal.

## Pairing through a notification
Wireless tab -> *Start pairing*. MyKuzu finds the pairing port by itself; tap "Pair device with pairing code" in Settings, then type the 6-digit code into the MyKuzu notification (pull-down reply field). MyKuzu pairs, finds the connection port and starts the server. Needs Android 11+, Wi-Fi and notification permission.

## Auto build & release
Every push to `main` builds the APK and publishes it as a GitHub Release (Releases page -> latest -> download the .apk). You can also run it by hand: Actions -> "Build & Release APK" -> Run workflow.
If the release step fails with a permission error: Settings -> Actions -> General -> Workflow permissions -> "Read and write permissions".
The APK is signed with the key in `app/debug.keystore` so new builds install over old ones. Use your own key if you publish the app publicly.
